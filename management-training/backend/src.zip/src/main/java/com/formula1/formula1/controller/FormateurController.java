package com.formula1.formula1.controller;

import com.formula1.formula1.model.Formateur;
import com.formula1.formula1.service.FormateurService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/formateurs")
public class FormateurController {

    private final FormateurService formateurService;

    public FormateurController(FormateurService formateurService) {
        this.formateurService = formateurService;
    }

    @GetMapping
    public List<Formateur> getAllFormateurs() {
        return formateurService.getAllFormateurs();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Formateur> getFormateurById(@PathVariable Long id) {
        return formateurService.getFormateurById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Formateur addFormateur(@RequestBody Formateur formateur) {
        return formateurService.addFormateur(formateur);
    }

    @PutMapping("/{id}")
    public Formateur updateFormateur(@PathVariable Long id, @RequestBody Formateur formateur) {
        return formateurService.updateFormateur(id, formateur);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFormateur(@PathVariable Long id) {
        formateurService.deleteFormateur(id);
        return ResponseEntity.noContent().build();
    }
}

