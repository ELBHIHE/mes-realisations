package com.formula1.formula1.model;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.formula1.formula1.model.enumeration.TypeParcours;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class Parcours {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String nom;

    @Enumerated(EnumType.STRING)
    private TypeParcours type;

    private int duree;
    private String description;
    private String profil;


    @OneToMany(mappedBy = "parcours", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("parcours-candidatParcours")
    private List<CandidatParcours> candidatParcours;

    @OneToMany(mappedBy = "parcours", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<Module> modules;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public TypeParcours getType() {
        return type;
    }

    public void setType(TypeParcours type) {
        this.type = type;
    }

    public int getDuree() {
        return duree;
    }

    public void setDuree(int duree) {
        this.duree = duree;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProfil() {
        return profil;
    }

    public void setProfil(String profil) {
        this.profil = profil;
    }

    public List<CandidatParcours> getCandidatParcours() {
        return candidatParcours;
    }


    public void setCandidatParcours(List<CandidatParcours> candidatParcours) {
        this.candidatParcours = candidatParcours;
    }

    public List<Module> getModules() {
        return modules;
    }

    public void setModules(List<Module> modules) {
        this.modules = modules;
    }
}

