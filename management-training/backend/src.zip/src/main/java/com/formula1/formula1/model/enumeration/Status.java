package com.formula1.formula1.model.enumeration;

public enum Status {
    NON_COMMENCE,
    EN_COURS,
    TERMINE
}
