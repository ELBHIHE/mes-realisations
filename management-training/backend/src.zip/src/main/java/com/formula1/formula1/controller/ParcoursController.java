package com.formula1.formula1.controller;


import com.formula1.formula1.model.Parcours;
import com.formula1.formula1.service.ParcoursService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/parcours")
public class ParcoursController {

    @Autowired
    private ParcoursService parcoursService;

    @GetMapping
    public List<Parcours> getAllParcours() {
        return parcoursService.getAllParcours();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Parcours> getParcoursById(@PathVariable int id) {
        return parcoursService.getParcoursById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Parcours createParcours(@RequestBody Parcours parcours) {
        return parcoursService.createParcours(parcours);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Parcours> updateParcours(@PathVariable int id, @RequestBody Parcours parcours) {
        try {
            return ResponseEntity.ok(parcoursService.updateParcours(id, parcours));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteParcours(@PathVariable int id) {
        parcoursService.deleteParcours(id);
        return ResponseEntity.noContent().build();
    }
}
