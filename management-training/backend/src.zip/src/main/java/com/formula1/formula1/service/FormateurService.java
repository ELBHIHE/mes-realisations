package com.formula1.formula1.service;

import com.formula1.formula1.Repository.FormateurRepository;
import com.formula1.formula1.model.Formateur;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FormateurService {

    private final FormateurRepository formateurRepository;

    public FormateurService(FormateurRepository formateurRepository) {
        this.formateurRepository = formateurRepository;
    }

    public List<Formateur> getAllFormateurs() {
        return formateurRepository.findAll();
    }

    public Optional<Formateur> getFormateurById(Long id) {
        return formateurRepository.findById(id);
    }

    public Formateur addFormateur(Formateur formateur) {
        return formateurRepository.save(formateur);
    }

    public Formateur updateFormateur(Long id, Formateur updatedFormateur) {
        return formateurRepository.findById(id)
                .map(f -> {
                    f.setNomComplet(updatedFormateur.getNomComplet());
                    f.setEmail(updatedFormateur.getEmail());
                    f.setPassword(updatedFormateur.getPassword());
                    f.setProfil(updatedFormateur.getProfil());
                    return formateurRepository.save(f);
                })
                .orElseThrow(() -> new RuntimeException("Formateur non trouvé"));
    }

    public void deleteFormateur(Long id) {
        formateurRepository.deleteById(id);
    }
}
