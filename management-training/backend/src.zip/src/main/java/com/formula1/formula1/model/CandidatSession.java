package com.formula1.formula1.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

import java.util.Date;

@Entity
public class CandidatSession {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private Date dateAffectation;

    @ManyToOne(fetch = FetchType.EAGER)
    @JsonBackReference("candidat-candidatSessions")
    private Candidat candidat;

    @ManyToOne(fetch = FetchType.EAGER)
    @JsonBackReference("session-candidatSessions")
    private Session session;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDateAffectation() {
        return dateAffectation;
    }

    public Candidat getCandidat() {
        return candidat;
    }

    public Session getSession() {
        return session;
    }


    public void setDateAffectation(Date dateAffectation) {
        this.dateAffectation = dateAffectation;
    }

    public void setCandidat(Candidat candidat) {
        this.candidat = candidat;
    }

    public void setSession(Session session) {
        this.session = session;
    }

}
