package com.formula1.formula1.model.dto;

import com.formula1.formula1.model.enumeration.Status;

import java.util.Date;


public class ProgressionRequest {
    private int id;
    private Status status;
    private Date dateDebut;
    private Date dateFin;
    private String commentaire;
    private String evaluation;
    private Long candidatId;
    private int moduleId;

    public ProgressionRequest() {
    }

    public ProgressionRequest(Status status, int id, Date dateDebut, String commentaire, Date dateFin, String evaluation, Long candidatId, int moduleId) {
        this.status = status;
        this.id = id;
        this.dateDebut = dateDebut;
        this.commentaire = commentaire;
        this.dateFin = dateFin;
        this.evaluation = evaluation;
        this.candidatId = candidatId;
        this.moduleId = moduleId;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(Date dateDebut) {
        this.dateDebut = dateDebut;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public String getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(String evaluation) {
        this.evaluation = evaluation;
    }

    public Long getCandidatId() {
        return candidatId;
    }

    public void setCandidatId(Long candidatId) {
        this.candidatId = candidatId;
    }

    public int getModuleId() {
        return moduleId;
    }

    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }
}

