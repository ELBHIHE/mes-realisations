package com.formula1.formula1.model.dto;

import com.formula1.formula1.model.*;
import com.formula1.formula1.model.Module;

import java.util.Date;

public class CandidatSessionDTO {
    private int id;
    private Date dateAffectation;
    private Candidat candidat;
    private Session session;

    public CandidatSessionDTO() {}

    public CandidatSessionDTO(CandidatSession cs) {
        this.id = cs.getId();
        this.dateAffectation = cs.getDateAffectation();
        this.candidat = cs.getCandidat();
        this.session = cs.getSession();
    }



    // Getters et setters


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDateAffectation() {
        return dateAffectation;
    }

    public void setDateAffectation(Date dateAffectation) {
        this.dateAffectation = dateAffectation;
    }

    public Candidat getCandidat() {
        return candidat;
    }

    public void setCandidat(Candidat candidat) {
        this.candidat = candidat;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }
}
