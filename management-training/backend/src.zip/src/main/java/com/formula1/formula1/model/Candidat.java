package com.formula1.formula1.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.util.Date;
import java.util.List;

@Entity
@DiscriminatorValue("CANDIDAT")
public class Candidat extends Utilisateur {

    private String profil;

    @Column(name = "date_entree")
    private Date dateEntree;


    @OneToMany(mappedBy = "candidat", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("candidat-progression")
    private List<Progression> progressions;

    @OneToMany(mappedBy = "candidat", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("candidat-candidatParcours")
    private List<CandidatParcours> candidatParcours;

    @OneToMany(mappedBy = "candidat", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("candidat-candidatSessions")
    private List<CandidatSession> candidatSessions;


    public String getProfil() {
        return profil;
    }

    public void setProfil(String profil) {
        this.profil = profil;
    }

    public Date getDateEntree() {
        return dateEntree;
    }

    public void setDateEntree(Date dateEntree) {
        this.dateEntree = dateEntree;
    }

}
