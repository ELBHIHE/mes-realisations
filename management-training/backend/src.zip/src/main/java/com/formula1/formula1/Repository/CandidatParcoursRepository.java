package com.formula1.formula1.Repository;

import com.formula1.formula1.model.CandidatParcours;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CandidatParcoursRepository extends JpaRepository<CandidatParcours, Integer> {
}
