package com.formula1.formula1.controller;


import com.formula1.formula1.model.Module;
import com.formula1.formula1.service.FormateurModuleService;
import com.formula1.formula1.service.ModuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/modules")
public class ModuleController {

    @Autowired
    private ModuleService moduleService;

    @Autowired
    private FormateurModuleService formateurModuleService;

    @PostMapping
    public Module createModule(@RequestBody Module module) {
        return moduleService.createModule(module);
    }


    @PostMapping("/automatique")
    public Module createModule(@RequestBody Module module, @RequestParam Long formateurId) {
        Module savedModule = moduleService.createModule(module);
        formateurModuleService.affecterFormateurModuleDirect(formateurId, savedModule.getId());
        return savedModule;
    }

    @GetMapping("/{id}")
    public Module getModuleById(@PathVariable int id) {
        return moduleService.getModuleById(id);
    }


    @GetMapping("/candidat/{id}")
    public List<Module> getModulesByCandidat(@PathVariable int id) {
        return moduleService.getModulesForCandidat(id);
    }


    @GetMapping
    public List<Module> getAllModules() {
        return moduleService.getAllModules();
    }

    @PutMapping("/{id}")
    public Module updateModule(@PathVariable int id, @RequestBody Module module) {
        return moduleService.updateModule(id, module);
    }

    @DeleteMapping("/{id}")
    public void deleteModule(@PathVariable int id) {
        moduleService.deleteModule(id);
    }
}
