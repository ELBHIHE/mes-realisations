package com.formula1.formula1.controller;


import com.formula1.formula1.model.Utilisateur;
import com.formula1.formula1.model.dto.LoginRequest;
import com.formula1.formula1.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public Utilisateur login(@RequestBody LoginRequest loginRequest) {
        Utilisateur utilisateur = authService.login(loginRequest.getEmail(), loginRequest.getPassword());
        if (utilisateur == null) {
            throw new RuntimeException("Email ou mot de passe incorrect");
        }
        return utilisateur;
    }



}
