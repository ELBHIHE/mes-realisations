package com.formula1.formula1.service;

import com.formula1.formula1.Repository.CandidatSessionRepository;
import com.formula1.formula1.Repository.SessionRepository;
import com.formula1.formula1.model.CandidatSession;
import com.formula1.formula1.model.Session;

import com.formula1.formula1.model.dto.SessionDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SessionService {
    @Autowired
    private final SessionRepository sessionRepository;
    @Autowired
    private CandidatSessionRepository candidatSessionRepository;

    public SessionService(SessionRepository sessionRepository) {
        this.sessionRepository = sessionRepository;
    }

    public List<SessionDTO> getAllSessions() {
        return sessionRepository.findAll().stream()
                .map(session -> new SessionDTO(
                        session.getId(),
                        session.getDateSession(),
                        session.getSalleOuLien(),
                        new SessionDTO.FormateurDTO(session.getFormateur().getId(), session.getFormateur().getNomComplet()),
                        new SessionDTO.ModuleDTO(session.getModule().getId(), session.getModule().getNom())
                ))
                .collect(Collectors.toList());
    }

    public Optional<Session> getSessionById(int id) {
        return sessionRepository.findById(id);
    }

    public Session addSession(Session session) {
        return sessionRepository.save(session);
    }

    public Session updateSession(int id, Session session) {
        session.setId(id);
        return sessionRepository.save(session);
    }

    public void deleteSession(int id) {
        sessionRepository.deleteById(id);
    }


    //Pour récupérer les sessions du formateur connecté
    public List<SessionDTO> getSessionsByFormateurId(int formateurId) {
        return sessionRepository.findByFormateurId(formateurId).stream()
                .map(session -> new SessionDTO(
                        session.getId(),
                        session.getDateSession(),
                        session.getSalleOuLien(),
                        new SessionDTO.FormateurDTO(
                                session.getFormateur().getId(),
                                session.getFormateur().getNomComplet()
                        ),
                        new SessionDTO.ModuleDTO(
                                session.getModule().getId(),
                                session.getModule().getNom()
                        )
                ))
                .collect(Collectors.toList());
    }


    //Pour récupérer les sessions du Candidat connecté
    public List<SessionDTO> getSessionsByCandidatId(int candidatId) {
        List<CandidatSession> candidatSessions = candidatSessionRepository.findByCandidatId(candidatId);

        return candidatSessions.stream()
                .map(cs -> {
                    Session session = cs.getSession();
                    return new SessionDTO(
                            session.getId(),
                            session.getDateSession(),
                            session.getSalleOuLien(),
                            session.getFormateur() != null
                                    ? new SessionDTO.FormateurDTO(session.getFormateur().getId(), session.getFormateur().getNomComplet())
                                    : null,
                            session.getModule() != null
                                    ? new SessionDTO.ModuleDTO(session.getModule().getId(), session.getModule().getNom())
                                    : null
                    );
                })
                .collect(Collectors.toList());
    }
}


