package com.formula1.formula1.Repository;


import com.formula1.formula1.model.FormateurModule;
import com.formula1.formula1.model.Module;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FormateurModuleRepository extends JpaRepository<FormateurModule, Integer> {

    @Query("SELECT fm.module FROM FormateurModule fm WHERE fm.formateur.id = :formateurId")
    List<Module> findModulesByFormateurId(@Param("formateurId") Long formateurId);

}

