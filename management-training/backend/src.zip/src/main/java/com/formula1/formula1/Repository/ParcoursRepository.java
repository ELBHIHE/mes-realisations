package com.formula1.formula1.Repository;


import com.formula1.formula1.model.Parcours;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ParcoursRepository extends JpaRepository<Parcours, Integer> {



    Parcours findFirstByProfil(String profil);

}
