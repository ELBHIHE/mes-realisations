package com.formula1.formula1.Repository;

import com.formula1.formula1.model.Session;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SessionRepository extends JpaRepository<Session, Integer> {
    List<Session> findByFormateurId(int formateurId);
}
