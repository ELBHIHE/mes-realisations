package com.formula1.formula1.model.dto;

import com.formula1.formula1.model.Progression;
import com.formula1.formula1.model.enumeration.Status;

import java.util.Date;
public class ProgressionDTO {
    private int id;
    private Status status;
    private Date dateDebut;
    private Date dateFin;
    private Date prohibited;
    private String commentaire;
    private String evaluation;
    private Long candidatId; // Add candidatId
    private String candidatNom;
    private String moduleNom;

    public ProgressionDTO() {
    }

    public ProgressionDTO(Progression progression) {
        this.id = progression.getId();
        this.status = progression.getStatus();
        this.dateDebut = progression.getDateDebut();
        this.dateFin = progression.getDateFin();
        this.commentaire = progression.getCommentaire();
        this.evaluation = progression.getEvaluation();
        this.candidatId = progression.getCandidat() != null ? progression.getCandidat().getId() : null;
        this.candidatNom = progression.getCandidat() != null ? progression.getCandidat().getNomComplet() : null;
        this.moduleNom = progression.getModule() != null ? progression.getModule().getNom() : null;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    public Date getDateDebut() { return dateDebut; }
    public void setDateDebut(Date dateDebut) { this.dateDebut = dateDebut; }
    public Date getDateFin() { return dateFin; }
    public void setDateFin(Date dateFin) { this.dateFin = dateFin; }
    public String getCommentaire() { return commentaire; }
    public void setCommentaire(String commentaire) { this.commentaire = commentaire; }
    public String getEvaluation() { return evaluation; }
    public void setEvaluation(String evaluation) { this.evaluation = evaluation; }
    public Long getCandidatId() { return candidatId; }
    public void setCandidatId(Long candidatId) { this.candidatId = candidatId; }
    public String getCandidatNom() { return candidatNom; }
    public void setCandidatNom(String candidatNom) { this.candidatNom = candidatNom; }
    public String getModuleNom() { return moduleNom; }
    public void setModuleNom(String moduleNom) { this.moduleNom = moduleNom; }
}
