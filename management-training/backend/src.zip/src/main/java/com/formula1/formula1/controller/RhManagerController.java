package com.formula1.formula1.controller;

import com.formula1.formula1.model.RH_Manager;
import com.formula1.formula1.service.RhManagerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rh-managers")
public class RhManagerController {

    private final RhManagerService rhManagerService;

    public RhManagerController(RhManagerService rhManagerService) {
        this.rhManagerService = rhManagerService;
    }

    @GetMapping
    public List<RH_Manager> getAllRhManagers() {
        return rhManagerService.getAllRhManagers();
    }

    @GetMapping("/{id}")
    public ResponseEntity<RH_Manager> getRhManagerById(@PathVariable Long id) {
        return rhManagerService.getRhManagerById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public RH_Manager addRhManager(@RequestBody RH_Manager rhManager) {
        return rhManagerService.addRhManager(rhManager);
    }

    @PutMapping("/{id}")
    public RH_Manager updateRhManager(@PathVariable Long id, @RequestBody RH_Manager rhManager) {
        return rhManagerService.updateRhManager(id, rhManager);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRhManager(@PathVariable Long id) {
        rhManagerService.deleteRhManager(id);
        return ResponseEntity.noContent().build();
    }
}

