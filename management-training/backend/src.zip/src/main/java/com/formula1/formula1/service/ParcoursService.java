package com.formula1.formula1.service;


import com.formula1.formula1.Repository.ParcoursRepository;
import com.formula1.formula1.model.Parcours;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Optional;

@Service
public class ParcoursService {

    @Autowired
    private ParcoursRepository parcoursRepository;

    public List<Parcours> getAllParcours() {
        return parcoursRepository.findAll();
    }

    public Optional<Parcours> getParcoursById(int id) {
        return parcoursRepository.findById(id);
    }

    public Parcours createParcours(Parcours parcours) {
        return parcoursRepository.save(parcours);
    }

    public Parcours updateParcours(int id, Parcours updatedParcours) {
        return parcoursRepository.findById(id).map(parcours -> {
            parcours.setNom(updatedParcours.getNom());
            parcours.setType(updatedParcours.getType());
            parcours.setDuree(updatedParcours.getDuree());
            parcours.setDescription(updatedParcours.getDescription());
            parcours.setProfil(updatedParcours.getProfil());
            return parcoursRepository.save(parcours);
        }).orElseThrow(() -> new RuntimeException("Parcours non trouvé"));
    }

    public void deleteParcours(int id) {
        parcoursRepository.deleteById(id);
    }
}
