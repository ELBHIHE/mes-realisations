package com.formula1.formula1.controller;

import com.formula1.formula1.model.Candidat;
import com.formula1.formula1.model.dto.CandidatAvecParcoursDTO;
import com.formula1.formula1.service.CandidatService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/candidats")
public class CandidatController {

    private final CandidatService candidatService;

    public CandidatController(CandidatService candidatService) {
        this.candidatService = candidatService;
    }

    @GetMapping
    public List<Candidat> getAllCandidats() {
        return candidatService.getAllCandidats();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Candidat> getCandidatById(@PathVariable Long id) {
        return candidatService.getCandidatById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public Candidat updateCandidat(@PathVariable Long id, @RequestBody Candidat candidat) {
        return candidatService.updateCandidat(id, candidat);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCandidat(@PathVariable Long id) {
        candidatService.deleteCandidat(id);
        return ResponseEntity.noContent().build();
    }


    @PostMapping
    public CandidatAvecParcoursDTO addCandidat(@RequestBody Candidat candidat) {
        return candidatService.addCandidatEtAffecter(candidat);
    }

}

