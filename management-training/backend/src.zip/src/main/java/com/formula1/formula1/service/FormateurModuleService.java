package com.formula1.formula1.service;

import com.formula1.formula1.Repository.FormateurModuleRepository;
import com.formula1.formula1.Repository.FormateurRepository;
import com.formula1.formula1.Repository.ModuleRepository;
import com.formula1.formula1.model.Formateur;
import com.formula1.formula1.model.FormateurModule;
import com.formula1.formula1.model.Module;
import com.formula1.formula1.model.dto.AffectationFormateurModule;
import com.formula1.formula1.model.dto.AffectationFormateurModuleDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FormateurModuleService {

    @Autowired
    private FormateurModuleRepository formateurModuleRepository;

    @Autowired
    private FormateurRepository formateurRepository;

    @Autowired
    private ModuleRepository moduleRepository;

    public FormateurModule affecterFormateurModule(AffectationFormateurModuleDTO dto) {
        Formateur formateur = formateurRepository.findById(dto.getFormateurId())
                .orElseThrow(() -> new RuntimeException("Formateur non trouvé"));

        Module module = moduleRepository.findById(dto.getModuleId())
                .orElseThrow(() -> new RuntimeException("Module non trouvé"));

        FormateurModule fm = new FormateurModule();
        fm.setFormateur(formateur);
        fm.setModule(module);
        fm.setDateAffectation(dto.getDateAffectation());

        return formateurModuleRepository.save(fm);
    }


    public List<AffectationFormateurModule> getAllAffectations() {
        return formateurModuleRepository.findAll()
                .stream()
                .map(AffectationFormateurModule::new)
                .collect(Collectors.toList());
    }



    public void supprimerAffectation(int id) {
        formateurModuleRepository.deleteById(id);
    }

    public List<Module> getModulesByFormateurId(Long formateurId) {
        return formateurModuleRepository.findModulesByFormateurId(formateurId);
    }


    public FormateurModule affecterFormateurModuleDirect(Long formateurId, int moduleId) {
        Formateur formateur = formateurRepository.findById(formateurId)
                .orElseThrow(() -> new RuntimeException("Formateur non trouvé"));
        Module module = moduleRepository.findById(moduleId)
                .orElseThrow(() -> new RuntimeException("Module non trouvé"));

        FormateurModule affectation = new FormateurModule();
        affectation.setFormateur(formateur);
        affectation.setModule(module);
        affectation.setDateAffectation(new Date());

        return formateurModuleRepository.save(affectation);
    }

}

