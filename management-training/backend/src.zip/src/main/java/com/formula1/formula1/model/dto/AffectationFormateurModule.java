package com.formula1.formula1.model.dto;

import com.formula1.formula1.model.Formateur;
import com.formula1.formula1.model.Module;
import com.formula1.formula1.model.FormateurModule;

import java.util.Date;



public class AffectationFormateurModule {
    private int id;
    private Date dateAffectation;
    private Formateur formateur;
    private Module module;

    public AffectationFormateurModule() {}

    public AffectationFormateurModule(FormateurModule fm) {
        this.id = fm.getId();
        this.dateAffectation = fm.getDateAffectation();
        this.formateur = fm.getFormateur();
        this.module = fm.getModule();
    }


    public Date getDateAffectation() {
        return dateAffectation;
    }

    public void setDateAffectation(Date dateAffectation) {
        this.dateAffectation = dateAffectation;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Formateur getFormateur() {
        return formateur;
    }

    public void setFormateur(Formateur formateur) {
        this.formateur = formateur;
    }

    public Module getModule() {
        return module;
    }

    public void setModule(Module module) {
        this.module = module;
    }
}
