package com.formula1.formula1.model.dto;

import java.util.List;

public class ParcoursDTO {
    private int id;
    private String nom;
    private String type;
    private int duree;
    private String description;
    private String profil;
    private List<AffectationCandidatParcours> candidatParcours;

    public ParcoursDTO(int id, String nom, String type, int duree, String description, String profil, List<AffectationCandidatParcours> candidatParcours) {
        this.id = id;
        this.nom = nom;
        this.type = type;
        this.duree = duree;
        this.description = description;
        this.profil = profil;
        this.candidatParcours = candidatParcours;
    }

    // Getters et setters


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getDuree() {
        return duree;
    }

    public void setDuree(int duree) {
        this.duree = duree;
    }

    public String getProfil() {
        return profil;
    }

    public void setProfil(String profil) {
        this.profil = profil;
    }

    public List<AffectationCandidatParcours> getCandidatParcours() {
        return candidatParcours;
    }

    public void setCandidatParcours(List<AffectationCandidatParcours> candidatParcours) {
        this.candidatParcours = candidatParcours;
    }
}
