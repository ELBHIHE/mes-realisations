package com.formula1.formula1.controller;

import com.formula1.formula1.model.dto.ProgressionDTO;
import com.formula1.formula1.model.dto.ProgressionRequest;
import com.formula1.formula1.model.dto.ProgressionStatusUpdateDTO;
import com.formula1.formula1.service.ProgressionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/api/progressions")
public class ProgressionController {

    @Autowired
    private ProgressionService progressionService;

    @PostMapping
    public ResponseEntity<ProgressionRequest> ajouter(@RequestBody ProgressionRequest dto) {
        return ResponseEntity.ok(progressionService.ajouterProgression(dto));
    }

    @GetMapping
    public List<ProgressionDTO> getAllProgressions() {
        return progressionService.getAllProgressions()
                .stream()
                .map(ProgressionDTO::new)
                .collect(Collectors.toList());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> supprimer(@PathVariable int id) {
        progressionService.supprimerProgression(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ProgressionDTO> updateProgressionStatus(@PathVariable int id, @RequestBody ProgressionStatusUpdateDTO statusUpdateDTO) {
        ProgressionDTO updatedProgression = progressionService.updateProgressionStatus(id, statusUpdateDTO);
        return ResponseEntity.ok(updatedProgression);
    }

    @GetMapping("/candidat/{id}")
    public ResponseEntity<List<ProgressionDTO>> getProgressionsByCandidat(@PathVariable("id") Long candidatId) {
        List<ProgressionDTO> progressions = progressionService.getProgressionsByCandidatId(candidatId);
        return ResponseEntity.ok(progressions);
    }


}

