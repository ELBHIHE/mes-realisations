package com.formula1.formula1.controller;


import com.formula1.formula1.model.CandidatSession;
import com.formula1.formula1.model.dto.AffectationRequest;
import com.formula1.formula1.model.dto.CandidatSessionDTO;
import com.formula1.formula1.model.dto.SessionDTO;
import com.formula1.formula1.service.CandidatSessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/affectationcandidatsession")
public class CandidatSessionController {

    @Autowired
    private CandidatSessionService service;

    @PostMapping("/affecter")
    public CandidatSession affecter(@RequestBody AffectationRequest request) {
        return service.affecterCandidatASession(
                request.getCandidatId(),
                request.getSessionId(),
                request.getDateAffectation()
        );
    }


    @GetMapping
    public List<CandidatSessionDTO> getAll() {
        return service.getAllAffectations();
    }

    @DeleteMapping("/{id}")
    public void supprimer(@PathVariable int id) {
        service.supprimerAffectation(id);
    }







    @GetMapping("/session/{sessionId}")
    public List<CandidatSessionDTO> getCandidatsBySession(@PathVariable int sessionId) {
        return service.getCandidatsBySession(sessionId);
    }

}
