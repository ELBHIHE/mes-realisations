package com.formula1.formula1.service;


import com.formula1.formula1.Repository.UtilisateurRepository;
import com.formula1.formula1.model.Administrateur;
import com.formula1.formula1.model.Utilisateur;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;


@Service
public class AuthService {

    @Autowired
    private UtilisateurRepository utilisateurRepository;

    @PostConstruct
    public void initAdmin() {
        Optional<Utilisateur> existingAdmin = utilisateurRepository.findByEmail("admin@capgemini.com");

        if (existingAdmin.isEmpty()) {
            Administrateur admin = new Administrateur();
            admin.setEmail("admin@capgemini.com");
            admin.setPassword("Chaimaa123!");
            admin.setNomComplet("Administrateur Principal");

            utilisateurRepository.save(admin);
        }
    }





    public Utilisateur login(String email, String password) {
        if (!email.endsWith("@capgemini.com")) {
            throw new RuntimeException("L'email doit se terminer par @capgemini.com");
        }

       /* if (!isValidPassword(password)) {
            throw new RuntimeException("Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule et un chiffre.");
        }*/

        Optional<Utilisateur> utilisateurOpt = utilisateurRepository.findByEmail(email);
        if (utilisateurOpt.isPresent()) {
            Utilisateur utilisateur = utilisateurOpt.get();
            if (utilisateur.getPassword().equals(password)) {
                return utilisateur;
            }
        }
        return null;
    }

    /*private boolean isValidPassword(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasUppercase = password.matches(".*[A-Z].*");
        boolean hasLowercase = password.matches(".*[a-z].*");
        boolean hasDigit = password.matches(".*\\d.*");
        boolean hasSpecialChar = password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?].*");

        return hasUppercase && hasLowercase && hasDigit && hasSpecialChar;
    }*/



}

