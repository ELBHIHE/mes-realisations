package com.formula1.formula1.service;

import com.formula1.formula1.Repository.CandidatParcoursRepository;
import com.formula1.formula1.Repository.CandidatRepository;
import com.formula1.formula1.Repository.ParcoursRepository;
import com.formula1.formula1.model.Candidat;
import com.formula1.formula1.model.CandidatParcours;
import com.formula1.formula1.model.Parcours;
import com.formula1.formula1.model.dto.CandidatAvecParcoursDTO;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class CandidatService {

    private final CandidatRepository candidatRepository;
    private final ParcoursRepository parcoursRepository;
    private final CandidatParcoursRepository candidatParcoursRepository;

    public CandidatService(CandidatRepository candidatRepository,
                           ParcoursRepository parcoursRepository,
                           CandidatParcoursRepository candidatParcoursRepository) {
        this.candidatRepository = candidatRepository;
        this.parcoursRepository = parcoursRepository;
        this.candidatParcoursRepository = candidatParcoursRepository;
    }

    public List<Candidat> getAllCandidats() {
        return candidatRepository.findAll();
    }

    public Optional<Candidat> getCandidatById(Long id) {
        return candidatRepository.findById(id);
    }

    public Candidat addCandidat(Candidat candidat) {
        // Sauvegarder le candidat
        Candidat savedCandidat = candidatRepository.save(candidat);

        // Rechercher un parcours avec le même profil
        Parcours parcours = parcoursRepository.findFirstByProfil(savedCandidat.getProfil());

        if (parcours != null) {
            // Créer l'affectation
            CandidatParcours affectation = new CandidatParcours();
            affectation.setCandidat(savedCandidat);
            affectation.setParcours(parcours);
            affectation.setDateAffectation(new Date());

            // Sauvegarder l'affectation
            candidatParcoursRepository.save(affectation);
        }

        return savedCandidat;
    }

    public Candidat updateCandidat(Long id, Candidat updatedCandidat) {
        return candidatRepository.findById(id)
                .map(c -> {
                    c.setNomComplet(updatedCandidat.getNomComplet());
                    c.setEmail(updatedCandidat.getEmail());
                    c.setPassword(updatedCandidat.getPassword());
                    c.setProfil(updatedCandidat.getProfil());
                    c.setDateEntree(updatedCandidat.getDateEntree());
                    return candidatRepository.save(c);
                })
                .orElseThrow(() -> new RuntimeException("Candidat non trouvé"));
    }

    public void deleteCandidat(Long id) {
        candidatRepository.deleteById(id);
    }


    public CandidatAvecParcoursDTO addCandidatEtAffecter(Candidat candidat) {
        Candidat savedCandidat = candidatRepository.save(candidat);
        Parcours parcours = parcoursRepository.findFirstByProfil(savedCandidat.getProfil());

        if (parcours != null) {
            CandidatParcours affectation = new CandidatParcours();
            affectation.setCandidat(savedCandidat);
            affectation.setParcours(parcours);
            affectation.setDateAffectation(new Date());
            candidatParcoursRepository.save(affectation);
        }

        return new CandidatAvecParcoursDTO(savedCandidat, parcours);
    }

}
