package com.formula1.formula1.model.enumeration;

public enum TypeParcours {
    FONDAMENTAL,
    TECHNIQUE
}
