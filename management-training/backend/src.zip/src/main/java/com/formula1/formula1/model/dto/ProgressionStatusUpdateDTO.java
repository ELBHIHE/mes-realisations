package com.formula1.formula1.model.dto;

import com.formula1.formula1.model.enumeration.Status;

public class ProgressionStatusUpdateDTO {
    private Status status;

    // No-args constructor (optional, but good practice for Jackson)
    public ProgressionStatusUpdateDTO() {
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}