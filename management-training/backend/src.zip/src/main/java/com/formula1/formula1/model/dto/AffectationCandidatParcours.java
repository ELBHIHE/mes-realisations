package com.formula1.formula1.model.dto;

import com.formula1.formula1.model.CandidatParcours;

import java.util.Date;

public class AffectationCandidatParcours {
    private int id;
    private Long candidatId;
    private int parcoursId;
    private Date dateAffectation;


    public AffectationCandidatParcours(CandidatParcours cp) {
        this.id = cp.getId();
        this.dateAffectation = cp.getDateAffectation();
        this.candidatId = cp.getCandidat().getId();
        this.parcoursId = cp.getParcours().getId();
    }


    public int getParcoursId() {
        return parcoursId;
    }

    public void setParcoursId(int parcoursId) {
        this.parcoursId = parcoursId;
    }

    public Long getCandidatId() {
        return candidatId;
    }

    public void setCandidatId(Long candidatId) {
        this.candidatId = candidatId;
    }

    public Date getDateAffectation() {
        return dateAffectation;
    }

    public void setDateAffectation(Date dateAffectation) {
        this.dateAffectation = dateAffectation;
    }
}

