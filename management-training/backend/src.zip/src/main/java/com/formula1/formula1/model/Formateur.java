package com.formula1.formula1.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.CascadeType;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;

import java.util.List;

@Entity
@JsonIgnoreProperties("formateur-formateurModules")
@DiscriminatorValue("FORMATEUR")
public class Formateur extends Utilisateur {

    private String profil;


    @OneToMany(mappedBy = "formateur", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("formateur-sessions")
    private List<Session> sessions;

    @OneToMany(mappedBy = "formateur", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("formateur-formateurModules")
    private List<FormateurModule> formateurModules;


    public String getProfil() {
        return profil;
    }

    public void setProfil(String profil) {
        this.profil = profil;
    }

}
