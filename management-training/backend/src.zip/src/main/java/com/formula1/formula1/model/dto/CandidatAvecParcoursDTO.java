package com.formula1.formula1.model.dto;

import com.formula1.formula1.model.Candidat;
import com.formula1.formula1.model.Parcours;

public class CandidatAvecParcoursDTO {
    private Candidat candidat;
    private Parcours parcours;

    public CandidatAvecParcoursDTO(Candidat candidat, Parcours parcours) {
        this.candidat = candidat;
        this.parcours = parcours;
    }

    public Candidat getCandidat() {
        return candidat;
    }

    public void setCandidat(Candidat candidat) {
        this.candidat = candidat;
    }

    public Parcours getParcours() {
        return parcours;
    }

    public void setParcours(Parcours parcours) {
        this.parcours = parcours;
    }

    // Getters et setters
}

