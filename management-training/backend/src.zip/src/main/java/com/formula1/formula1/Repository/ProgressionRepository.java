package com.formula1.formula1.Repository;

import com.formula1.formula1.model.Progression;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProgressionRepository extends JpaRepository<Progression, Integer> {
    @Query("SELECT p FROM Progression p JOIN FETCH p.candidat JOIN FETCH p.module WHERE p.candidat.id = :candidatId")
    List<Progression> findByCandidatId(@Param("candidatId") Long candidatId);
}
