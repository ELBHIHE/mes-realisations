package com.formula1.formula1.controller;

import com.formula1.formula1.model.Session;
import com.formula1.formula1.model.dto.SessionDTO;
import com.formula1.formula1.service.SessionService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sessions")
public class SessionController {

    private final SessionService sessionService;

    public SessionController(SessionService sessionService) {
        this.sessionService = sessionService;
    }

    @GetMapping
    public List<SessionDTO> getAllSessions() {
        return sessionService.getAllSessions();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Session> getSessionById(@PathVariable int id) {
        return sessionService.getSessionById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Session addSession(@RequestBody Session session) {
        return sessionService.addSession(session);
    }

    @PutMapping("/{id}")
    public Session updateSession(@PathVariable int id, @RequestBody Session session) {
        return sessionService.updateSession(id, session);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSession(@PathVariable int id) {
        sessionService.deleteSession(id);
        return ResponseEntity.noContent().build();
    }

    //Pour récupérer les sessions du formateur connecté
    @GetMapping("/formateur/{id}")
    public ResponseEntity<List<SessionDTO>> getSessionsByFormateur(@PathVariable("id") int id) {
        List<SessionDTO> sessionDTOs = sessionService.getSessionsByFormateurId(id);
        return ResponseEntity.ok(sessionDTOs);
    }

    //Pour récupérer les sessions du Candidat connecté
    @GetMapping("/candidat/{id}")
    public ResponseEntity<List<SessionDTO>> getSessionsByCandidat(@PathVariable("id") int id) {
        List<SessionDTO> sessionDTOs = sessionService.getSessionsByCandidatId(id);
        return ResponseEntity.ok(sessionDTOs);
    }
}