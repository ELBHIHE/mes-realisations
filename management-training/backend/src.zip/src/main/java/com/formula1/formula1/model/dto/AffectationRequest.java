package com.formula1.formula1.model.dto;

import com.formula1.formula1.model.CandidatSession;

import java.util.Date;

public class AffectationRequest {
    private Long candidatId;
    private int sessionId;

    private int id;
    private Date dateAffectation;


    // ✅ Constructeur par défaut requis pour Jackson
    public AffectationRequest() {
    }


    public AffectationRequest(CandidatSession cs) {
        this.id = cs.getId();
        this.dateAffectation = cs.getDateAffectation();
        this.candidatId = cs.getCandidat().getId();
        this.sessionId = cs.getSession().getId();
    }

    public Date getDateAffectation() {
        return dateAffectation;
    }

    public void setDateAffectation(Date dateAffectation) {
        this.dateAffectation = dateAffectation;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Long getCandidatId() {
        return candidatId;
    }

    public void setCandidatId(Long candidatId) {
        this.candidatId = candidatId;
    }


    public int getSessionId() {
        return sessionId;
    }

    public void setSessionId(int sessionId) {
        this.sessionId = sessionId;
    }
}