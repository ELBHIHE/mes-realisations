package com.formula1.formula1.service;



import com.formula1.formula1.Repository.CandidatRepository;
import com.formula1.formula1.Repository.CandidatSessionRepository;
import com.formula1.formula1.Repository.ProgressionRepository;
import com.formula1.formula1.Repository.SessionRepository;
import com.formula1.formula1.model.Candidat;
import com.formula1.formula1.model.Progression;
import com.formula1.formula1.model.Session;
import com.formula1.formula1.model.CandidatSession;

import com.formula1.formula1.model.dto.AffectationRequest;
import com.formula1.formula1.model.dto.CandidatSessionDTO;
import com.formula1.formula1.model.enumeration.Status;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CandidatSessionService {

    @Autowired
    private CandidatSessionRepository candidatSessionRepository;

    @Autowired
    private CandidatRepository candidatRepository;

    @Autowired
    private SessionRepository sessionRepository;

    @Autowired
    private ProgressionRepository progressionRepository;

    public CandidatSession affecterCandidatASession(Long candidatId, int sessionId,  Date dateAffectation) {
        Candidat candidat = candidatRepository.findById(candidatId)
                .orElseThrow(() -> new RuntimeException("Candidat introuvable"));
        Session session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new RuntimeException("Session introuvable"));

        // Création de l'affectation
        CandidatSession cs = new CandidatSession();
        cs.setCandidat(candidat);
        cs.setSession(session);
        cs.setDateAffectation(dateAffectation);
        CandidatSession savedAffectation = candidatSessionRepository.save(cs);

        // Création de la progression associée avec statut NON_COMMENCE
        Progression progression = new Progression();
        progression.setCandidat(candidat);
        progression.setModule(session.getModule());
        progression.setStatus(Status.NON_COMMENCE);
        progression.setDateDebut(null);
        progression.setDateFin(null);
        progressionRepository.save(progression);

        return savedAffectation;
    }


    public List<CandidatSessionDTO> getAllAffectations() {
        return candidatSessionRepository.findAll()
                .stream()
                .map(CandidatSessionDTO::new)
                .collect(Collectors.toList());
    }




    public void supprimerAffectation(int id) {
        candidatSessionRepository.deleteById(id);
    }




    public List<CandidatSessionDTO> getCandidatsBySession(int sessionId) {
        List<CandidatSession> affectations = candidatSessionRepository.findBySessionId(sessionId);
        return affectations.stream()
                .map(CandidatSessionDTO::new) // Utilise le constructeur que tu as déjà
                .collect(Collectors.toList());
    }





}

