package com.formula1.formula1.service;

import com.formula1.formula1.Repository.RhManagerRepository;
import com.formula1.formula1.model.RH_Manager;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RhManagerService {

    private final RhManagerRepository rhManagerRepository;

    public RhManagerService(RhManagerRepository rhManagerRepository) {
        this.rhManagerRepository = rhManagerRepository;
    }

    public List<RH_Manager> getAllRhManagers() {
        return rhManagerRepository.findAll();
    }

    public Optional<RH_Manager> getRhManagerById(Long id) {
        return rhManagerRepository.findById(id);
    }

    public RH_Manager addRhManager(RH_Manager rhManager) {
        return rhManagerRepository.save(rhManager);
    }

    public RH_Manager updateRhManager(Long id, RH_Manager updatedRhManager) {
        return rhManagerRepository.findById(id)
                .map(rh -> {
                    rh.setNomComplet(updatedRhManager.getNomComplet());
                    rh.setEmail(updatedRhManager.getEmail());
                    rh.setPassword(updatedRhManager.getPassword());
                    return rhManagerRepository.save(rh);
                })
                .orElseThrow(() -> new RuntimeException("RH Manager non trouvé"));
    }

    public void deleteRhManager(Long id) {
        rhManagerRepository.deleteById(id);
    }
}
