package com.formula1.formula1.Repository;


import com.formula1.formula1.model.CandidatSession;
import com.formula1.formula1.model.Module;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CandidatSessionRepository extends JpaRepository<CandidatSession, Integer> {


    @Query("SELECT DISTINCT cs.session.module FROM CandidatSession cs WHERE cs.candidat.id = :candidatId")
    List<Module> findModulesByCandidatId(@Param("candidatId") int candidatId);



    List<CandidatSession> findBySessionId(int sessionId);
    List<CandidatSession> findByCandidatId(int candidatId);

}

