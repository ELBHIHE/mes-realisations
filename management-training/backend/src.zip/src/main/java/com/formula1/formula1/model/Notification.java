package com.formula1.formula1.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

@Entity
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String message;

    @ManyToOne
    @JoinColumn(name = "utilisateur_id")
    @JsonBackReference("notification-user")
    private Utilisateur destinataire;

    // Getters et Setters
}