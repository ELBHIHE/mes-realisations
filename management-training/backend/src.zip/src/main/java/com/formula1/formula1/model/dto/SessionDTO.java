package com.formula1.formula1.model.dto;

import java.util.Date;

public class SessionDTO {
    private int id;
    private Date dateSession;
    private String salleOuLien;
    private FormateurDTO formateur;
    private ModuleDTO module;

    public SessionDTO(int id, Date dateSession, String salleOuLien, FormateurDTO formateur, ModuleDTO module) {
        this.id = id;
        this.dateSession = dateSession;
        this.salleOuLien = salleOuLien;
        this.formateur = formateur;
        this.module = module;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDateSession() {
        return dateSession;
    }

    public void setDateSession(Date dateSession) {
        this.dateSession = dateSession;
    }

    public String getSalleOuLien() {
        return salleOuLien;
    }

    public void setSalleOuLien(String salleOuLien) {
        this.salleOuLien = salleOuLien;
    }

    public FormateurDTO getFormateur() {
        return formateur;
    }

    public void setFormateur(FormateurDTO formateur) {
        this.formateur = formateur;
    }

    public ModuleDTO getModule() {
        return module;
    }

    public void setModule(ModuleDTO module) {
        this.module = module;
    }

    public static class FormateurDTO {
        private Long id;
        private String nomComplet;

        public FormateurDTO(Long id, String nomComplet) {
            this.id = id;
            this.nomComplet = nomComplet;
        }

        // Getters and setters
        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getNomComplet() {
            return nomComplet;
        }

        public void setNomComplet(String nomComplet) {
            this.nomComplet = nomComplet;
        }
    }

    public static class ModuleDTO {
        private int id;
        private String nom;

        public ModuleDTO(int id, String nom) {
            this.id = id;
            this.nom = nom;
        }

        // Getters and setters
        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getNom() {
            return nom;
        }

        public void setNom(String nom) {
            this.nom = nom;
        }
    }
}
