package com.formula1.formula1.service;


import com.formula1.formula1.Repository.CandidatSessionRepository;
import com.formula1.formula1.Repository.ModuleRepository;


import com.formula1.formula1.model.Module;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ModuleService {

    @Autowired
    private ModuleRepository moduleRepository;



    @Autowired
    private CandidatSessionRepository candidatSessionRepository;

    public List<Module> getModulesForCandidat(int candidatId) {
        return candidatSessionRepository.findModulesByCandidatId(candidatId);
    }


    public Module createModule(Module module) {
        return moduleRepository.save(module);
    }

    public Module getModuleById(int id) {
        return moduleRepository.findById(id).orElse(null);
    }

    public List<Module> getAllModules() {
        return moduleRepository.findAll();
    }

    public Module updateModule(int id, Module moduleDetails) {
        Optional<Module> optionalModule = moduleRepository.findById(id);
        if (optionalModule.isPresent()) {
            Module module = optionalModule.get();
            module.setNom(moduleDetails.getNom());
            module.setDuree(moduleDetails.getDuree());
            module.setContenu(moduleDetails.getContenu());
            module.setParcours(moduleDetails.getParcours());
            return moduleRepository.save(module);
        }
        return null;
    }

    public void deleteModule(int id) {
        moduleRepository.deleteById(id);
    }
}
