package com.formula1.formula1.service;

import com.formula1.formula1.Repository.CandidatParcoursRepository;
import com.formula1.formula1.Repository.CandidatRepository;
import com.formula1.formula1.Repository.ParcoursRepository;
import com.formula1.formula1.model.Candidat;
import com.formula1.formula1.model.CandidatParcours;
import com.formula1.formula1.model.CandidatSession;
import com.formula1.formula1.model.Parcours;
import com.formula1.formula1.model.dto.AffectationCandidatParcours;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CandidatParcoursService {

    @Autowired
    private CandidatParcoursRepository candidatParcoursRepository;

    @Autowired
    private CandidatRepository candidatRepository;

    @Autowired
    private ParcoursRepository parcoursRepository;

    public CandidatParcours affecterCandidatParcours(AffectationCandidatParcours dto) {
        Candidat candidat = candidatRepository.findById(dto.getCandidatId())
                .orElseThrow(() -> new RuntimeException("Candidat non trouvé"));
        Parcours parcours = parcoursRepository.findById(dto.getParcoursId())
                .orElseThrow(() -> new RuntimeException("Parcours non trouvé"));

        CandidatParcours cp = new CandidatParcours();
        cp.setCandidat(candidat);
        cp.setParcours(parcours);
        cp.setDateAffectation(dto.getDateAffectation());

        return candidatParcoursRepository.save(cp);
    }


    public List<AffectationCandidatParcours> getAllAffectations() {
        return candidatParcoursRepository.findAll()
                .stream()
                .map(AffectationCandidatParcours::new)
                .collect(Collectors.toList());
    }


    public void supprimerAffectation(int id) {
        candidatParcoursRepository.deleteById(id);
    }
}

