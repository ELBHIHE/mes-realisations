package com.formula1.formula1.controller;

import com.formula1.formula1.model.FormateurModule;
import com.formula1.formula1.model.Module;
import com.formula1.formula1.model.dto.AffectationFormateurModule;
import com.formula1.formula1.model.dto.AffectationFormateurModuleDTO;
import com.formula1.formula1.model.dto.AffectationRequest;
import com.formula1.formula1.service.FormateurModuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/formateur-modules")
public class FormateurModuleController {

    @Autowired
    private FormateurModuleService service;

    @PostMapping("/affecter")
    public ResponseEntity<AffectationFormateurModule> affecter(@RequestBody AffectationFormateurModuleDTO request) {
        FormateurModule saved = service.affecterFormateurModule(request);
        return ResponseEntity.ok(new AffectationFormateurModule(saved));
    }

    @GetMapping("/{formateurId}")
    public ResponseEntity<List<Module>> getModulesForFormateur(@PathVariable Long formateurId) {
        List<Module> modules = service.getModulesByFormateurId(formateurId);
        return ResponseEntity.ok(modules);
    }

    @GetMapping
    public ResponseEntity<List<AffectationFormateurModule>> getAll() {
        return ResponseEntity.ok(service.getAllAffectations());
    }



    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        service.supprimerAffectation(id);
        return ResponseEntity.noContent().build();
    }
}
