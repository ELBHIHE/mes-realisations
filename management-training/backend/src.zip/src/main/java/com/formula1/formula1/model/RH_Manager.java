package com.formula1.formula1.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("RH")
public class RH_Manager extends Utilisateur {

    // Getters et Setters
}

