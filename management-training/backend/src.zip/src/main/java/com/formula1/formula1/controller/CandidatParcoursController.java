package com.formula1.formula1.controller;

import com.formula1.formula1.model.CandidatParcours;
import com.formula1.formula1.model.dto.AffectationCandidatParcours;
import com.formula1.formula1.service.CandidatParcoursService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/affectationcandidatparcours")
public class CandidatParcoursController {

    @Autowired
    private CandidatParcoursService service;

    @PostMapping("/affecter")
    public CandidatParcours affecterCandidat(@RequestBody AffectationCandidatParcours dto) {
        return service.affecterCandidatParcours(dto);
    }

    @GetMapping
    public List<AffectationCandidatParcours> getAll() {
        return service.getAllAffectations();
    }

    @DeleteMapping("/{id}")
    public void supprimer(@PathVariable int id) {
        service.supprimerAffectation(id);
    }

}
