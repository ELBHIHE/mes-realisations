package com.formula1.formula1.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

import java.util.Date;

@Entity
public class Certificat {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String nom;
    private Date dateObtention;
    @ManyToOne
    @JoinColumn(name = "module_id")
    @JsonBackReference("module-certificat")
    private Module module;


}

