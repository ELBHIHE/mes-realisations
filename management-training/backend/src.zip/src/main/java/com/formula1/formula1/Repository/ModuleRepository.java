package com.formula1.formula1.Repository;


import com.formula1.formula1.model.Module;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModuleRepository extends JpaRepository<Module, Integer> {
}
