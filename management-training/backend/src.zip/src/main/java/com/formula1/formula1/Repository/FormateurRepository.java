package com.formula1.formula1.Repository;


import com.formula1.formula1.model.Formateur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FormateurRepository extends JpaRepository<Formateur, Long> {


}

