package com.formula1.formula1.Repository;

import com.formula1.formula1.model.RH_Manager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RhManagerRepository extends JpaRepository<RH_Manager, Long> {
}
