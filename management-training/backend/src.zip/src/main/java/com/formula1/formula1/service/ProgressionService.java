package com.formula1.formula1.service;

import com.formula1.formula1.Repository.CandidatRepository;
import com.formula1.formula1.Repository.ModuleRepository;
import com.formula1.formula1.Repository.ProgressionRepository;
import com.formula1.formula1.model.Candidat;
import com.formula1.formula1.model.Module;
import com.formula1.formula1.model.Progression;
import com.formula1.formula1.model.dto.ProgressionDTO;
import com.formula1.formula1.model.dto.ProgressionRequest;
import com.formula1.formula1.model.dto.ProgressionStatusUpdateDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProgressionService {

    @Autowired
    private ProgressionRepository progressionRepository;

    @Autowired
    private CandidatRepository candidatRepository;

    @Autowired
    private ModuleRepository moduleRepository;

    public ProgressionRequest ajouterProgression(ProgressionRequest dto) {
        Candidat candidat = candidatRepository.findById(dto.getCandidatId())
                .orElseThrow(() -> new RuntimeException("Candidat non trouvé"));
        Module module = moduleRepository.findById(dto.getModuleId())
                .orElseThrow(() -> new RuntimeException("Module non trouvé"));

        Progression progression = new Progression();
        progression.setStatus(dto.getStatus());
        progression.setDateDebut(dto.getDateDebut());
        progression.setDateFin(dto.getDateFin());
        progression.setCommentaire(dto.getCommentaire());
        progression.setEvaluation(dto.getEvaluation());
        progression.setCandidat(candidat);
        progression.setModule(module);

        Progression saved = progressionRepository.save(progression);
        dto.setId(saved.getId());
        return dto;
    }

    public List<Progression> getAllProgressions() {
        return progressionRepository.findAll();
    }

    public void supprimerProgression(int id) {
        progressionRepository.deleteById(id);
    }

    private ProgressionRequest toDTO(Progression progression) {
        ProgressionRequest dto = new ProgressionRequest();
        dto.setId(progression.getId());
        dto.setStatus(progression.getStatus());
        dto.setDateDebut(progression.getDateDebut());
        dto.setDateFin(progression.getDateFin());
        dto.setCommentaire(progression.getCommentaire());
        dto.setEvaluation(progression.getEvaluation());
        dto.setCandidatId(progression.getCandidat().getId());
        dto.setModuleId(progression.getModule().getId());
        return dto;
    }


    public ProgressionDTO updateProgressionStatus(int id, ProgressionStatusUpdateDTO statusUpdateDTO) {
        Progression progression = progressionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Progression non trouvée"));
        progression.setStatus(statusUpdateDTO.getStatus());
        Progression updated = progressionRepository.save(progression);
        return new ProgressionDTO(updated);
    }

    public List<ProgressionDTO> getProgressionsByCandidatId(Long candidatId) {
        candidatRepository.findById(candidatId)
                .orElseThrow(() -> new RuntimeException("Candidat non trouvé"));
        return progressionRepository.findByCandidatId(candidatId)
                .stream()
                .map(ProgressionDTO::new)
                .collect(Collectors.toList());
    }
}

