import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ParcoursComponent } from './components/parcours/parcours.component';
import { ParcoursFormComponent } from './components/parcours-form/parcours-form.component';
 
import { CandidatListComponent } from './components/candidat-list1/candidat-list';
import { FormateurListComponent } from './components/formateur-list1/formateur-list';
import { RHManagerListComponent } from './components/rh-manager-list1/rh-manager-list';
import { HomeComponent } from './components/home1/home';
import { ModuleComponent } from './components/module/module.component';
import { CandidatModulesComponent } from './components/candidat-modules/candidat-modules.component';
import { FormateurModulesComponent } from './components/formateur-modules/formateur-modules.component';
import { FormateurSessionsComponent } from './components/formateur-sessions/formateur-sessions.component';
import { CandidatSessionsComponent } from './components/candidat-sessions/candidat-sessions.component';
import { CandidatProgressionComponent } from './components/candidat-progression/candidat-progression.component';
import { AuthGuard } from './guards/auth.guard';
import { RoleGuard } from './guards/role.guard';
import { TableauBordComponent } from './components/tableau-bord/tableau-bord.component';
 
export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
 
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', component: TableauBordComponent },
      { path: 'users', component: HomeComponent, canActivate: [RoleGuard], data: { roles: ['RH', 'ADMIN'] } },
      { path: 'parcours', component: ParcoursComponent, canActivate: [RoleGuard], data: { roles: ['RH', 'ADMIN', 'FORMATEUR'] } },
      { path: 'modules', component: ModuleComponent, canActivate: [RoleGuard], data: { roles: ['RH', 'ADMIN', 'FORMATEUR'] } },
      { path: 'parcours/new', component: ParcoursFormComponent, canActivate: [RoleGuard], data: { roles: ['RH', 'ADMIN', 'FORMATEUR'] } },
      { path: 'parcours/edit/:id', component: ParcoursFormComponent, canActivate: [RoleGuard], data: { roles: ['RH', 'ADMIN', 'FORMATEUR'] } },
      { path: 'home', component: HomeComponent },
      { path: 'candidats', component: CandidatListComponent, canActivate: [RoleGuard], data: { roles: ['RH', 'ADMIN', 'FORMATEUR'] } },
      { path: 'formateurs', component: FormateurListComponent, canActivate: [RoleGuard], data: { roles: ['RH', 'ADMIN'] } },
      { path: 'rh-managers', component: RHManagerListComponent, canActivate: [RoleGuard], data: { roles: ['ADMIN'] } },
      { path: 'mes-modules', component: CandidatModulesComponent, canActivate: [RoleGuard], data: { roles: ['CANDIDAT'] } },
      { path: 'formateur-modules', component: FormateurModulesComponent, canActivate: [RoleGuard], data: { roles: ['FORMATEUR'] } },
      { path: 'formateur-sessions', component: FormateurSessionsComponent, canActivate: [RoleGuard], data: { roles: ['FORMATEUR'] } },
      { path: 'candidat-sessions', component: CandidatSessionsComponent, canActivate: [RoleGuard], data: { roles: ['CANDIDAT'] } },
      { path: 'candidat-progressions', component: CandidatProgressionComponent, canActivate: [RoleGuard], data: { roles: ['CANDIDAT'] } }
    ]
  }
];