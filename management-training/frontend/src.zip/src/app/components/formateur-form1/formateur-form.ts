import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { Formateur } from '../../models/formateur.model';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCard } from '@angular/material/card';


@Component({
  selector: 'app-formateur-form',
  templateUrl: './formateur-form.component.html',
  styleUrls: ['./formateur-form.scss'],
  standalone : true,
  imports: [
     MatDialogModule,
      MatFormFieldModule,
      MatInputModule,
      FormsModule,
      MatDatepickerModule,
      MatNativeDateModule,
      MatIconModule,
      MatTableModule,
      CommonModule,
      MatCard
    ],
})
export class FormateurFormComponent {
  formateur: Formateur;
  constructor(
    public dialogRef: MatDialogRef<FormateurFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { formateur: Formateur }
  ) {
    this.formateur = { ...data.formateur};
  }


  

  onSubmit(): void {
    this.dialogRef.close(this.formateur);
  }

  onCancel(): void {
    this.dialogRef.close();
  }
}