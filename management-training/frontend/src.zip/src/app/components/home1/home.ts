import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.scss'],
  standalone : true,
  
  imports: [
      // autres modules
      MatCardModule,
      CommonModule
    ]

})
export class HomeComponent {
  user:any;
  constructor(private router: Router) {}

  ngOnInit(): void {
    const userData = localStorage.getItem('user');
    if (userData) {
      this.user = JSON.parse(userData);
    }
  }


  navigateTo(path: string): void {
    this.router.navigate([`/dashboard/${path}`]);
  }
}