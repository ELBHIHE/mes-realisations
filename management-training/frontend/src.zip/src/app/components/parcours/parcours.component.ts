import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { Parcours } from '../../models/parcours.model';
import { ParcoursService } from '../../services/parcours/parcours.service';
import { RouterModule } from '@angular/router';
import { MatCard } from '@angular/material/card';



@Component({
  selector: 'app-parcours',
  standalone: true,
  styleUrls: ['./parcours.component.scss'],
  imports: [
    CommonModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    RouterModule,
    MatCard
  ],
  templateUrl: './parcours.component.html',
})
export class ParcoursComponent implements OnInit {
  parcoursList: Parcours[] = [];
  displayedColumns: string[] = ['nom', 'type','profil', 'duree', 'actions'];

  constructor(
    private parcoursService: ParcoursService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.parcoursService.getAll().subscribe(data => this.parcoursList = data);
  }

  edit(parcours: Parcours) {
    this.router.navigate(['/dashboard/parcours/edit', parcours.id]);
  }

  delete(id: number) {
    this.parcoursService.delete(id).subscribe(() => {
      this.parcoursList = this.parcoursList.filter(p => p.id !== id);
    });
  }

  openForm() {
    this.router.navigate(['/dashboard/parcours/new']);
  }
}
