import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSortModule } from '@angular/material/sort';
import { MatInputModule } from '@angular/material/input';

import { CertificatDTO } from '../../models/CertificatDTO.model';
import { Module } from '../../models/module.model';
import { Candidat } from '../../models/candidat.model';
import { ProgressionDTO } from '../../models/ProgressionDTO.model';


import { FormateurModuleService } from '../../services/formateur-module/formateur-module.service';
import { SessionService, Session } from '../../services/session/session.service';
import { UtilisateurService } from '../../services/utilisateur/utilisateur';
import { ProgressionService } from '../../services/progression/progression.service';
import { StatistiquesService } from '../../services/stats/statistiques-service.service';

import jsPDF from 'jspdf';
import { StatistiquesUtilisateurs } from '../../models/StatistiquesUtilisateurs.model';
import { MatIconButton } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-tableau-bord',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatTableModule,
    MatSortModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule
  ],
  templateUrl: './tableau-bord.component.html',
  styleUrls: ['./tableau-bord.component.scss']
})
export class TableauBordComponent implements OnInit {
  modules: Module[] = [];
  sessions: Session[] = [];
  candidats: Candidat[] = [];
  progressions: ProgressionDTO[] = [];
  stats!: StatistiquesUtilisateurs;
  searchCandidatTerm: string = '';
  user: any = {};
  candidatId!: number;

  constructor(
    private formateurModuleService: FormateurModuleService,
    private sessionService: SessionService,
    private utilisateurService: UtilisateurService,
    private progressionService: ProgressionService,
    private statistiquesService: StatistiquesService
  ) {}

  ngOnInit(): void {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      this.user = JSON.parse(userStr);
      this.candidatId = this.user?.id;
      this.loadModules();
      this.loadSessions();
      this.loadCandidats();
      this.loadProgressions();
      this.loadStats();
    }
  }

  loadModules(): void {
    const formateurId = this.user?.id;
    if (formateurId) {
      this.formateurModuleService.getModulesByFormateurId(formateurId).subscribe({
        next: (data) => this.modules = data,
        error: (err) => console.error('Erreur chargement modules', err)
      });
    }
  }

  loadSessions(): void {
    const formateurId = this.user?.id;
    if (formateurId) {
      this.sessionService.getSessionsByFormateurId(formateurId).subscribe({
        next: (data) => this.sessions = data,
        error: (err) => console.error('Erreur chargement sessions', err)
      });
    }
  }

  loadCandidats(): void {
    this.utilisateurService.getAllCandidats().subscribe({
      next: (data) => this.candidats = data,
      error: (err) => console.error('Erreur chargement candidats', err)
    });
  }

  loadProgressions(): void {
    this.progressionService.getProgressionsByCandidatId(this.candidatId).subscribe({
      next: (res) => this.progressions = res,
      error: (err) => console.error('Erreur chargement progressions', err)
    });
  }

  loadStats(): void {
    this.statistiquesService.getStats().subscribe({
      next: (data) => this.stats = data,
      error: (err) => console.error('Erreur chargement statistiques', err)
    });
  }

  filteredCandidats(): Candidat[] {
    const term = this.searchCandidatTerm.toLowerCase();
    return this.candidats.filter(candidat =>
      candidat.nomComplet.toLowerCase().includes(term) ||
      candidat.email.toLowerCase().includes(term) ||
      candidat.profil.toLowerCase().includes(term)
    );
  }

  getStatusClass(status: string): string {
    switch (status.toUpperCase()) {
      case 'EN COURS': return 'status-en-cours';
      case 'TERMINE': return 'status-termine';
      case 'NON DEMARRE': return 'status-non-demarre';
      default: return '';
    }
  }

  genererCertificat(progressionId: number): void {
    this.progressionService.getCertificat(progressionId).subscribe({
      next: async (cert: CertificatDTO) => {
        const doc = new jsPDF();
        const logo = await this.loadImage('assets/capgemini_logo.png');
        doc.addImage(logo, 'PNG', 150, 10, 40, 20);
        doc.setFontSize(18);
        doc.text('Certificat de Réussite', 60, 40);
        doc.setFontSize(12);
        doc.text(`Candidat : ${cert.nomCandidat}`, 20, 60);
        doc.text(`Module : ${cert.nomModule}`, 20, 70);
        doc.text(`Date de fin : ${new Date(cert.dateFin).toLocaleDateString()}`, 20, 80);
        doc.text(`Évaluation : ${cert.evaluation}`, 20, 90);
        doc.setFontSize(10);
        doc.text('Félicitations pour votre réussite !', 20, 110);
        doc.save(`certificat_${cert.nomCandidat}_${cert.nomModule}.pdf`);
      },
      error: (err) => console.error('Erreur génération certificat', err)
    });
  }

  loadImage(url: string): Promise<string> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'Anonymous';
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0);
        resolve(canvas.toDataURL('image/png'));
      };
      img.onerror = reject;
      img.src = url;
    });
  }

  hasCertificats(): boolean {
    return this.progressions?.some(p => p.status === 'TERMINE');
  }

formatProfilClass(profil: string): string {
  return profil.trim()
               .replace(/\./g, '-')     // remplace le point par un tiret
               .replace(/\s+/g, '-')    // remplace les espaces par un tiret
               .replace(/-+/g, '-')     // fusionne les doubles tirets
               .toLowerCase();
}

}
