import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, MatOptionModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { AffectationFormateurModule } from '../../models/affectation-formateur-module.model';
import { MatCard } from '@angular/material/card';
import { CommonModule } from '@angular/common';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
 
interface Session {
  dateDebut: Date;
  dateFin: Date;
  salleOuLien: string;
  formateur: any;
  module: any;
}
 
@Component({
  selector: 'app-session-form',
  templateUrl: './session-form.component.html',
   styleUrls: ['./session-form.component.scss'],
  standalone: true,
  imports: [
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    FormsModule,
    MatCard,
    CommonModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatOptionModule
  ]
})
export class SessionFormComponent implements OnInit {
  session!: Session;

 sessionForm!: FormGroup;

constructor(
  private fb: FormBuilder,
  public dialogRef: MatDialogRef<SessionFormComponent>,
  @Inject(MAT_DIALOG_DATA) public data: { affectation: AffectationFormateurModule }
) {}

ngOnInit(): void {
  this.sessionForm = this.fb.group({
    typeSession: ['presentiel', Validators.required],
    salleOuLien: ['', Validators.required],
    dateDebut: [new Date(), Validators.required],
    dateFin: [new Date(), Validators.required],
    formateur: [this.data.affectation.formateur],
    module: [this.data.affectation.module]
  });
}

 
  onSubmit(): void {
  if (this.sessionForm.valid) {
    const session: Session = {
      dateDebut: this.sessionForm.value.dateDebut,
      dateFin: this.sessionForm.value.dateFin,
      salleOuLien: this.sessionForm.value.salleOuLien,
      formateur: this.sessionForm.value.formateur,
      module: this.sessionForm.value.module
    };
    this.dialogRef.close(session);
  }
}

 
  onCancel(): void {
    this.dialogRef.close();
  }


  onTypeSessionChange(): void {
    const type = this.sessionForm.value.typeSession;

    const salleOuLienControl = this.sessionForm.get('salleOuLien');
    if (type === 'online') {
      salleOuLienControl?.setValidators([
        Validators.required,
        Validators.pattern('https?://.+') // simple validation de lien
      ]);
    } else {
      salleOuLienControl?.setValidators([Validators.required]);
    }
    salleOuLienControl?.updateValueAndValidity();
  }


onPlatformChange(event: MatSelectChange): void {
  const selectedUrl = event.value;

  if (selectedUrl && confirm('Voulez-vous ouvrir la plateforme pour créer une réunion ?')) {
    window.open(selectedUrl, '_blank');
  }

  // Met à jour le champ salleOuLien dans le formulaire
  this.sessionForm.get('salleOuLien')?.setValue(selectedUrl);
}



}
 