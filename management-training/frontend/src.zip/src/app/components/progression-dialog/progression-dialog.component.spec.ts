import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgressionDialogComponent } from './progression-dialog.component';

describe('ProgressionDialogComponent', () => {
  let component: ProgressionDialogComponent;
  let fixture: ComponentFixture<ProgressionDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProgressionDialogComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProgressionDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
