import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CommonModule, DatePipe } from '@angular/common';

import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms';

import { ProgressionService } from '../../services/progression/progression.service';
import { ProgressionDTO } from '../../models/ProgressionDTO.model';

@Component({
  selector: 'app-progression-dialog',
  templateUrl: './progression-dialog.component.html',
  styleUrls: ['./progression-dialog.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    FormsModule
  ],
  providers: [DatePipe]
})
export class ProgressionDialogComponent implements OnInit {
  progressions: (ProgressionDTO & { editMode?: boolean })[] = [];

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { candidatId: number },
    private progressionService: ProgressionService
  ) {}

  ngOnInit(): void {
    this.progressionService.getProgressionsByCandidatId(this.data.candidatId).subscribe({
      next: (res) => {
        this.progressions = res.map(p => ({ ...p, editMode: false }));
      },
      error: (err) => {
        console.error('Erreur lors du chargement des progressions', err);
      }
    });
  }

  enregistrer(p: ProgressionDTO & { editMode?: boolean }): void {
    const updateDTO = {
      status: p.status,
      commentaire: p.commentaire,
      evaluation: p.evaluation
    };

    this.progressionService.updateProgression(p.id, updateDTO).subscribe({
      next: (updated) => {
        Object.assign(p, updated);
        p.editMode = false;
      },
      error: (err) => {
        console.error('Erreur lors de la mise à jour de la progression', err);
      }
    });
  }

  annuler(p: ProgressionDTO & { editMode?: boolean }): void {
    this.progressionService.getProgressionsByCandidatId(this.data.candidatId).subscribe({
      next: (res) => {
        const original = res.find(item => item.id === p.id);
        if (original) {
          Object.assign(p, original);
          p.editMode = false;
        }
      },
      error: (err) => {
        console.error('Erreur lors de l\'annulation', err);
      }
    });
  }
  
}
