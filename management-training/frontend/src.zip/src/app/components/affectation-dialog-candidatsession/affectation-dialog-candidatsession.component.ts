import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { AffectationDialogComponent } from '../affectation-dialog/affectation-dialog.component';
import { SessionService } from '../../services/session/session.service';
import { CandidatSessionService } from '../../services/candidat-session/candidat-session.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { CommonModule } from '@angular/common';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';


@Component({
  selector: 'app-affectation-dialog',
  standalone : true,
  templateUrl: './affectation-dialog-candidatsession.component.html',
  styleUrls: ['./affectation-dialog-candidatsession.component.scss'],
      imports: [
      CommonModule,
      FormsModule,              // <--- essentiel pour ngModel
      MatCardModule,            // <--- pour mat-card
      MatFormFieldModule,
      MatInputModule,
      MatDatepickerModule,
      MatNativeDateModule,      // <--- adapter datepicker
      MatIconModule,
      MatButtonModule,
      MatSelectModule,
      MatDialogModule

    ],
})
export class AffectationDialogCandidatsessionComponent implements OnInit {
  sessions: any[] = [];
  selectedSessionId!: number;
  dateAffectation: Date = new Date();

  constructor(
    private dialogRef: MatDialogRef<AffectationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { candidatId: number },
    private sessionService: SessionService,
    private affectationService: CandidatSessionService
  ) {}

  ngOnInit(): void {
    this.sessionService.getAllSessions().subscribe((sessions) => {
      this.sessions = sessions;
    });
  }

  affecter(): void {
    const request = {
      candidatId: this.data.candidatId,
      sessionId: this.selectedSessionId,
      dateAffectation: this.dateAffectation
    };

    this.affectationService.affecterCandidat(request.candidatId, request.sessionId, request.dateAffectation)
      .subscribe(() => {
        this.dialogRef.close(true);
      });
  }

  annuler(): void {
    this.dialogRef.close(false);
  }
}
