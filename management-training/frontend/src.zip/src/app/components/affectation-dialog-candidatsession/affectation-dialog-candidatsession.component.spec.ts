import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AffectationDialogCandidatsessionComponent } from './affectation-dialog-candidatsession.component';

describe('AffectationDialogCandidatsessionComponent', () => {
  let component: AffectationDialogCandidatsessionComponent;
  let fixture: ComponentFixture<AffectationDialogCandidatsessionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AffectationDialogCandidatsessionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AffectationDialogCandidatsessionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
