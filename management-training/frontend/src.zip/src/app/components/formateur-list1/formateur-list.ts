import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { Formateur } from '../../models/formateur.model';
import { UtilisateurService } from '../../services/utilisateur/utilisateur';
import { FormateurFormComponent } from '../formateur-form1/formateur-form';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatNativeDateModule } from '@angular/material/core';
import { AffectationDialogComponent } from '../affectation-dialog/affectation-dialog.component';
import { Router } from '@angular/router';
import { AffectationFormateurModule } from '../../models/affectation-formateur-module.model';
import { FormateurModuleService } from '../../services/formateur-module/formateur-module.service';
import { SessionFormComponent } from '../session-form/session-form.component';
import { SessionService, Session} from '../../services/session/session.service';
import { ListeCandidatsDialogComponent } from '../liste-candidats-dialog/liste-candidats-dialog.component';
import { CandidatSessionService } from '../../services/candidat-session/candidat-session.service';
import { MatButtonModule } from '@angular/material/button';
import { MatSortModule } from '@angular/material/sort';
import { MatCardModule } from '@angular/material/card';


@Component({
  selector: 'app-formateur-list',
  templateUrl: './formateur-list.component.html',
   styleUrls: ['./formateur-list.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSortModule,
    FormsModule,
    MatCardModule
  ],
})
export class FormateurListComponent implements OnInit {
  user: any;
  formateurs: Formateur[] = [];
  displayedColumns: string[] = ['nomComplet', 'email', 'profil', 'actions'];
  affectationColumns: string[] = ['formateur', 'module', 'dateAffectation', 'actions'];
  sessionColumns: string[] = ['formateur', 'module', 'dateDebut','dateFin', 'salleOuLien', 'actions'];
  affectations: AffectationFormateurModule[] = [];
  sessions: any[] = [];
  searchTerm: string = '';
  showTable: boolean = false;
  searchSessionTerm: string = '';


  constructor(
    private utilisateurService: UtilisateurService,
    private dialog: MatDialog,
    private router: Router,
    private formateurModuleService: FormateurModuleService,
    private sessionService: SessionService,
    private affectationService: CandidatSessionService
  ) {}

  ngOnInit(): void {
    this.loadFormateurs();
    this.chargerAffectations();
    this.chargerSessions();
    
    const userData = localStorage.getItem('user');
    if (userData) {
      this.user = JSON.parse(userData);
    }
  }


  loadFormateurs(): void {
    this.utilisateurService.getAllFormateurs().subscribe(data => {
      this.formateurs = data;
    });
  }

  openAddDialog(): void {
    const dialogRef = this.dialog.open(FormateurFormComponent, {
      width: '400px',
      data: { formateur: {} as Formateur }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.utilisateurService.addFormateur(result).subscribe(() => this.loadFormateurs());
      }
    });
  }

  openEditDialog(formateur: Formateur): void {
    const dialogRef = this.dialog.open(FormateurFormComponent, {
      width: '400px',
      data: { formateur }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.utilisateurService.updateFormateur(formateur.id!, result).subscribe(() => this.loadFormateurs());
      }
    });
  }

  deleteFormateur(id: number): void {
    if (confirm('Voulez-vous vraiment supprimer ce formateur ?')) {
      this.utilisateurService.deleteFormateur(id).subscribe(() => this.loadFormateurs());
    }
  }

  openAffectationDialog(formateur: Formateur): void {
    const dialogRef = this.dialog.open(AffectationDialogComponent, {
      width: '400px',
      data: { formateur }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.chargerAffectations();
      }
    });
  }

  openSessionDialog(affectation: AffectationFormateurModule): void {
    const dialogRef = this.dialog.open(SessionFormComponent, {
      width: '400px',
      data: { affectation }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.sessionService.addSession(result).subscribe(() => {
          this.chargerSessions();
        });
      }
    });
  }

  chargerAffectations(): void {
    this.formateurModuleService.getAll().subscribe(data => {
      this.affectations = data;
    });
  }

  supprimer(id: number): void {
    if (confirm('Voulez-vous vraiment supprimer cette affectation ?')) {
      this.formateurModuleService.delete(id).subscribe(() => {
        this.chargerAffectations();
      });
    }
  }

  filteredAffectations(): AffectationFormateurModule[] {
    const term = this.searchTerm.toLowerCase();
    return this.affectations.filter(aff =>
      aff.formateur?.nomComplet?.toLowerCase().includes(term) ||
      aff.module?.nom?.toLowerCase().includes(term)
    );
  }

  filteredSessions(): Session[] {
  const term = this.searchSessionTerm.toLowerCase();
  return this.sessions.filter(session =>
    session.formateur?.nomComplet?.toLowerCase().includes(term) ||
    session.module?.nom?.toLowerCase().includes(term)
  );
}


  chargerSessions(): void {
    this.sessionService.getAllSessions().subscribe(data => {
      this.sessions = data;
    });
  }

  deleteSession(id: number): void {
    if (confirm('Voulez-vous vraiment supprimer cette session ?')) {
      this.sessionService.deleteSession(id).subscribe(() => {
        this.chargerSessions();
      });
    }
  }

  toggleTable(): void {
    this.showTable = !this.showTable;
  }


  
  voirCandidats(sessionId: number): void {
  this.affectationService.getCandidatsBySession(sessionId).subscribe(candidats => {
    this.dialog.open(ListeCandidatsDialogComponent, {
      width: '1000px', // ou '90vw' pour une largeur relative à l'écran
      maxWidth: '1000px',
      panelClass: 'custom-dialog-container',
      data: { candidats }
    });
  });
 }


}