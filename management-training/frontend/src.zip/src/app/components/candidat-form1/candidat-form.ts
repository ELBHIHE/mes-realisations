import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { Candidat } from '../../models/candidat.model';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, MatOption, MatOptionModule } from '@angular/material/core';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { MatSelectModule } from '@angular/material/select';
import { MatCard } from '@angular/material/card';

@Component({
  selector: 'app-candidat-form',
  templateUrl: './candidat-form.component.html', 
  styleUrls: ['./candidat-form.scss'],
  standalone : true,
  imports: [
       MatDialogModule,
      MatFormFieldModule,
      MatInputModule,
      FormsModule,
      MatDatepickerModule,
      MatNativeDateModule,
      MatIconModule,
      MatTableModule,
      CommonModule,
      MatSelectModule,
      MatOptionModule,
      MatCard

    ],

})
export class CandidatFormComponent {
  candidat: Candidat;
  profils: string[] = [
  'Dev Java',
  'Dev .Net',
  'Dev Salesforce',
  'Dev SharePoint',
  'Testeur',
  'BA',
  'PM'
];

  constructor(
    public dialogRef: MatDialogRef<CandidatFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { candidat: Candidat }
  ) {
    
    // ✅ Copie de l'objet reçu pour éviter la modification directe
    this.candidat = { ...data.candidat };
  }

  onSubmit(): void {
  this.dialogRef.close(this.candidat); // ✅ renvoie les données modifiées
}


  onCancel(): void {
    this.dialogRef.close();
  }
}