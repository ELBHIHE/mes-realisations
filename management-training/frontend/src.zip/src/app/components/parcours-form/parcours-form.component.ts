import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { ParcoursService } from '../../services/parcours/parcours.service';
import { Parcours,TypeParcours  } from '../../models/parcours.model';
import { MatCardModule } from '@angular/material/card';
import { MatOptionModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';


@Component({
  selector: 'app-parcours-form',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatCardModule,
    MatSelectModule,
    MatOptionModule,
    MatIconModule
  ],
  templateUrl: './parcours-form.component.html',
  styleUrls: ['./parcours-form.component.scss']
})
export class ParcoursFormComponent implements OnInit {
  form!: FormGroup;
  types = Object.values(TypeParcours);
  isEditMode = false;
  parcoursId!: number;
  profils: string[] = [
  'Dev Java',
  'Dev .Net',
  'Dev Salesforce',
  'Dev SharePoint',
  'Testeur',
  'BA',
  'PM'
];

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private parcoursService: ParcoursService
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      nom: [''],
      type: [''],
      duree: [0],
      description: [''],
      profil: ['']
    });

    this.route.paramMap.subscribe(params => {
      const idParam = params.get('id');
      if (idParam) {
        this.isEditMode = true;
        this.parcoursId = +idParam;
        this.parcoursService.getById(this.parcoursId).subscribe(parcours => {
          this.form.patchValue(parcours);
        });
      }
    });
  }

  onSubmit() {
    const parcours: Parcours = this.form.value;

    if (this.isEditMode) {
      this.parcoursService.update(this.parcoursId, parcours).subscribe(() => {
        this.router.navigate(['/dashboard/parcours']);
      });
    } else {
      this.parcoursService.create(parcours).subscribe(() => {
        this.router.navigate(['/dashboard/parcours']);
      });
    }
  }

onCancel(): void {
    // Retour à la liste des parcours ou autre action
    this.router.navigate(['/dashboard/parcours']);
  }
}
