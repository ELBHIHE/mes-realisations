import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RhManagerForm } from './rh-manager-form';

describe('RhManagerForm', () => {
  let component: RhManagerForm;
  let fixture: ComponentFixture<RhManagerForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RhManagerForm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RhManagerForm);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
