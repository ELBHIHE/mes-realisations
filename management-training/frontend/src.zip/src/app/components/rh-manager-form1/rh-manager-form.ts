import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { RHManager } from '../../models/rh-manager.model';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { CommonModule } from '@angular/common';
import { MatCard } from '@angular/material/card';

@Component({
  selector: 'app-rh-manager-form',
  templateUrl: './rh-manager-form.component.html',
   styleUrls: ['./rh-manager-form.scss'],
  standalone : true,
    imports: [
      MatDialogModule,
      MatFormFieldModule,
      MatInputModule,
      FormsModule,
      MatDatepickerModule,
      MatNativeDateModule,
      MatIconModule,
      MatTableModule,
      CommonModule,
      MatCard
    ],
})
export class RHManagerFormComponent {
  rhManager: RHManager;
  constructor(
    public dialogRef: MatDialogRef<RHManagerFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { rhManager: RHManager }
  ) {
    this.rhManager = { ...data.rhManager};
  }



  onSubmit(): void {
    this.dialogRef.close(this.rhManager);
  }

  onCancel(): void {
    this.dialogRef.close();
  }
}