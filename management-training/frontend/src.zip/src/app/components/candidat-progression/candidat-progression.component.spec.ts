import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidatProgressionComponent } from './candidat-progression.component';

describe('CandidatProgressionComponent', () => {
  let component: CandidatProgressionComponent;
  let fixture: ComponentFixture<CandidatProgressionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CandidatProgressionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CandidatProgressionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
