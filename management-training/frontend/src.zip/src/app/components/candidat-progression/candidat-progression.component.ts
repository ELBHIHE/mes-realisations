import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProgressionService } from '../../services/progression/progression.service';
import { ProgressionDTO } from '../../models/ProgressionDTO.model';

import jsPDF from 'jspdf';
import { CertificatDTO } from '../../models/CertificatDTO.model';

@Component({
  selector: 'app-candidat-progression',
  standalone: true,
  templateUrl: './candidat-progression.component.html',
  styleUrl: './candidat-progression.component.scss',
  imports: [CommonModule]
})
export class CandidatProgressionComponent implements OnInit {
  progressions: ProgressionDTO[] = [];
  candidatId!: number;

  constructor(private progressionService: ProgressionService) {}

  ngOnInit(): void {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      const user = JSON.parse(userStr);
      this.candidatId = user?.id;
      this.chargerProgressions();
    }
  }

  chargerProgressions(): void {
    this.progressionService.getProgressionsByCandidatId(this.candidatId).subscribe({
      next: (res) => {
        this.progressions = res;
      },
      error: (err) => {
        console.error('Erreur lors du chargement des progressions', err);
      }
    });
  }

 genererCertificat(progressionId: number): void {
  this.progressionService.getCertificat(progressionId).subscribe({
    next: async (cert: CertificatDTO) => {
      const doc = new jsPDF();

      // Charger les images
      const logo = await this.loadImage('assets/capgemini_logo.png');
   

      // Ajouter le logo
      doc.addImage(logo, 'PNG', 150, 10, 40, 20); // x, y, width, height

      doc.setFontSize(18);
      doc.text(' Certificat de Réussite', 60, 40);

      doc.setFontSize(12);
      doc.text(`Candidat : ${cert.nomCandidat}`, 20, 60);
      doc.text(`Module : ${cert.nomModule}`, 20, 70);
      doc.text(`Date de fin : ${new Date(cert.dateFin).toLocaleDateString()}`, 20, 80);
      doc.text(`Évaluation : ${cert.evaluation}`, 20, 90);

      doc.setFontSize(10);
      doc.text('Félicitations pour votre réussite !', 20, 110);

   

      doc.save(`certificat_${cert.nomCandidat}_${cert.nomModule}.pdf`);
    },
    error: (err) => {
      console.error('Erreur lors de la génération du certificat', err);
    }
  });
}

// Méthode pour charger une image
loadImage(url: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'Anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0);
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = reject;
    img.src = url;
  });
}

}
