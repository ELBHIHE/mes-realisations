import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { CommonModule } from '@angular/common';
import { ModuleService } from '../../services/module/module.service';
import { FormateurModuleService } from '../../services/formateur-module/formateur-module.service';
import { Module } from '../../models/module.model';
 
 
@Component({
  selector: 'app-affectation-dialog',
  standalone: true,
  templateUrl: './affectation-dialog.component.html',
  styleUrls: ['./affectation-dialog.component.scss'],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatNativeDateModule
  ]
})
export class AffectationDialogComponent implements OnInit {
  form: FormGroup;
  modules: Module[] = [];
 
  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<AffectationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private moduleService: ModuleService,
    private formateurModuleService: FormateurModuleService
  ) {
    this.form = this.fb.group({
      dateAffectation: [''],
      moduleId: ['']
    });
  }
 
  ngOnInit(): void {
    this.moduleService.getAll().subscribe((modules) => {
      this.modules = modules;
    });
  }
 
  submit(): void {
    const affectation = {
      dateAffectation: this.form.value.dateAffectation,
      formateurId: this.data.formateur.id,
      moduleId: this.form.value.moduleId
    };
 
    this.formateurModuleService.create(affectation).subscribe(() => {
      this.dialogRef.close(true);
    });
  }
 
  cancel(): void {
    this.dialogRef.close();
  }
}