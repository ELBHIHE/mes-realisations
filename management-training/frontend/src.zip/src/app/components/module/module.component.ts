import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Module } from '../../models/module.model';
import { Parcours } from '../../models/parcours.model';
import { ModuleService } from '../../services/module/module.service';
import { ParcoursService } from '../../services/parcours/parcours.service';
 
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSortModule } from '@angular/material/sort';
 
@Component({
  selector: 'app-module',
  standalone: true,
  imports: [
   CommonModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatSortModule,
    MatCardModule,
    MatToolbarModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    ReactiveFormsModule
  ],
  templateUrl: './module.component.html',
  styleUrls: ['./module.component.scss']
})
export class ModuleComponent implements OnInit {
  user: any;
  modules: Module[] = [];
  parcoursList: Parcours[] = [];
  displayedColumns: string[] = ['nom', 'duree', 'contenu', 'parcours', 'actions'];
  form!: FormGroup;
  isEditMode = false;
  selectedModuleId?: number;
 
  constructor(
    private moduleService: ModuleService,
    private parcoursService: ParcoursService,
    private fb: FormBuilder
  ) {}
 
  ngOnInit(): void {
    this.loadModules();
    this.loadParcours();
    this.initForm();
 
    const userData = localStorage.getItem('user');
    if (userData) {
      this.user = JSON.parse(userData);
    }
  }
 
  initForm() {
    this.form = this.fb.group({
      nom: [''],
      duree: [0],
      contenu: [''],
      parcours: [null]
    });
  }
 
  loadModules() {
    this.moduleService.getAll().subscribe(data => this.modules = data);
  }
 
  loadParcours() {
    this.parcoursService.getAll().subscribe(data => this.parcoursList = data);
  }
 
onSubmit() {
  const parcoursId = this.form.value.parcours;
  const parcours = this.parcoursList.find(p => p.id === parcoursId);
 
  const module: Module = {
    ...this.form.value,
    parcours: parcours!
  };
 
  const formateurId = this.user?.id;
  const isFormateur = this.user?.type_utilisateur === 'FORMATEUR';
 
  if (this.isEditMode && this.selectedModuleId) {
    this.moduleService.update(this.selectedModuleId, module).subscribe(() => {
      this.loadModules();
      this.cancel();
    });
  } else {
    if (isFormateur && formateurId) {
      this.moduleService.createWithFormateur(module, formateurId).subscribe(() => {
        this.loadModules();
        this.form.reset();
      });
    } else {
      this.moduleService.create(module).subscribe(() => {
        this.loadModules();
        this.form.reset();
      });
    }
  }
}
 
 
 
  edit(module: Module) {
    this.isEditMode = true;
    this.selectedModuleId = module.id;
    this.form.patchValue({
      nom: module.nom,
      duree: module.duree,
      contenu: module.contenu,
      parcours: module.parcours.id
    });
  }
 
  delete(id: number) {
    this.moduleService.delete(id).subscribe(() => {
      this.modules = this.modules.filter(m => m.id !== id);
    });
  }
 
  cancel() {
    this.isEditMode = false;
    this.selectedModuleId = undefined;
    this.form.reset();
  }
}