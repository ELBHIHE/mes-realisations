import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { Router, RouterOutlet } from '@angular/router';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  imports: [
    RouterOutlet,
    CommonModule,
    MatMenuModule, // Ajout pour mat-menu
    MatButtonModule,
    MatIconModule, // Ajout pour les icônes
    MatDividerModule
  ],
})
export class DashboardComponent implements OnInit {
  
showMenu = false;
  user: any = {};


  constructor(private router: Router) {}


  ngOnInit() {
    const userData = localStorage.getItem('user');
    if (userData) {
      this.user = JSON.parse(userData);
    }
  }

  navigateTo(path: string) {
    this.router.navigate([`/dashboard/${path}`]);
  }

  logout() {
    localStorage.removeItem('user');
    this.router.navigate(['/login']);
  }

  
toggleMenu() {
    this.showMenu = !this.showMenu;
  }

}
