import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { Router } from '@angular/router';



@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,

  ],

  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  email = '';
  password = '';
  showError: boolean = false;

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit() {
  const credentials = { email: this.email, password: this.password };

  this.authService.login(credentials).subscribe({
    next: (response) => {
      this.showError = false;
      localStorage.setItem('user', JSON.stringify(response));
      this.router.navigate(['/dashboard']);
    },
    error: (err) => {
      this.showError = true;
      setTimeout(() => {
        this.showError = false;
      }, 3000);
      console.error('Erreur de connexion', err);
    }
  });
}


  }

