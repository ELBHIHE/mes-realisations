import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormateurModuleListComponent } from './formateur-module-list.component';

describe('FormateurModuleList1Component', () => {
  let component: FormateurModuleListComponent;
  let fixture: ComponentFixture<FormateurModuleListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormateurModuleListComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormateurModuleListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
