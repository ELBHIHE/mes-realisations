import { Component, OnInit } from '@angular/core';
import { AffectationFormateurModule } from '../../models/affectation-formateur-module.model';
import { FormateurModuleService } from '../../services/formateur-module/formateur-module.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-formateur-module-list',
  templateUrl: './formateur-module-list.component.html',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
  ]
})
export class FormateurModuleListComponent implements OnInit {
  affectations: AffectationFormateurModule[] = [];
  searchTerm: string = '';
  showTable: boolean = true;

  constructor(private service: FormateurModuleService) {}

  ngOnInit(): void {
    this.chargerAffectations();
  }

  chargerAffectations(): void {
    this.service.getAll().subscribe(data => {
      this.affectations = data;
    });
  }

  supprimer(id: number): void {
    if (confirm('Voulez-vous vraiment supprimer cette affectation ?')) {
      this.service.delete(id).subscribe(() => {
        this.chargerAffectations();
      });
    }
  }

  filteredAffectations(): AffectationFormateurModule[] {
    const term = this.searchTerm.toLowerCase();
    return this.affectations.filter(aff =>
      aff.formateur?.nomComplet?.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  toggleTable(): void {
    this.showTable = !this.showTable;
  }
}