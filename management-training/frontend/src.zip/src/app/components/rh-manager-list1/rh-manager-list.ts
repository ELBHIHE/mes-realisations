import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { RHManager } from '../../models/rh-manager.model';
import { UtilisateurService } from '../../services/utilisateur/utilisateur';
import { RHManagerFormComponent } from '../rh-manager-form1/rh-manager-form';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatIconModule } from '@angular/material/icon';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableModule } from '@angular/material/table';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';


@Component({
  selector: 'app-rh-manager-list',
  templateUrl: './rh-manager-list.component.html',
  styleUrls: ['./rh-manager-list.scss'],
  standalone : true,
    imports: [
     CommonModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatSortModule,
    MatCardModule
    ],
})
export class RHManagerListComponent implements OnInit {
  rhManagers: RHManager[] = [];
  displayedColumns: string[] = ['nomComplet', 'email', 'actions'];

  constructor(private utilisateurService: UtilisateurService, private dialog: MatDialog) {}

  ngOnInit(): void {
    this.loadRHManagers();
  }

  loadRHManagers(): void {
    this.utilisateurService.getAllRHManagers().subscribe(data => {
      this.rhManagers = data;
    });
  }

  openAddDialog(): void {
    const dialogRef = this.dialog.open(RHManagerFormComponent, {
      width: '400px',
      data: { rhManager: {} as RHManager }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.utilisateurService.addRHManager(result).subscribe(() => this.loadRHManagers());
      }
    });
  }

  openEditDialog(rhManager: RHManager): void {
    const dialogRef = this.dialog.open(RHManagerFormComponent, {
      width: '400px',
      data: { rhManager }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.utilisateurService.updateRHManager(rhManager.id!, result).subscribe(() => this.loadRHManagers());
      }
    });
  }

  deleteRHManager(id: number): void {
    if (confirm('Voulez-vous vraiment supprimer ce RH manager ?')) {
      this.utilisateurService.deleteRHManager(id).subscribe(() => this.loadRHManagers());
    }
  }
}