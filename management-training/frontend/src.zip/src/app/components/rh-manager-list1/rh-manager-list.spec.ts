import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RhManagerList } from './rh-manager-list';

describe('RhManagerList', () => {
  let component: RhManagerList;
  let fixture: ComponentFixture<RhManagerList>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RhManagerList]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RhManagerList);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
