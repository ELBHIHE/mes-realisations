import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListeCandidatsDialogComponent } from './liste-candidats-dialog.component';

describe('ListeCandidatsDialogComponent', () => {
  let component: ListeCandidatsDialogComponent;
  let fixture: ComponentFixture<ListeCandidatsDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ListeCandidatsDialogComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListeCandidatsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
