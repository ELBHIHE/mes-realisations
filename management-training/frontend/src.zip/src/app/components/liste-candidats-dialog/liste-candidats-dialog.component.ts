import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogActions, MatDialogContent, MatDialogRef } from '@angular/material/dialog';
import { CandidatSession } from '../../models/candidatsession.model';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { DatePipe } from '@angular/common';
import { ProgressionDialogComponent } from '../progression-dialog/progression-dialog.component';

@Component({
  selector: 'app-liste-candidats-dialog',
  templateUrl: './liste-candidats-dialog.component.html',
  styleUrls: ['./liste-candidats-dialog.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatDialogActions,
    MatDialogContent,
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    DatePipe
  ]
})
export class ListeCandidatsDialogComponent {
  displayedColumns: string[] = ['nomComplet', 'email', 'profil', 'dateEntree', 'dateAffectation', 'Actions'];

  constructor(
    public dialogRef: MatDialogRef<ListeCandidatsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { candidats: CandidatSession[] },
    private dialog: MatDialog
  ) {}


  fermer(): void {
    this.dialogRef.close();
  }

   ouvrirProgression(candidatId: number): void {
    this.dialog.open(ProgressionDialogComponent, {
      width: '1100px', // ou '90vw' pour une largeur relative
      maxWidth: '1100px',
      panelClass: 'progression-dialog-container',
      data: { candidatId }
    });
  }

}