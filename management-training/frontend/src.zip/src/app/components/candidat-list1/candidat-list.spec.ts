import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidatList } from './candidat-list';

describe('CandidatList', () => {
  let component: CandidatList;
  let fixture: ComponentFixture<CandidatList>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CandidatList]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CandidatList);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
