import { Component, OnInit } from '@angular/core';
import { Candidat } from '../../models/candidat.model';
 
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core'; // nécessaire pour le support des dates natives
 
 
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { UtilisateurService } from '../../services/utilisateur/utilisateur';
import { CandidatFormComponent } from '../candidat-form1/candidat-form';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common'
import { AffectationDialogCandidatsessionComponent } from '../affectation-dialog-candidatsession/affectation-dialog-candidatsession.component';
import { CandidatSession } from '../../models/candidatsession.model';
import { CandidatSessionService } from '../../services/candidat-session/candidat-session.service';
import { MatCardModule } from '@angular/material/card';
import { MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
 
 
 
@Component({
  selector: 'app-candidat-list',
  templateUrl: './candidat-list.component.html',
  styleUrls: ['./candidat-list.scss'],
  standalone : true,
    imports: [
      CommonModule,
      MatTableModule,
      MatButtonModule,
      MatIconModule,
      MatFormFieldModule,
      MatInputModule,
      MatSortModule,
      FormsModule,
      MatCardModule
 
    ],
})
export class CandidatListComponent implements OnInit {
 
  affectations: CandidatSession[] = [];
  searchCandidatSessionTerm: string = '';
  showAffectations: boolean = false;
 
  candidats: Candidat[] = [];
  displayedColumns: string[] = ['nomComplet', 'email', 'profil', 'dateEntree', 'actions'];
  affectationColumns: string[] = ['candidat', 'dateDebut','dateFin', 'dateAffectation', 'actions'];
 
  constructor(private utilisateurService: UtilisateurService, private dialog: MatDialog, private affectationService: CandidatSessionService) {}
 
  ngOnInit(): void {
    this.loadCandidats();
    this.loadAffectations();
  }
 
  loadCandidats(): void {
    this.utilisateurService.getAllCandidats().subscribe(data => {
      this.candidats = data;
    });
  }
 
  openAddDialog(): void {
    const dialogRef = this.dialog.open(CandidatFormComponent, {
      width: '400px',
      data: { candidat: {} as Candidat }
    });
 
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.utilisateurService.addCandidat(result).subscribe(() => this.loadCandidats());
      }
    });
  }
 
  openEditDialog(candidat: Candidat): void {
    const dialogRef = this.dialog.open(CandidatFormComponent, {
      width: '400px',
      data: { candidat }
    });
 
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.utilisateurService.updateCandidat(candidat.id!, result).subscribe(() => this.loadCandidats());
      }
    });
  }
 
  deleteCandidat(id: number): void {
    if (confirm('Voulez-vous vraiment supprimer ce candidat ?')) {
      this.utilisateurService.deleteCandidat(id).subscribe(() => this.loadCandidats());
    }
  }
 
 
openAffectationDialog(candidat: any): void {
  const dialogRef = this.dialog.open(AffectationDialogCandidatsessionComponent, {
    width: '400px',
    data: { candidatId: candidat.id }
  });
 
  dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadAffectations();
      }
    });
}
 
 
loadAffectations(): void {
  this.affectationService.getAllAffectations().subscribe(data => {
    this.affectations = data;
  });
}
 
filteredCandidatSessions(): CandidatSession[] {
  const term = this.searchCandidatSessionTerm.toLowerCase();
  return this.affectations.filter(aff =>
    aff.candidat.nomComplet?.toLowerCase().includes(term)
  );
}

 
supprimerAffectation(id: number): void {
  this.affectationService.supprimerAffectation(id).subscribe(() => {
    this.loadAffectations();
  });
}
 
 
 
}