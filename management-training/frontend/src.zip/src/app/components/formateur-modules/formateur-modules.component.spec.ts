import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormateurModulesComponent } from './formateur-modules.component';

describe('FormateurModulesComponent', () => {
  let component: FormateurModulesComponent;
  let fixture: ComponentFixture<FormateurModulesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormateurModulesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormateurModulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
