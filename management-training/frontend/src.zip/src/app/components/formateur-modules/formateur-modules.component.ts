import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Module } from '../../models/module.model';
import { ModuleService } from '../../services/module/module.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormateurModuleService } from '../../services/formateur-module/formateur-module.service';
 
@Component({
  selector: 'app-formateur-modules',
  templateUrl: './formateur-modules.component.html',
  styleUrls: ['./formateur-modules.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule
  ],
})
export class FormateurModulesComponent implements OnInit {
  modules: Module[] = [];
  form!: FormGroup;
  isEditMode = false;
  selectedModuleId?: number;
  user: any;
 
  constructor(
    private moduleService: ModuleService,
    private formateurmoduleservice : FormateurModuleService,
    private fb: FormBuilder
  ) {}
 
  ngOnInit(): void {
    this.initForm();
 
    const userData = localStorage.getItem('user');
    if (userData) {
      this.user = JSON.parse(userData);
      this.loadModules();
    }
  }
 
  initForm() {
    this.form = this.fb.group({
      nom: [''],
      duree: [0],
      contenu: ['']
    });
  }
 
loadModules() {
  const formateurId = this.user?.id;
  if (formateurId) {
    this.formateurmoduleservice.getModulesByFormateurId(formateurId).subscribe({
      next: (data) => {
        this.modules = data.sort((a, b) => a.nom.localeCompare(b.nom)); // tri alphabétique
      },
      error: (err) => console.error('Erreur lors du chargement des modules', err)
    });
  }
}
 
 
  edit(module: Module) {
    this.isEditMode = true;
    this.selectedModuleId = module.id;
    this.form.patchValue({
      nom: module.nom,
      duree: module.duree,
      contenu: module.contenu
    });
  }
 
  onSubmit() {
    if (this.isEditMode && this.selectedModuleId) {
      const updatedModule: Module = {
        ...this.form.value,
        id: this.selectedModuleId
      };
 
      this.moduleService.update(this.selectedModuleId, updatedModule).subscribe(() => {
        this.loadModules();
        this.cancel();
      });
    }
  }
 
  cancel() {
    this.isEditMode = false;
    this.selectedModuleId = undefined;
    this.form.reset();
  }
 
    delete(moduleId?: number): void {
      if (moduleId && confirm('Voulez-vous vraiment supprimer ce module ?')) {
        this.moduleService.delete(moduleId).subscribe({
          next: () => this.loadModules(),
          error: (err) => console.error('Erreur lors de la suppression du module', err)
        });
      }
    }
 
 
}