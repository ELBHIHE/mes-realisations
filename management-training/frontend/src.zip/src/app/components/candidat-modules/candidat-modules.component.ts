import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { DatePipe } from '@angular/common';
import { ModuleService } from '../../services/module/module.service';
import { Module } from '../../models/module.model';

@Component({
  selector: 'app-candidat-modules',
  templateUrl: './candidat-modules.component.html',
  styleUrls: ['./candidat-modules.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatIconModule,
    MatToolbarModule,
    DatePipe
  ]
})
export class CandidatModulesComponent implements OnInit {
  modules: Module[] = [];

  constructor(private moduleService: ModuleService) {}

  ngOnInit(): void {
    const user = localStorage.getItem('user');
    if (user) {
      const candidat = JSON.parse(user);
      const candidatId = candidat.id;

      this.moduleService.getModulesByCandidat(candidatId).subscribe({
        next: (data) => (this.modules = data),
        error: (err) => console.error('Erreur lors du chargement des modules', err)
      });
    } else {
      console.warn('Utilisateur non connecté');
    }
  }
}