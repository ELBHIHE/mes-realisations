import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidatModulesComponent } from './candidat-modules.component';

describe('CandidatModulesComponent', () => {
  let component: CandidatModulesComponent;
  let fixture: ComponentFixture<CandidatModulesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CandidatModulesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CandidatModulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
