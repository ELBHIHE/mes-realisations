import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormateurSessionsComponent } from './formateur-sessions.component';

describe('FormateurSessionsComponent', () => {
  let component: FormateurSessionsComponent;
  let fixture: ComponentFixture<FormateurSessionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormateurSessionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormateurSessionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
