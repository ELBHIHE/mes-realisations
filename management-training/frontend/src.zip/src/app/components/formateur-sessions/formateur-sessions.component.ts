import { Component, OnInit } from '@angular/core';
import { Session, SessionService } from '../../services/session/session.service';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Module } from '../../models/module.model';
import { FormateurModuleService } from '../../services/formateur-module/formateur-module.service';
import { CandidatSessionService } from '../../services/candidat-session/candidat-session.service';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { ListeCandidatsDialogComponent } from '../liste-candidats-dialog/liste-candidats-dialog.component';
import { AssignCandidateDialogComponent } from '../assign-candidate-dialog/assign-candidate-dialog.component';
import { Candidat } from '../../models/candidat.model';
import { UtilisateurService } from '../../services/utilisateur/utilisateur';
 
@Component({
  selector: 'app-formateur-sessions',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule
  ],
  templateUrl: './formateur-sessions.component.html',
  styleUrl: './formateur-sessions.component.scss'
})
export class FormateurSessionsComponent implements OnInit {
  modules: Module[] = [];
  showForm = false;
  sessionForm!: FormGroup;
  user: any;
  sessions: Session[] = [];
  candidats: Candidat[] = [];
 
  constructor(
    private sessionService: SessionService,
    private formateurmoduleservice: FormateurModuleService,
    private fb: FormBuilder,
    private affectationService: CandidatSessionService,
    private candidatService: UtilisateurService,
    private dialog: MatDialog
  ) {}
 
  ngOnInit(): void {
    this.chargerSessions();
    this.initForm();
    this.loadModules();
    this.loadCandidats();
  }
 
 
initForm(): void {
  this.sessionForm = this.fb.group({
    dateDebut: ['', Validators.required],
    dateFin: ['', Validators.required],
    salleOuLien: ['', Validators.required],
    typeSession: ['presentiel', Validators.required], // valeur par défaut
    moduleId: ['', Validators.required]
  });
}
 
  loadModules(): void {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      this.user = JSON.parse(userStr);
      const formateurId = this.user?.id;
 
      if (formateurId) {
        this.formateurmoduleservice.getModulesByFormateurId(formateurId).subscribe({
          next: (data) => this.modules = data,
          error: (err) => console.error('Erreur lors du chargement des modules', err)
        });
      }
    }
  }
 
  loadCandidats(): void {
    this.candidatService.getAllCandidats().subscribe({
      next: (data) => this.candidats = data,
      error: (err) => console.error('Erreur lors du chargement des candidats', err)
    });
  }
 
  chargerSessions(): void {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      this.user = JSON.parse(userStr);
      const formateurId = this.user?.id;
 
      if (formateurId) {
        this.sessionService.getSessionsByFormateurId(formateurId).subscribe({
          next: (data) => this.sessions = data,
          error: (err) => console.error('Erreur lors du chargement des sessions', err)
        });
      } else {
        console.warn('ID du formateur non trouvé dans l\'objet user');
      }
    } else {
      console.warn('Objet user non trouvé dans le localStorage');
    }
  }
 
  deleteSession(id: number): void {
    if (confirm('Voulez-vous vraiment supprimer cette session ?')) {
      this.sessionService.deleteSession(id).subscribe(() => {
        this.chargerSessions();
      });
    }
  }
 
ajouterSession(): void {
  const formateurId = this.user?.id;
  if (!formateurId) return;
 
  const nouvelleSession = {
    dateDebut: this.sessionForm.value.dateDebut,
    dateFin: this.sessionForm.value.dateFin,
    salleOuLien: this.sessionForm.value.salleOuLien,
    module: { id: this.sessionForm.value.moduleId },
    formateur: { id: formateurId }
  };
 
  this.sessionService.addSessionFromFormateur(nouvelleSession).subscribe({
    next: () => {
      this.chargerSessions();
      this.sessionForm.reset();
      this.showForm = false;
    },
    error: (err) => console.error('Erreur lors de l\'ajout de la session', err)
  });
}
 
 
  voirCandidats(sessionId: number): void {
    this.affectationService.getCandidatsBySession(sessionId).subscribe(candidats => {
      this.dialog.open(ListeCandidatsDialogComponent, {
                
        width: '1000px', // ou '90vw' pour une largeur relative à l'écran
        maxWidth: '1000px',
        panelClass: 'custom-dialog-container',

        data: { candidats }
      });
    });
  }
 
  openAssignCandidateDialog(sessionId: number): void {
    this.dialog.open(AssignCandidateDialogComponent, {
      width: '600px',
      data: { sessionId, candidats: this.candidats }
    }).afterClosed().subscribe(result => {
      if (result) {
        this.chargerSessions(); // Refresh sessions if needed
      }
    });
  }

  
  onTypeSessionChange(): void {
    const type = this.sessionForm.value.typeSession;

    const salleOuLienControl = this.sessionForm.get('salleOuLien');
    if (type === 'online') {
      salleOuLienControl?.setValidators([
        Validators.required,
        Validators.pattern('https?://.+') // simple validation de lien
      ]);
    } else {
      salleOuLienControl?.setValidators([Validators.required]);
    }
    salleOuLienControl?.updateValueAndValidity();
  }

onPlatformChange(event: Event): void {
  const selectedUrl = (event.target as HTMLSelectElement).value;
  if (selectedUrl && confirm('Voulez-vous ouvrir la plateforme pour créer une réunion ?')) {
    window.open(selectedUrl, '_blank');
  }
}



}