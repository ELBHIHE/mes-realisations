import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { CandidatSessionService } from '../../services/candidat-session/candidat-session.service';
import { Candidat } from '../../models/candidat.model';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-assign-candidate-dialog',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule
  ],
  template: `
    <h2 mat-dialog-title>Affecter un candidat</h2>
    <mat-dialog-content>
      <form [formGroup]="assignForm">
        <mat-form-field class="w-100">
          <mat-label>Candidat</mat-label>
          <mat-select formControlName="candidatId" required>
            <mat-option *ngFor="let candidat of candidats" [value]="candidat.id">
              {{ candidat.nomComplet }}
            </mat-option>
          </mat-select>
        </mat-form-field>
        <mat-form-field class="w-100">
          <mat-label>Date d'affectation</mat-label>
          <input matInput type="date" formControlName="dateAffectation" required>
        </mat-form-field>
      </form>
    </mat-dialog-content>
    <mat-dialog-actions>
      <button mat-button (click)="onCancel()">Annuler</button>
      <button mat-button color="primary" [disabled]="assignForm.invalid" (click)="onSubmit()">Affecter</button>
    </mat-dialog-actions>
  `,
  styles: [`
    .w-100 { width: 100%; margin-bottom: 1rem; }
  `]
})
export class AssignCandidateDialogComponent {
  assignForm: FormGroup;
  candidats: Candidat[];

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<AssignCandidateDialogComponent>,
    private affectationService: CandidatSessionService,
    @Inject(MAT_DIALOG_DATA) public data: { sessionId: number, candidats: Candidat[] }
  ) {
    this.candidats = data.candidats;
    this.assignForm = this.fb.group({
      candidatId: ['', Validators.required],
      dateAffectation: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.assignForm.valid) {
      const { candidatId, dateAffectation } = this.assignForm.value;
      this.affectationService.affecterCandidat(candidatId, this.data.sessionId, new Date(dateAffectation))
        .subscribe({
          next: () => this.dialogRef.close(true),
          error: (err) => {
            console.error('Erreur lors de l\'affectation', err);
            this.dialogRef.close(false);
          }
        });
    }
  }

  onCancel() {
    this.dialogRef.close(false);
  }
}