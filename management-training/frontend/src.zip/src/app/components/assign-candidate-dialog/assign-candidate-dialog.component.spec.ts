import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignCandidateDialogComponent } from './assign-candidate-dialog.component';

describe('AssignCandidateDialogComponent', () => {
  let component: AssignCandidateDialogComponent;
  let fixture: ComponentFixture<AssignCandidateDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssignCandidateDialogComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssignCandidateDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
