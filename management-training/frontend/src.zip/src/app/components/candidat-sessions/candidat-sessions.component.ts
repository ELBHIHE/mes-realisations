import { Component, OnInit } from '@angular/core';
import { Session, SessionService } from '../../services/session/session.service';
import { CommonModule, DatePipe } from '@angular/common';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
 
@Component({
  selector: 'app-candidat-sessions',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatIconModule,
    MatToolbarModule,
    DatePipe
  ],
  templateUrl: './candidat-sessions.component.html',
  styleUrl: './candidat-sessions.component.scss'
})
export class CandidatSessionsComponent implements OnInit {
 
 
  sessions: Session[] = [];
  user: any;
 
  constructor(private sessionService: SessionService) {}
 
  ngOnInit(): void {
    this.chargerSessions();
  }
 
  chargerSessions(): void {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      this.user = JSON.parse(userStr);
      const candidatId = this.user?.id;
 
      if (candidatId) {
        this.sessionService.getSessionsByCandidat(candidatId).subscribe({
          next: (data) => this.sessions = data,
          error: (err) => console.error('Erreur lors du chargement des sessions du candidat', err)
        });
      } else {
        console.warn('ID du candidat non trouvé dans l\'objet user');
      }
    } else {
      console.warn('Objet user non trouvé dans le localStorage');
    }
  }
}
 
 
