import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidatSessionsComponent } from './candidat-sessions.component';

describe('CandidatSessionsComponent', () => {
  let component: CandidatSessionsComponent;
  let fixture: ComponentFixture<CandidatSessionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CandidatSessionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CandidatSessionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
