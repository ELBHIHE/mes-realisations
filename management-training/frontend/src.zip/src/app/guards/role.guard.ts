import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';
 
@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
 
  constructor(private router: Router) {}
 
  canActivate(route: ActivatedRouteSnapshot): boolean {
    const expectedRoles = route.data['roles'] as string[];
    const userData = localStorage.getItem('user');
 
    if (!userData) {
      this.router.navigate(['/login']);
      return false;
    }
 
    const user = JSON.parse(userData);
    const userRole = user.type_utilisateur; // 👈 Utilisation du champ renvoyé par le backend
 
    if (expectedRoles.includes(userRole)) {
      return true;
    } else {
      this.router.navigate(['/dashboard']); // ou une page d'erreur
      return false;
    }
  }
}