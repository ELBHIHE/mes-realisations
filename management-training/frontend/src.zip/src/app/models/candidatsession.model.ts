export interface CandidatSession {
  id?: number;
  dateAffectation: Date;
  candidat: {
    id: number;
    nomComplet: string;
    email: string;
    profil: string;
    dateEntree: Date;
  };
  session: {
    id: number;
    dateDebut: Date;
    dateFin: Date;
    salleOuLien: string;
    formateur: { id: number; nomComplet: string };
    module: { id: number; nom: string };
  };
}
