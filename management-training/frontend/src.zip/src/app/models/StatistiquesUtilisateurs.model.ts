export interface StatistiquesUtilisateurs {
  total: number;
  candidats: number;
  formateurs: number;
  rhManagers: number;
}
