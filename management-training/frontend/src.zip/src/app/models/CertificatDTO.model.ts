export interface CertificatDTO {
  nomCandidat: string;
  nomModule: string;
  dateFin: Date;
  evaluation: string;
}
