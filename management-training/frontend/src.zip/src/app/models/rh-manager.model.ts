import { Utilisateur } from './utilisateur.model';

export interface RHManager extends Utilisateur {}