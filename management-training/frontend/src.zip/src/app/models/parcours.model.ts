// src/app/models/parcours.model.ts
export enum TypeParcours {
  FONDAMENTAL = 'FONDAMENTAL',
  TECHNIQUE = 'TECHNIQUE'
}

export interface Parcours {
  id?: number;
  nom: string;
  type: TypeParcours;
  duree: number;
  description: string;
  profil: string;
}
