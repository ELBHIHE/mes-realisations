export interface Utilisateur {
    id?: number;
    email: string;
    password: string;
    nomComplet: string;
    typeUtilisateur?: string;
  }