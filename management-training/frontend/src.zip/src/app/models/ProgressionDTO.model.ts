
export interface ProgressionDTO {
  id: number;
  status: string;
  dateDebut: Date;
  dateFin: Date;
  commentaire: string;
  evaluation: string;
  candidatId: number;
  candidatNom: string;
  moduleNom: string;
}
