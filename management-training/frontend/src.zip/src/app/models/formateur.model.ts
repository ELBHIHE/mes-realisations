import { Utilisateur } from './utilisateur.model';

export interface Formateur extends Utilisateur {
  profil: string;
}