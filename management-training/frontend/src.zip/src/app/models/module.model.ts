// src/app/models/module.model.ts
import { Parcours } from './parcours.model';

export interface Module {
  id?: number;
  nom: string;
  duree: number;
  contenu: string;
  parcours: Parcours;
}
