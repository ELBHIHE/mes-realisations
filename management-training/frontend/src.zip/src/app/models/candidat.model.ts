import { Utilisateur } from './utilisateur.model';

export interface Candidat extends Utilisateur {
  profil: string;
  dateEntree: Date;
}