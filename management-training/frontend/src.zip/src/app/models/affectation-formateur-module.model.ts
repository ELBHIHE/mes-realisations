// affectation-formateur-module.model.ts
export interface AffectationFormateurModule {
  id: number;
  dateAffectation: Date;
  formateur: {
    id: number;
    nomComplet: string;
    profil: string;
  };
  module: {
    id: number;
    nom: string;
    duree: number;
    contenu: string;
  };
}
