import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
 
export interface Session {
  id?: number;
  dateDebut: Date;
  dateFin: Date;
  salleOuLien: string;
  formateur: { id: number; nomComplet: string };
  module: { id: number; nom: string };
}
 
export interface SessionPayload {
  dateDebut: Date;
  dateFin: Date;
  salleOuLien: string;
  module: { id: number };
  formateur: { id: number };
}
 
 
@Injectable({
  providedIn: 'root'
})
export class SessionService {
  private apiUrl = 'http://localhost:8080/api/sessions';
 
  constructor(private http: HttpClient) {}
 
  getAllSessions(): Observable<Session[]> {
    return this.http.get<Session[]>(this.apiUrl);
  }
 
  addSession(session: Session): Observable<Session> {
    return this.http.post<Session>(this.apiUrl, session);
  }
 
  deleteSession(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
 
  getSessionsByFormateurId(formateurId: number): Observable<Session[]> {
     return this.http.get<Session[]>(`${this.apiUrl}/formateur/${formateurId}`);
  }
 
  addSessionFromFormateur(session: SessionPayload): Observable<Session> {
    return this.http.post<Session>(this.apiUrl, session);
}

 getSessionsByCandidat(id: number): Observable<Session[]> {
    return this.http.get<Session[]>(`${this.apiUrl}/candidat/${id}`);
  }
 
 
}