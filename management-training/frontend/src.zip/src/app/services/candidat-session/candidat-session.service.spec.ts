import { TestBed } from '@angular/core/testing';

import { CandidatSessionService } from './candidat-session.service';

describe('CandidatSessionService', () => {
  let service: CandidatSessionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CandidatSessionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
