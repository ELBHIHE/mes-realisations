import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CandidatSession } from '../../models/candidatsession.model';


@Injectable({
  providedIn: 'root'
})
export class CandidatSessionService {
  private apiUrl = 'http://localhost:8080/api/affectationcandidatsession';

  constructor(private http: HttpClient) {}

  affecterCandidat(candidatId: number, sessionId: number, dateAffectation: Date): Observable<CandidatSession> {
  const request = { candidatId, sessionId, dateAffectation };
  return this.http.post<CandidatSession>(`${this.apiUrl}/affecter`, request);
}


  getAllAffectations(): Observable<CandidatSession[]> {
    return this.http.get<CandidatSession[]>(this.apiUrl);
  }

  supprimerAffectation(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  

  
  getCandidatsBySession(sessionId: number): Observable<CandidatSession[]> {
  return this.http.get<CandidatSession[]>(`${this.apiUrl}/session/${sessionId}`);
  }

}
