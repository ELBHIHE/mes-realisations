import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Module } from '../../models/module.model';
 
@Injectable({ providedIn: 'root' })
export class ModuleService {
  private apiUrl = 'http://localhost:8080/api/modules';
   private apiUrlV2 = 'http://localhost:8080/api/modules/automatique';
 
  constructor(private http: HttpClient) {}
 
  getAll(): Observable<Module[]> {
    return this.http.get<Module[]>(this.apiUrl);
  }
 
  getById(id: number): Observable<Module> {
    return this.http.get<Module>(`${this.apiUrl}/${id}`);
  }
 
  create(module: Module): Observable<Module> {
    return this.http.post<Module>(this.apiUrl, module);
  }
 
  update(id: number, module: Module): Observable<Module> {
    return this.http.put<Module>(`${this.apiUrl}/${id}`, module);
  }
 
  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
 
  createWithFormateur(module: Module, formateurId: number): Observable<Module> {
    return this.http.post<Module>(`${this.apiUrlV2}?formateurId=${formateurId}`, module);
  }
 
  getModulesByCandidat(candidatId: number): Observable<Module[]> {
    return this.http.get<Module[]>(`${this.apiUrl}/candidat/${candidatId}`);
  }
}
 