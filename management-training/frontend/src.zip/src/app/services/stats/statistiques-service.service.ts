import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { StatistiquesUtilisateurs } from "../../models/StatistiquesUtilisateurs.model";
import { Observable } from 'rxjs';




// statistiques.service.ts
@Injectable({ providedIn: 'root' })
export class StatistiquesService {
  private apiUrl = 'http://localhost:8080/api/statistiques/utilisateurs';

  constructor(private http: HttpClient) {}

  getStats(): Observable<StatistiquesUtilisateurs> {
    return this.http.get<StatistiquesUtilisateurs>(this.apiUrl);
  }
}
