import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ProgressionDTO } from '../../models/ProgressionDTO.model';
import { CertificatDTO } from '../../models/CertificatDTO.model';



@Injectable({ providedIn: 'root' })
export class ProgressionService {
  private apiUrl = 'http://localhost:8080/api/progressions';

  constructor(private http: HttpClient) {}

  getProgressionsByCandidatId(candidatId: number): Observable<ProgressionDTO[]> {
    return this.http.get<ProgressionDTO[]>(`${this.apiUrl}/candidat/${candidatId}`);
  }

  updateProgression(id: number, updateDTO: any): Observable<ProgressionDTO> {
    return this.http.patch<ProgressionDTO>(`${this.apiUrl}/${id}`, updateDTO);
  }
  
  getCertificat(progressionId: number): Observable<CertificatDTO> {
  return this.http.get<CertificatDTO>(`${this.apiUrl}/certificat/${progressionId}`);
}
}

