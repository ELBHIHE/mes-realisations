// parcours.service.ts
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Parcours } from '../../models/parcours.model';


@Injectable({ providedIn: 'root' })
export class ParcoursService {
  private apiUrl = 'http://localhost:8080/api/parcours';

  constructor(private http: HttpClient) {}

  getAll(): Observable<Parcours[]> {
    return this.http.get<Parcours[]>(this.apiUrl);
  }

  getById(id: number): Observable<Parcours> {
    return this.http.get<Parcours>(`${this.apiUrl}/${id}`);
  }

  create(parcours: Parcours): Observable<Parcours> {
    return this.http.post<Parcours>(this.apiUrl, parcours);
  }

  update(id: number, parcours: Parcours): Observable<Parcours> {
    return this.http.put<Parcours>(`${this.apiUrl}/${id}`, parcours);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
