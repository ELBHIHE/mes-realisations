// formateur-module.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AffectationFormateurModule } from '../../models/affectation-formateur-module.model';
import { Module } from '../../models/module.model';

@Injectable({
  providedIn: 'root'
})
export class FormateurModuleService {
  private apiUrl = 'http://localhost:8080/api/formateur-modules';
  private apiUrlAffecter = 'http://localhost:8080/api/formateur-modules/affecter';

  constructor(private http: HttpClient) {}

  getAll(): Observable<AffectationFormateurModule[]> {
    return this.http.get<AffectationFormateurModule[]>(this.apiUrl);
  }

  delete(id: number): Observable<void> {
  return this.http.delete<void>(`${this.apiUrl}/${id}`);
}

create(affectation: {
  dateAffectation: Date;
  formateurId: number;
  moduleId: number;
}): Observable<AffectationFormateurModule> {
  return this.http.post<AffectationFormateurModule>(this.apiUrlAffecter, affectation);
}


getModulesByFormateurId(formateurId: number): Observable<Module[]> {
    return this.http.get<Module[]>(`${this.apiUrl}/${formateurId}`);
  }

}

