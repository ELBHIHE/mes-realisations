import { TestBed } from '@angular/core/testing';

import { FormateurModuleService } from './formateur-module.service';

describe('FormateurModuleService', () => {
  let service: FormateurModuleService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FormateurModuleService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
