import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Candidat } from '../../models/candidat.model';
import { Formateur } from '../../models/formateur.model';
import { RHManager } from '../../models/rh-manager.model';


@Injectable({
  providedIn: 'root'
})
export class UtilisateurService {
  private apiUrl = 'http://localhost:8080/api';

  constructor(private http: HttpClient) {}

  // Candidat CRUD
  getAllCandidats(): Observable<Candidat[]> {
    return this.http.get<Candidat[]>(`${this.apiUrl}/candidats`);
  }

  getCandidatById(id: number): Observable<Candidat> {
    return this.http.get<Candidat>(`${this.apiUrl}/candidats/${id}`);
  }

  addCandidat(candidat: Candidat): Observable<Candidat> {
    return this.http.post<Candidat>(`${this.apiUrl}/candidats`, candidat);
  }

  updateCandidat(id: number, candidat: Candidat): Observable<Candidat> {
    return this.http.put<Candidat>(`${this.apiUrl}/candidats/${id}`, candidat);
  }

  deleteCandidat(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/candidats/${id}`);
  }

  // Formateur CRUD
  getAllFormateurs(): Observable<Formateur[]> {
    return this.http.get<Formateur[]>(`${this.apiUrl}/formateurs`);
  }

  getFormateurById(id: number): Observable<Formateur> {
    return this.http.get<Formateur>(`${this.apiUrl}/formateurs/${id}`);
  }

  addFormateur(formateur: Formateur): Observable<Formateur> {
    return this.http.post<Formateur>(`${this.apiUrl}/formateurs`, formateur);
  }

  updateFormateur(id: number, formateur: Formateur): Observable<Formateur> {
    return this.http.put<Formateur>(`${this.apiUrl}/formateurs/${id}`, formateur);
  }

  deleteFormateur(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/formateurs/${id}`);
  }

  // RH Manager CRUD
  getAllRHManagers(): Observable<RHManager[]> {
    return this.http.get<RHManager[]>(`${this.apiUrl}/rh-managers`);
  }

  getRHManagerById(id: number): Observable<RHManager> {
    return this.http.get<RHManager>(`${this.apiUrl}/rh-managers/${id}`);
  }

  addRHManager(rhManager: RHManager): Observable<RHManager> {
    return this.http.post<RHManager>(`${this.apiUrl}/rh-managers`, rhManager);
  }

  updateRHManager(id: number, rhManager: RHManager): Observable<RHManager> {
    return this.http.put<RHManager>(`${this.apiUrl}/rh-managers/${id}`, rhManager);
  }

  deleteRHManager(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/rh-managers/${id}`);
  }
}