export interface ApiResponse {
    success: boolean;
    message: string;
    userId?: number; // Ajoutez d'autres champs si nécessaire
  }
  