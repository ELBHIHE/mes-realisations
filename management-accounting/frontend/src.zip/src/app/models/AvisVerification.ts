export interface AvisVerification {
    id: number;
    exerciceComptable: number;
    typeControle: string;
    impot: string;
    numAvisVerification: string;
    envoiAvis: string;
    dateNotification: Date;
    dateReception: Date;
    referenceEnvoi: string;
    formeNotification: string;
    etat: string;
  }