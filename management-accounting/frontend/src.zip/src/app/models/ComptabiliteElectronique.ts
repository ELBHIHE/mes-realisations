export interface ComptabiliteElectronique {
    id: number;
    nom: string;
  }
  