export interface ResponseApi {
    // Ajoutez ici les propriétés de votre réponse API
    message: string;
    // etc.
  }
  