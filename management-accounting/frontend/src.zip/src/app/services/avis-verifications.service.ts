import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AvisVerification } from '../models/AvisVerification';



@Injectable({
  providedIn: 'root'
})
export class AvisVerificationsService {
  private avisUrl = 'http://localhost:8080/api/avisVerification';
  private brouillonapi = 'http://localhost:8080/api/avisVerification';

  constructor(private http: HttpClient) { }

  getAvisByContribuableId(userId: number): Observable<AvisVerification[]> {
    return this.http.get<AvisVerification[]>(`${this.avisUrl}/${userId}`);
  }

  brouillonAvis(avisId: number): Observable<any> {
    return this.http.put(`${this.brouillonapi}/${avisId}/brouillon`, {});
  }
}
