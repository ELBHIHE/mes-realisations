import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ResponseApi } from '../models/ResponseApi';


@Injectable({
  providedIn: 'root'
})
export class ComptabiliteElectroniqueService {
  private apiUrl = 'http://localhost:8080/api/comptabilite/ajouter';
  private urlapi = 'http://localhost:8080/api/comptabilite';
  private deleteapi = 'http://localhost:8080/api/comptabilite/supprimer';
  private downloadapi = 'http://localhost:8080/api/comptabilite/comptabilites';
  private apivalidate = 'http://localhost:8080/api/avisVerification';
  private apirestore = 'http://localhost:8080/api/avisVerification';
  private apisubmit ='http://localhost:8080/api/avisVerification';
  private apireçu ='http://localhost:8080/api/avisVerification';
  private isvalidapi ='http://localhost:8080/api/avisVerification';


  constructor(private http: HttpClient) { }

  chargerComptabilite(avisId: number, nom: string, file: File): Observable<ResponseApi> {
    const formData: FormData = new FormData();
    formData.append('avisDeVerificationId', avisId.toString());
    formData.append('nom', nom);
    formData.append('file', file);

    return this.http.post<ResponseApi>(this.apiUrl, formData);
  }

  getComptabilites(avisId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.urlapi}/lister/${avisId}`);
  }

  deleteComptabilite(id: number): Observable<void> {
    return this.http.delete<void>(`${this.deleteapi}/${id}`);
  }

  downloadComptabilite(id: number): Observable<Blob> {
    return this.http.get(`${this.downloadapi}/${id}/download`, { responseType: 'blob' });
  }

  validateAvis(avisId: number): Observable<any> {
    return this.http.put(`${this.apivalidate}/${avisId}/validate`, {});
  }

  restoreAvis(avisId: number): Observable<any> {
    return this.http.post(`${this.apirestore}/${avisId}/restore`, {});
  }


  submitAvis(avisId: number): Observable<any> {
    return this.http.post(`${this.apisubmit}/${avisId}/submit`, {});
  }

  downloadReceipt(avisId: number): Observable<Blob> {
    return this.http.get(`${this.apireçu}/${avisId}/receipt`, { responseType: 'blob' });
  }

  checkAvisValidity(avisId: number): Observable<boolean> {
    return this.http.get<boolean>(`${this.isvalidapi}/${avisId}/valide`);
  }
}
