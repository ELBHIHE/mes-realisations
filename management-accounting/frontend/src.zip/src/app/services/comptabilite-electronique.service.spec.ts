import { TestBed } from '@angular/core/testing';

import { ComptabiliteElectroniqueService } from './comptabilite-electronique.service';

describe('ComptabiliteElectroniqueService', () => {
  let service: ComptabiliteElectroniqueService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ComptabiliteElectroniqueService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
