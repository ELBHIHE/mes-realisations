import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ValidationStateService {
  private isValidated: boolean = false;

  constructor() { }

  setValidationState(state: boolean): void {
    this.isValidated = state;
    // Stockez l'état dans le localStorage pour persistance
    localStorage.setItem('isValidated', JSON.stringify(state));
  }

  getValidationState(): boolean {
    const storedState = localStorage.getItem('isValidated');
    return storedState ? JSON.parse(storedState) : this.isValidated;
  }
}
