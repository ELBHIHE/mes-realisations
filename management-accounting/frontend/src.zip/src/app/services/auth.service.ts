import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

interface LoginResponse {
  success: boolean;
  message: string;
  userId?: number;
  prenom?: string;
  nom?: string;
  ice?: number;
  identifiantFiscal?: number;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private isLoggedIn = false;
  private loginUrl = 'http://localhost:8080/api/login';

  constructor(private http: HttpClient) { }

  login(login: string, password: string): Observable<LoginResponse> {
    this.isLoggedIn = true;
    return this.http.post<LoginResponse>(this.loginUrl, { login, password });
  }

  checkLoginStatus(): boolean {
    return this.isLoggedIn;
  }
}