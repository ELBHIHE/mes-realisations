import { TestBed } from '@angular/core/testing';

import { AvisVerificationsService } from './avis-verifications.service';

describe('AvisVerificationsService', () => {
  let service: AvisVerificationsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AvisVerificationsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
