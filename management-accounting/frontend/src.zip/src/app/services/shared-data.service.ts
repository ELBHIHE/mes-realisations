import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedDataService {
  private exerciceComptable: number | null = null;
  private avisId: number | null = null;
  private numAvisVerification: string | null = null;
  private referenceEnvoi: string | null = null;

  setExerciceComptable(exercice: number | null): void {
    this.exerciceComptable = exercice;
  }

  getExerciceComptable(): number | null {
    return this.exerciceComptable;
  }

  setAvisId(id: number | null): void {
    this.avisId = id;
  }

  getAvisId(): number | null {
    return this.avisId;
  }

  setNumAvisVerification(num: string | null): void {
    this.numAvisVerification = num;
  }

  getNumAvisVerification(): string | null {
    return this.numAvisVerification;
  }

  setReferenceEnvoi(reference: string | null): void {
    this.referenceEnvoi = reference;
  }

  getReferenceEnvoi(): string | null {
    return this.referenceEnvoi;
  }
}
