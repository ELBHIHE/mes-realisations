import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginFormComponent } from './components/login-form/login-form.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { HomeComponent } from './components/home/home.component';
import { AvisVerificationsComponent } from './components/avis-verifications/avis-verifications.component';
import { ChargerComptabiliteComponent } from './components/charger-comptabilite/charger-comptabilite.component';
import { ValidationPageComponent } from './components/validation-page/validation-page.component';

const routes: Routes = [
  { path: 'login', component: LoginFormComponent },
  { path: 'avis-verifications', component: AvisVerificationsComponent },
  { path: 'charger-comptabilite', component: ChargerComptabiliteComponent },
  { path: 'validation-page', component: ValidationPageComponent },
  // Autres routes de votre application si nécessaire
  { path: 'dashboard', component: DashboardComponent },
  { path: 'home', component: HomeComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', redirectTo: '/home' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
