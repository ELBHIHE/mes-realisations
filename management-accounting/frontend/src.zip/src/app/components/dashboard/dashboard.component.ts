import { Component, OnInit } from '@angular/core';
import { AvisVerification } from '../../models/AvisVerification';
import { AvisVerificationsService } from '../../services/avis-verifications.service';
import { Router } from '@angular/router';
import { SharedDataService } from '../../services/shared-data.service';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  prenom: string = '';
  nom: string = '';
  ice: number = 0;
  identifiantFiscal: number = 0;
  avisList: AvisVerification[] = [];
  successMessage: string = '';

  constructor(
    private avisService: AvisVerificationsService,
    private router: Router,
    private sharedDataService: SharedDataService,
    public dialog: MatDialog
  ) { }

  ngOnInit(): void {
    this.prenom = localStorage.getItem('prenom')!;
    this.nom = localStorage.getItem('nom')!;

    const iceStr = localStorage.getItem('ice');
    const identifiantFiscalStr = localStorage.getItem('identifiantFiscal');

    this.ice = iceStr ? parseInt(iceStr, 10) : 0;
    this.identifiantFiscal = identifiantFiscalStr ? parseInt(identifiantFiscalStr, 10) : 0;

    const userId = +localStorage.getItem('userId')!;
    this.avisService.getAvisByContribuableId(userId).subscribe({
      next: avis => {
        this.avisList = avis;
      },
      error: err => {
        console.error('Error fetching audit notices:', err);
      }
    });
  }

  showSuccessMessage(message: string): void {
    this.successMessage = message;
    setTimeout(() => {
      this.successMessage = '';
    }, 5000);
  }

  goToForm(exerciceComptable: number, avisId: number, numAvisVerification: string, referenceEnvoi: string) {
    this.sharedDataService.setExerciceComptable(exerciceComptable);
    this.sharedDataService.setAvisId(avisId);
    this.sharedDataService.setNumAvisVerification(numAvisVerification);
    this.sharedDataService.setReferenceEnvoi(referenceEnvoi);
    this.router.navigate(['/charger-comptabilite']);
  }

  editForm(exerciceComptable: number, avisId: number, numAvisVerification: string, referenceEnvoi: string): void {
    this.sharedDataService.setExerciceComptable(exerciceComptable);
    this.sharedDataService.setAvisId(avisId);
    this.sharedDataService.setNumAvisVerification(numAvisVerification);
    this.sharedDataService.setReferenceEnvoi(referenceEnvoi);
    this.router.navigate(['/validation-page']);
  }

  confirmReopen(avis: AvisVerification): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '600px',
      panelClass: 'custom-dialog',
      data: {
        title: 'Confirmation',
        message: 'Êtes-vous sûr de vouloir réouvrir cet avis de vérification ?'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.brouillonAvis(avis.id);
      }
    });
  }

  brouillonAvis(avisId: number): void {
    this.avisService.brouillonAvis(avisId).subscribe({
      next: () => {
        // Actualiser la liste des avis
        const userId = +localStorage.getItem('userId')!;
        this.avisService.getAvisByContribuableId(userId).subscribe({
          next: avis => {
            this.avisList = avis;
          },
          error: err => {
            console.error('Error fetching audit notices:', err);
          }
        });
      },
      error: err => {
        console.error('Erreur lors de la réouverture de l\'avis de vérification', err);
      }
    });
  }
}
