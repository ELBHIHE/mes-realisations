import { Component, HostListener, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent implements OnInit{

  isVisible = false;

  ngOnInit() {
    // Initialisez la visibilité au chargement de la page
    this.updateFooterVisibility();
  }

  @HostListener('window:scroll', ['$event'])
  onWindowScroll() {
    this.updateFooterVisibility();
  }

  private updateFooterVisibility() {
    const scrollPosition = window.scrollY + window.innerHeight;
    const documentHeight = document.documentElement.scrollHeight;

    // Ajustez la valeur 100 pixels selon vos besoins
    this.isVisible = scrollPosition >= documentHeight - 100;
  }
}
