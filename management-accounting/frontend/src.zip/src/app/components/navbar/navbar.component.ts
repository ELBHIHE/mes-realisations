import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { interval, Subscription } from 'rxjs';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit, OnDestroy {

  isLoggedIn: boolean = false;
  currentDateTime: string = '';
  private subscription: Subscription | undefined;
  prenom: string = '';
  nom: string = '';
  identifiantFiscal: number = 0;
  showNavbar: boolean = true; // Contrôle la visibilité de la navbar

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Vérifier l'état de connexion à chaque changement de route
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.isLoggedIn = !!localStorage.getItem('userId');
        if (this.isLoggedIn) {
          this.prenom = localStorage.getItem('prenom')!;
          this.nom = localStorage.getItem('nom')!;
          const identifiantFiscalStr = localStorage.getItem('identifiantFiscal');
          this.identifiantFiscal = identifiantFiscalStr ? parseInt(identifiantFiscalStr, 10) : 0;
        }
      }
    });

    // Initialement vérifier l'état de connexion
    this.isLoggedIn = !!localStorage.getItem('userId');
    if (this.isLoggedIn) {
      this.prenom = localStorage.getItem('prenom')!;
      this.nom = localStorage.getItem('nom')!;
   
    }

    // Mettre à jour la date et l'heure chaque seconde
    this.updateDateTime();
    this.subscription = interval(1000).subscribe(() => this.updateDateTime());
  }

  ngOnDestroy(): void {
    // Se désabonner pour éviter les fuites de mémoire
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  updateDateTime(): void {
    const now = new Date();
    const days = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
    const months = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];

    const dayName = days[now.getDay()];
    const dayNumber = now.getDate();
    const monthName = months[now.getMonth()];
    const year = now.getFullYear();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');

    this.currentDateTime = `${dayName} ${dayNumber} ${monthName} ${year} ${hours}:${minutes}:${seconds}`;
  }

  logout(): void {
    // Supprimer les informations utilisateur du localStorage
    localStorage.removeItem('userId');
    localStorage.removeItem('prenom');
    localStorage.removeItem('nom');

    // Rediriger vers la page de login
    this.router.navigate(['/login']);
  }

  @HostListener('window:scroll', ['$event'])
  onScroll(event: Event): void {
    const scrollPosition = window.scrollY;
    this.showNavbar = scrollPosition < 100; // Ajuster le seuil de défilement selon vos besoins
  }
}
