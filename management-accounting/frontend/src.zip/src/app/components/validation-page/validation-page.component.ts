import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ComptabiliteElectroniqueService } from '../../services/comptabilite-electronique.service';
import { SharedDataService } from '../../services/shared-data.service';
import { ComptabiliteElectronique } from '../../models/ComptabiliteElectronique';
import { saveAs } from 'file-saver';
import jsPDF from 'jspdf'; // Import jsPDF

@Component({
  selector: 'app-validation-page',
  templateUrl: './validation-page.component.html',
  styleUrls: ['./validation-page.component.css']
})
export class ValidationPageComponent implements OnInit {
  exerciceComptable: number | null = null;
  numAvisVerification: string | null = null;
  referenceEnvoi: string | null = null;
  avisId: number | null = null;
  comptabiliteList: ComptabiliteElectronique[] = [];
  successMessage: string = '';
  erreurmessage: string = '';

  constructor(
    private router: Router,
    private comptabiliteService: ComptabiliteElectroniqueService,
    private sharedDataService: SharedDataService
  ) {}

  ngOnInit(): void {
    this.exerciceComptable = this.sharedDataService.getExerciceComptable();
    this.numAvisVerification = this.sharedDataService.getNumAvisVerification();
    this.referenceEnvoi = this.sharedDataService.getReferenceEnvoi();
    this.avisId = this.sharedDataService.getAvisId();

    if (this.avisId !== null) {
      this.loadComptabilites();
    }
  }

  loadComptabilites(): void {
    if (this.avisId !== null) {
      this.comptabiliteService.getComptabilites(this.avisId).subscribe((data: ComptabiliteElectronique[]) => {
        this.comptabiliteList = data;
      });
    }
  }

  onRestore(): void {
    if (this.avisId !== null) {
      this.comptabiliteService.restoreAvis(this.avisId).subscribe({
        next: (response) => {
          console.log('Avis restauré avec succès', response);
          this.successMessage = 'Avis restauré avec succès';
          this.router.navigate(['/charger-comptabilite']);
        },
        error: (err) => {
          console.error('Erreur lors de la restauration de l\'avis', err);
          this.erreurmessage = 'Erreur lors de la restauration de l\'avis';
        }
      });
    }
  }

  onSubmit(): void {
    if (this.avisId !== null) {
      this.comptabiliteService.submitAvis(this.avisId).subscribe({
        next: (response) => {
          console.log('Avis soumis avec succès', response);
          this.successMessage = 'Avis soumis avec succès';
          this.generateReceipt(); // Generate and download the receipt after successful submission
          this.router.navigate(['/dashboard']);
        },
        error: (err) => {
          console.error('Erreur lors de la soumission de l\'avis', err);
          this.erreurmessage = 'Erreur lors de la soumission de l\'avis';
        }
      });
    }
  }

  downloadComptabilite(id: number): void {
    this.comptabiliteService.downloadComptabilite(id).subscribe((blob: Blob) => {
      saveAs(blob, `comptabilite_${id}.xml`);
    });
  }

  generateReceipt(): void {
    const doc = new jsPDF();
    
    // Ajouter le logo en haut à droite
    const logoUrl = 'assets/dgi.png'; // Chemin vers le logo ou l'URL de l'image
    const logoX = 160; // Position X pour le logo
    const logoY = 10; // Position Y pour le logo
    const logoWidth = 40; // Augmenter la largeur du logo
    const logoHeight = 30; // Garder la hauteur du logo
    doc.addImage(logoUrl, 'PNG', logoX, logoY, logoWidth, logoHeight); // Ajouter le logo à droite
  
    // Ajouter un autre logo en haut à gauche
    const leftLogoUrl = 'assets/royaume.png'; // Chemin vers l'autre logo ou l'URL de l'image
    const leftLogoX = 10; // Position X pour le logo à gauche
    const leftLogoY = 10; // Position Y pour le logo à gauche
    const leftLogoWidth = 40; // Augmenter la largeur du logo
    const leftLogoHeight = 30; // Garder la hauteur du logo
    doc.addImage(leftLogoUrl, 'PNG', leftLogoX, leftLogoY, leftLogoWidth, leftLogoHeight); // Ajouter le logo à gauche
  
    // Mise en forme du texte
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('Reçu de Dépôt : ', 10, 50);
  
    doc.setFontSize(14);
    doc.setFont('helvetica', 'normal');
    doc.text(`Exercice Comptable: ${this.exerciceComptable}`, 10, 70);
    doc.text(`Numéro d'Avis de Vérification: ${this.numAvisVerification}`, 10, 85);
    doc.text(`Référence d'Envoi: ${this.referenceEnvoi}`, 10, 100);
  
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('Liste des Comptabilités Électroniques:', 10, 120);
  
    // Liste des comptabilités électroniques
    let y = 140;
    this.comptabiliteList.forEach((comptabilite, index) => {
      doc.setFontSize(12);
      doc.text(`${index + 1}. ${comptabilite.nom}`, 10, y); // Utilisation de la propriété 'nom'
      y += 10;
    });
  
    // Enregistrement du PDF
    doc.save(`reçu_de_dépôt_${this.numAvisVerification}.pdf`);
  }
  
  

  showSuccessMessage(message: string): void {
    this.successMessage = message;
    setTimeout(() => {
      this.successMessage = '';
    }, 5000);
  }

  showErreurMessage(message: string): void {
    this.erreurmessage = message;
    setTimeout(() => {
      this.erreurmessage = '';
    }, 5000);
  }
}
