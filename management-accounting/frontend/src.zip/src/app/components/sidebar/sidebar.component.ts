import { Component, OnInit } from '@angular/core';
import { faFileAlt, faUpload } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css'
})
export class SidebarComponent implements OnInit {
  faFileAlt = faFileAlt;
  faUpload = faUpload;
  isSubmenuOpen = false;

  constructor() {}

  ngOnInit(): void {}


  toggleSubmenu() {
    this.isSubmenuOpen = !this.isSubmenuOpen;
  }

}
