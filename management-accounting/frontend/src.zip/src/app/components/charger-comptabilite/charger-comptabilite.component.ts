import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ComptabiliteElectroniqueService } from '../../services/comptabilite-electronique.service';
import { ResponseApi } from '../../models/ResponseApi';
import { ComptabiliteElectronique } from '../../models/ComptabiliteElectronique';
import { saveAs } from 'file-saver';
import { SharedDataService } from '../../services/shared-data.service';

@Component({
  selector: 'app-charger-comptabilite',
  templateUrl: './charger-comptabilite.component.html',
  styleUrls: ['./charger-comptabilite.component.css']
})
export class ChargerComptabiliteComponent implements OnInit {
  @ViewChild('fileInput') fileInput!: ElementRef;
  exerciceComptable: number | null = null;
  numAvisVerification: string | null = null;
  referenceEnvoi: string | null = null;
  avisId: number | null = null;
  nom: string = '';
  selectedFile: File | null = null;
  comptabiliteList: ComptabiliteElectronique[] = [];
  successMessage: string = '';
  erreurmessage: string = '';
  isValid: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private comptabiliteService: ComptabiliteElectroniqueService,
    private sharedDataService: SharedDataService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.exerciceComptable = this.sharedDataService.getExerciceComptable();
    this.avisId = this.sharedDataService.getAvisId();
    this.numAvisVerification = this.sharedDataService.getNumAvisVerification();
    this.referenceEnvoi = this.sharedDataService.getReferenceEnvoi();

    if (this.avisId !== null) {
      this.loadComptabilites();
      this.checkAvisValidity();
    }
  }

  checkAvisValidity(): void {
    if (this.avisId !== null) {
      this.comptabiliteService.checkAvisValidity(this.avisId).subscribe((isValid: boolean) => {
        this.isValid = isValid;
      });
    }
  }

  onValidate(): void {
    if (
      this.exerciceComptable !== null &&
      this.numAvisVerification !== null &&
      this.referenceEnvoi !== null &&
      this.avisId !== null
    ) {
      this.comptabiliteService.validateAvis(this.avisId).subscribe({
        next: (response) => {
          console.log('Avis validé avec succès', response);
          this.showSuccessMessage('Avis validé avec succès');
          this.sharedDataService.setExerciceComptable(this.exerciceComptable); 
          this.sharedDataService.setNumAvisVerification(this.numAvisVerification);
          this.sharedDataService.setReferenceEnvoi(this.referenceEnvoi);
          this.sharedDataService.setAvisId(this.avisId); 
          this.router.navigate(['/validation-page']);
        },
        error: (err) => {
          console.error('Erreur lors de la validation de l\'avis', err);
          this.showErreurMessage('Erreur lors de la validation de l\'avis');
        }
      });
    } else {
      console.error('Les données nécessaires pour la validation sont manquantes.');
      this.showErreurMessage('Les données nécessaires pour la validation sont manquantes.');
    }
  }


  onFileSelected(event: any): void {
    this.selectedFile = event.target.files[0];
    console.log('File selected:', this.selectedFile);
  }
  

  onSubmit(): void {
    console.log('Form submitted:', {
      avisId: this.avisId,
      nom: this.nom,
      selectedFile: this.selectedFile
    });

    if (!this.avisId) {
      this.showErreurMessage('L\'ID de l\'avis de vérification est manquant.');
      return;
    }
    if (!this.nom) {
      this.showErreurMessage('Le nom du fichier est obligatoire.');
      return;
    }
    if (!this.selectedFile) {
      this.showErreurMessage('Le fichier est obligatoire.');
      return;
    }

    this.comptabiliteService.chargerComptabilite(this.avisId, this.nom, this.selectedFile)
      .subscribe({
        next: (response: ResponseApi) => {
          console.log('Comptabilité électronique chargée avec succès', response);
          this.showSuccessMessage('Comptabilité électronique chargée avec succès');
          this.nom = '';
          this.selectedFile = null;
          this.fileInput.nativeElement.value = ''; // Réinitialiser le champ de fichier
          this.loadComptabilites();
        },
        error: (err: any) => {
          console.error('Erreur lors du chargement de la comptabilité électronique', err);
          this.showErreurMessage('La comptabilité électronique doit être sous format XML');
        },
        complete: () => {
          console.log('Upload complete');
        }
      });
  }

  loadComptabilites(): void {
    if (this.avisId !== null) {
      this.comptabiliteService.getComptabilites(this.avisId).subscribe((data: ComptabiliteElectronique[]) => {
        console.log(data);
        this.comptabiliteList = data;
      });
    }
  }

  deleteComptabilite(id: number): void {
    this.comptabiliteService.deleteComptabilite(id).subscribe({
      next: () => {
        console.log('Comptabilité électronique supprimée avec succès');
        this.showSuccessMessage('Comptabilité électronique supprimée avec succès');
        this.loadComptabilites();
      },
      error: (err: any) => {
        console.error('Erreur lors de la suppression de la comptabilité électronique', err);
      }
    });
  }

  downloadComptabilite(id: number): void {
    this.comptabiliteService.downloadComptabilite(id).subscribe({
      next: (response: Blob) => {
        saveAs(response, `comptabilite_${id}.xml`);
        this.showSuccessMessage('Comptabilité électronique téléchargée avec succès');
      },
      error: (err: any) => {
        console.error('Erreur lors du téléchargement de la comptabilité électronique', err);
      }
    });
  }

  showSuccessMessage(message: string): void {
    this.successMessage = message;
    setTimeout(() => {
      this.successMessage = '';
    }, 3000);
  }

  showErreurMessage(message: string): void {
    this.erreurmessage = message;
    setTimeout(() => {
      this.erreurmessage = '';
    }, 7000);
  }
}
