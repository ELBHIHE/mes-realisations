import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChargerComptabiliteComponent } from './charger-comptabilite.component';

describe('ChargerComptabiliteComponent', () => {
  let component: ChargerComptabiliteComponent;
  let fixture: ComponentFixture<ChargerComptabiliteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChargerComptabiliteComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChargerComptabiliteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
