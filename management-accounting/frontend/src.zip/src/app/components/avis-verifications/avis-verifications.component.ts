import { Component, OnInit } from '@angular/core';
import { AvisVerification } from '../../models/AvisVerification';
import { AvisVerificationsService } from '../../services/avis-verifications.service';

@Component({
  selector: 'app-avis-verifications',
  templateUrl: './avis-verifications.component.html',
  styleUrl: './avis-verifications.component.css'
})
export class AvisVerificationsComponent implements OnInit {
  prenom: string = '';
  nom: string = '';
  ice: number = 0;
  identifiantFiscal: number = 0;
  avisList: AvisVerification[] = [];

  constructor(private avisService: AvisVerificationsService) { }

  ngOnInit(): void {
    this.prenom = localStorage.getItem('prenom')!;
    this.nom = localStorage.getItem('nom')!;

    const iceStr = localStorage.getItem('ice');
    const identifiantFiscalStr = localStorage.getItem('identifiantFiscal');
  
    this.ice = iceStr ? parseInt(iceStr, 10) : 0;
    this.identifiantFiscal = identifiantFiscalStr ? parseInt(identifiantFiscalStr, 10) : 0;

    const userId = +localStorage.getItem('userId')!;
    this.avisService.getAvisByContribuableId(userId).subscribe({
      next: avis => {
        this.avisList = avis;
      },
      error: err => {
        console.error('Error fetching audit notices:', err);
      }
    });
  }
}