import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvisVerificationsComponent } from './avis-verifications.component';

describe('AvisVerificationsComponent', () => {
  let component: AvisVerificationsComponent;
  let fixture: ComponentFixture<AvisVerificationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AvisVerificationsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AvisVerificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
