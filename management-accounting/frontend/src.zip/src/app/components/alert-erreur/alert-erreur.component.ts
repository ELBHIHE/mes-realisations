import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-alert-erreur',
  templateUrl: './alert-erreur.component.html',
  styleUrl: './alert-erreur.component.css'
})
export class AlertErreurComponent {
  @Input() message: string = '';
}
