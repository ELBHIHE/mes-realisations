import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlertErreurComponent } from './alert-erreur.component';

describe('AlertErreurComponent', () => {
  let component: AlertErreurComponent;
  let fixture: ComponentFixture<AlertErreurComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AlertErreurComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AlertErreurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
