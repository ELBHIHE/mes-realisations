import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { ApiResponse } from '../../models/ApiResponse';
import { Observer } from 'rxjs';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrl: './login-form.component.css'
})
export class LoginFormComponent {
  login: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private authService: AuthService, private router: Router) { }


  
  onSubmit(): void {
    this.authService.login(this.login, this.password).subscribe({
      next: response => {
        if (response.success) {
          // Stocker les informations utilisateur dans le localStorage ou un service partagé
          console.log('Login successful:', response);
          localStorage.setItem('userId', response.userId!.toString());
          localStorage.setItem('prenom', response.prenom!);
          localStorage.setItem('nom', response.nom!);
          localStorage.setItem('ice', String(response.ice)); // Save as string
          localStorage.setItem('identifiantFiscal', String(response.identifiantFiscal));
          // Rediriger vers la page de compte
          this.router.navigate(['/home']);
        } else {
          this.errorMessage = response.message;
        }
      },
      error: err => {
        this.errorMessage = 'Login failed. Please try again.';
      }
    });
  }
}