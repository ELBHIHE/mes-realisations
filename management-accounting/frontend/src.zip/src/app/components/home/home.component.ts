import { Component, OnInit } from '@angular/core';
import { AvisVerificationsService } from '../../services/avis-verifications.service';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit{

  prenom: string = '';
  nom: string = '';
  ice: number = 0;
  identifiantFiscal: number = 0;
  showWelcomeMessage = true;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.prenom = localStorage.getItem('prenom')!;
    this.nom = localStorage.getItem('nom')!;

      // Retrieve and parse 'ice' and 'identifiantFiscal' from localStorage
  const iceStr = localStorage.getItem('ice');
  const identifiantFiscalStr = localStorage.getItem('identifiantFiscal');

  this.ice = iceStr ? parseInt(iceStr, 10) : 0;
  this.identifiantFiscal = identifiantFiscalStr ? parseInt(identifiantFiscalStr, 10) : 0;

    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.showWelcomeMessage = event.urlAfterRedirects === '/home';
      }
    });
  }
}