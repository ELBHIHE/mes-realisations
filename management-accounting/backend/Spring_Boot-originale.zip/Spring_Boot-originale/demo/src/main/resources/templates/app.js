var app = angular.module('myApp', []);

app.controller('StudentController', function($scope, $http) {
    $http.get('http://localhost:8080/students')
        .then(function(response) {
            $scope.students = response.data;
        }, function(error) {
            console.error('Erreur lors de la récupération des étudiants : ', error);
        });
});
