package com.example.demo.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApiResponse {

    private boolean success;
    private String message;
    private Long userId;
    private String prenom;
    private String nom;
    private Long identifiantFiscal; // New field
    private Long ice; // New field

    public ApiResponse(boolean success, String message, Long userId, String prenom, String nom, Long identifiantFiscal, Long ice) {
        this.success = success;
        this.message = message;
        this.userId = userId;
        this.prenom = prenom;
        this.nom = nom;
        this.identifiantFiscal = identifiantFiscal;
        this.ice = ice;
    }
}
