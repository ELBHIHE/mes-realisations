package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.models.AvisDeVerification;

@Repository
public interface AvisDeVerificationRepository extends JpaRepository<AvisDeVerification, Long> {
    List<AvisDeVerification> findByContribuableId(Long contribuableId);
}
