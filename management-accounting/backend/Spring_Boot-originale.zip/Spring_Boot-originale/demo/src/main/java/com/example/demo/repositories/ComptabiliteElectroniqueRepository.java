package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.models.ComptabiliteElectronique;

public interface ComptabiliteElectroniqueRepository extends JpaRepository<ComptabiliteElectronique, Long> {
    List<ComptabiliteElectronique> findByAvisDeVerificationId(Long avisId);
}
