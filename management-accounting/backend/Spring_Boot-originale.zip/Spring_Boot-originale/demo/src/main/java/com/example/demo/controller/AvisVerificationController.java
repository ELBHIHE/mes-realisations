package com.example.demo.controller;


import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.AvisDeVerification;
import com.example.demo.services.AvisDeVerificationService;
import com.itextpdf.text.DocumentException;

import org.springframework.http.HttpHeaders;


@RestController
@RequestMapping("/api/avisVerification")
public class AvisVerificationController {
   

    private final AvisDeVerificationService avisService;

    public AvisVerificationController(AvisDeVerificationService avisService) {
        this.avisService = avisService;
    }

    @GetMapping("/{contribuableId}")
    public ResponseEntity<List<AvisDeVerification>> getAvisByContribuableId(@PathVariable Long contribuableId) {
        List<AvisDeVerification> avisList = avisService.getAvisByContribuableId(contribuableId);
        if (avisList.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(avisList);
    }

    @PutMapping("/{avisId}/validate")
    public ResponseEntity<AvisDeVerification> validateAvis(@PathVariable Long avisId) {
        try {
            AvisDeVerification updatedAvis = avisService.validateAvis(avisId);
            return ResponseEntity.ok(updatedAvis);
        } catch (Exception e) {
            return ResponseEntity.status(404).body(null);
        }
    }

    @PutMapping("/{avisId}/brouillon")
    public ResponseEntity<AvisDeVerification> brouillonAvis(@PathVariable Long avisId) {
        try {
            AvisDeVerification updatedAvis = avisService.BrouillonAvis(avisId);
            return ResponseEntity.ok(updatedAvis);
        } catch (Exception e) {
            return ResponseEntity.status(404).body(null);
        }
    }

    @PostMapping("/{id}/restore")
    public ResponseEntity<?> restoreAvis(@PathVariable Long id) {
        try {
            avisService.restoreAvis(id);
            return ResponseEntity.ok().body(Collections.singletonMap("message", "Avis restauré avec succès"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonMap("error", "Erreur lors de la restauration de l'avis"));
        }
    }

    @PostMapping("/{id}/submit")
    public ResponseEntity<Map<String, String>> submitAvis(@PathVariable Long id) {
        try {
            avisService.submitAvis(id);
            Map<String, String> response = new HashMap<>();
            response.put("message", "Avis soumis avec succès");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Erreur lors de la soumission de l'avis");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

     @GetMapping("/{avisId}/receipt")
    public ResponseEntity<InputStreamResource> downloadReceipt(@PathVariable Long avisId) {
        try {
            ByteArrayInputStream bis = avisService.generateReceipt(avisId);
            HttpHeaders headers = new HttpHeaders();
            headers.add("Content-Disposition", "attachment; filename=receipt.pdf");
            return ResponseEntity.ok()
                    .headers(headers)
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(new InputStreamResource(bis));
        } catch (IOException | DocumentException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/{avisId}/valide")
    public ResponseEntity<Boolean> checkAvisValidity(@PathVariable Long avisId) {
        boolean isValid = avisService.isAvisValid(avisId);
        return ResponseEntity.ok(isValid);
    }

    

}