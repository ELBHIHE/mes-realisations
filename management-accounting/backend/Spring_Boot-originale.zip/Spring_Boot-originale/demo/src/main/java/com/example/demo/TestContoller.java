package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestContoller {
    @RequestMapping("/hello")
    String Helloworld(){
        return "Hello world, Spring Boot!";
    }
}
