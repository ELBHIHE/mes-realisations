package com.example.demo.models;

import jakarta.persistence.*;
import lombok.*;

import java.util.Set;


@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name="CONTRIBUABLE")
public class Contribuable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String nom;
    private String prenom;
    private String login;
    private String password;
    private Long identifiant_fiscal;
    private Long ICE; 
    

    @OneToMany(mappedBy = "contribuable", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<AvisDeVerification> avisDeVerifications;

}
