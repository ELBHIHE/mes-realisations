package com.example.demo.models;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.Set;


@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Data
@Table(name="AVISDEVERIFICATION")
public class AvisDeVerification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private int exerciceComptable;
    private String typeControle;
    private String impot;
    private String numAvisVerification;
    private String envoiAvis;
    private Date dateNotification;
    private Date dateReception;
    private String referenceEnvoi;
    private String formeNotification;
    private String etat;

    @ManyToOne
    @JoinColumn(name = "contribuable_id")
    private Contribuable contribuable;

    @OneToMany(mappedBy = "avisDeVerification", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ComptabiliteElectronique> comptabiliteElectroniques;
}

