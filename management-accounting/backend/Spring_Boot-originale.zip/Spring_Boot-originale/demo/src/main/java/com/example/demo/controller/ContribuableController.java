package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.Contribuable;
import com.example.demo.repositories.ContribuableRepository;
import com.example.demo.response.ApiResponse;
import com.example.demo.response.LoginRequest;
import com.example.demo.services.ContribuableService;

@RestController
@RequestMapping("/api")
public class ContribuableController {
    
    @Autowired
    private  ContribuableService ContribuableService;

    public ContribuableController(ContribuableService ContribuableService, ContribuableRepository contribuableRepository) {
        this.ContribuableService = ContribuableService;
    }


    /*@PostMapping(value = "/login", consumes = "application/json", produces = "application/json")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        ApiResponse loginResponse = ContribuableService.login(loginRequest);

        if (loginResponse.isSuccess()) {
            return ResponseEntity.ok(loginResponse);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(loginResponse);
        }
    }*/

    @PostMapping("/register")
    public ResponseEntity<Contribuable> registerContribuable(@RequestBody Contribuable contribuable) {
        Contribuable registeredContribuable = ContribuableService.registerContribuable(contribuable);
        return ResponseEntity.ok(registeredContribuable);
    }

    // Méthode pour se connecter
    @PostMapping("/login")
    public ResponseEntity<ApiResponse> loginContribuable(@RequestBody LoginRequest loginRequest) {
        ApiResponse response = ContribuableService.login(loginRequest);
        if (response.isSuccess()) {
            return ResponseEntity.ok(response);  // Retourne une réponse OK avec les informations du contribuable
        } else {
            return ResponseEntity.status(401).body(response);  // Retourne une réponse 401 Unauthorized en cas d'échec
        }
    }

    


}
