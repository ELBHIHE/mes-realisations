package com.example.demo.controller;

import com.example.demo.models.ComptabiliteElectronique;
import com.example.demo.services.ComptabiliteElectroniqueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/comptabilite")
public class ComptabiliteElectroniqueController {

    @Autowired
    private ComptabiliteElectroniqueService service;

    @PostMapping("/ajouter")
    public ResponseEntity<ComptabiliteElectronique> ajouterComptabilite(
            @RequestParam Long avisDeVerificationId,
            @RequestParam String nom,
            @RequestParam("file") MultipartFile file) throws IOException {
        
        byte[] content = file.getBytes();
        ComptabiliteElectronique comptabilite = service.ajouterComptabilite(avisDeVerificationId, nom, content);
        
        return ResponseEntity.ok(comptabilite);
    }


    @GetMapping("/lister/{avisId}")
    public ResponseEntity<List<ComptabiliteElectronique>> listerComptabilites(@PathVariable("avisId") Long avisId) {
        List<ComptabiliteElectronique> comptabilites = service.getComptabilitesByAvisId(avisId);
        return ResponseEntity.ok(comptabilites);
    }

    @DeleteMapping("/supprimer/{id}")
    public ResponseEntity<Void> deleteComptabilite(@PathVariable Long id) {
        service.deleteComptabilite(id);
        return ResponseEntity.noContent().build();
    }
    

    @GetMapping("/comptabilites/{id}/download")
    public ResponseEntity<byte[]> downloadComptabilite(@PathVariable Long id) {
        ComptabiliteElectronique comptabilite = service.getComptabilite(id);
        if (comptabilite == null) {
            return ResponseEntity.notFound().build();
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(ContentDisposition.attachment().filename(comptabilite.getNom()).build());
        return new ResponseEntity<>(comptabilite.getContent(), headers, HttpStatus.OK);
    }

}
