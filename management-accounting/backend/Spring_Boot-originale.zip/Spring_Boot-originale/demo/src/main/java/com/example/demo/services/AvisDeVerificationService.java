package com.example.demo.services;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.AvisDeVerification;
import com.example.demo.models.ComptabiliteElectronique;
import com.example.demo.repositories.AvisDeVerificationRepository;
import com.example.demo.repositories.ComptabiliteElectroniqueRepository;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import com.itextpdf.text.Document;


@Service
public class AvisDeVerificationService {

    @Autowired
    private AvisDeVerificationRepository avisRepository;
    private ComptabiliteElectroniqueRepository comptarepo;

    public List<AvisDeVerification> getAvisByContribuableId(Long contribuableId) {
        return avisRepository.findByContribuableId(contribuableId);
    }

    public AvisDeVerification validateAvis(Long avisId) throws Exception {
        Optional<AvisDeVerification> avisOpt = avisRepository.findById(avisId);
        if (avisOpt.isPresent()) {
            AvisDeVerification avis = avisOpt.get();
            if ("brouillon".equals(avis.getEtat())) {
                avis.setEtat("validee");
                return avisRepository.save(avis);
            } else {
                throw new Exception("L'avis de vérification n'est pas à l'état brouillon.");
            }
        } else {
            throw new Exception("Avis de vérification non trouvé");
        }
    }

    public void restoreAvis(Long id) {
        AvisDeVerification avis = avisRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Avis non trouvé"));
        avis.setEtat("brouillon"); // Modifier l'état de l'avis
        avisRepository.save(avis);
    }

    public void submitAvis(Long id) {
        AvisDeVerification avis = avisRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Avis non trouvé"));
        avis.setEtat("deposee");
        avisRepository.save(avis);
    }

       public ByteArrayInputStream generateReceipt(Long avisId) throws IOException, DocumentException {
        AvisDeVerification avis = avisRepository.findById(avisId)
                .orElseThrow(() -> new IllegalArgumentException("Avis non trouvé"));

        List<ComptabiliteElectronique> comptabilites = comptarepo.findByAvisDeVerificationId(avisId);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document document = new Document();
        PdfWriter.getInstance(document, out);
        document.open();
        document.add(new Paragraph("Exercice Comptable: " + avis.getExerciceComptable()));
        document.add(new Paragraph("Numéro d'avis de vérification: " + avis.getNumAvisVerification()));
        document.add(new Paragraph("Référence d'envoi: " + avis.getReferenceEnvoi()));

        document.add(new Paragraph("Liste des comptabilités électroniques:"));
        for (ComptabiliteElectronique comptabilite : comptabilites) {
            document.add(new Paragraph("- " + comptabilite.getNom()));
        }

        document.close();

        return new ByteArrayInputStream(out.toByteArray());
    }

    public boolean isAvisValid(Long avisId) {
        // Trouver l'avis de vérification par son identifiant
        AvisDeVerification avis = avisRepository.findById(avisId)
                .orElseThrow(() -> new RuntimeException("Avis non trouvé"));
        
        // Vérifiez si l'état de l'avis est "VALIDATED"
        return "validee".equals(avis.getEtat());
    }


    public AvisDeVerification BrouillonAvis(Long avisId) throws Exception {
        Optional<AvisDeVerification> avisOpt = avisRepository.findById(avisId);
        if (avisOpt.isPresent()) {
            AvisDeVerification avis = avisOpt.get();
            if ("deposee".equals(avis.getEtat())) {
                avis.setEtat("brouillon");
                return avisRepository.save(avis);
            } else {
                throw new Exception("L'avis de vérification n'est pas à l'état déposée.");
            }
        } else {
            throw new Exception("Avis de vérification non trouvé");
        }
    }
   
}
