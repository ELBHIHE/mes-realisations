package com.example.demo.models;

import jakarta.persistence.*;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name="COMPTABILITEELECTRONIQUE")
public class ComptabiliteElectronique {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String nom;
    private byte[] content;
    
    @ManyToOne
    @JoinColumn(name = "avisDeVerification_id")
    private AvisDeVerification avisDeVerification;
}

