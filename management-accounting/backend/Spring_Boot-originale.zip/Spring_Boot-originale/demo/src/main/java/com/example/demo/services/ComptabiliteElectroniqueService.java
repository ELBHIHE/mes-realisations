package com.example.demo.services;

import com.example.demo.models.ComptabiliteElectronique;
import com.example.demo.repositories.ComptabiliteElectroniqueRepository;
import com.example.demo.models.AvisDeVerification;
import com.example.demo.repositories.AvisDeVerificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class ComptabiliteElectroniqueService {

    @Autowired
    private ComptabiliteElectroniqueRepository repository;

    @Autowired
    private AvisDeVerificationRepository avisRepository;

    public ComptabiliteElectronique ajouterComptabilite(Long avisDeVerificationId, String nom, byte[] content) throws IOException {
        Optional<AvisDeVerification> optionalAvis = avisRepository.findById(avisDeVerificationId);
        if (!optionalAvis.isPresent()) {
            throw new IOException("Avis de vérification non trouvé");
        }
        
        AvisDeVerification avis = optionalAvis.get();
        
        ComptabiliteElectronique comptabilite = new ComptabiliteElectronique();
        comptabilite.setAvisDeVerification(avis);
        comptabilite.setNom(nom);
        comptabilite.setContent(content);

        return repository.save(comptabilite);
    }

    public List<ComptabiliteElectronique> getComptabilitesByAvisId(Long avisId) {
        return repository.findByAvisDeVerificationId(avisId);
    }

    public void deleteComptabilite(Long id) {
        repository.deleteById(id);
    }

    public ComptabiliteElectronique getComptabilite(Long id) {
        return  repository.findById(id).orElse(null);
    }
}
