package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.models.Contribuable;
import com.example.demo.repositories.ContribuableRepository;
import com.example.demo.response.ApiResponse;
import com.example.demo.response.LoginRequest;

@Service
public class ContribuableService {

    @Autowired
    private ContribuableRepository contribuableRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public ApiResponse login(LoginRequest loginRequest) {
        // Trouver le contribuable par login
        Contribuable contribuable = contribuableRepository.findByLogin(loginRequest.getLogin());

        // Vérifier le mot de passe
        if (contribuable != null && passwordEncoder.matches(loginRequest.getPassword(), contribuable.getPassword())) {
            // Retourner les informations du contribuable en cas de succès
            return new ApiResponse(
                true,
                "Login successful",
                contribuable.getId(),
                contribuable.getPrenom(),
                contribuable.getNom(),
                contribuable.getIdentifiant_fiscal(),
                contribuable.getICE()
            );
        } else {
            // Retourner une réponse d'échec en cas d'erreur
            return new ApiResponse(false, "Invalid username or password", null, null, null, null, null);
        }
    }

    public Contribuable registerContribuable(Contribuable contribuable) {
        String encodedPassword = passwordEncoder.encode(contribuable.getPassword());
        contribuable.setPassword(encodedPassword);
        return contribuableRepository.save(contribuable);
    }

    
    
}
