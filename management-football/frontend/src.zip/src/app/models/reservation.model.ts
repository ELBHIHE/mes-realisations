export interface Reservation {
    id: number;
    userId: number;
    eventId: number;
    numberOfTickets: number;
    totalPrice: number;
    status: string;
    reservationCode: string;
    eventName: string;
    eventDate: string;
    eventStadium: string;
    createdAt: string;
}
