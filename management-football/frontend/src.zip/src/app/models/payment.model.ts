export enum PaymentMethod {
    CREDIT_CARD = 'CREDIT_CARD',
    DEBIT_CARD = 'DEBIT_CARD',
    PAYPAL = 'PAYPAL',
    BANK_TRANSFER = 'BANK_TRANSFER',
    CASH = 'CASH'
}

export enum PaymentStatus {
    EN_ATTENTE = 'EN_ATTENTE',
    EN_COURS_DE_TRAITEMENT = 'EN_COURS_DE_TRAITEMENT',
    COMPLETE = 'COMPLETE',
    ECHOUE = 'ECHOUE',
    REMBOURSE = 'REMBOURSE',
    ANNULE = 'ANNULE'
}

export interface Payment {
    id: number;
    reservationId: number;
    userId: number;
    amount: number;
    paymentMethod: PaymentMethod;
    status: PaymentStatus;
    transactionId: string;
    description?: string;

    eventName?: string;
    reservationCode?: string;

    createdAt: string;
    completedAt?: string;
}
