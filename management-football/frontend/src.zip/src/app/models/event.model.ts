export enum TeamType {
    HOME = 'HOME',
    AWAY = 'AWAY',
    NEUTRAL = 'NEUTRAL'
}

export enum EventStatus {
    SCHEDULED = 'SCHEDULED',
    CANCELLED = 'CANCELLED',
    COMPLETED = 'COMPLETED'
}

export interface Participant {
    id?: number;
    teamName: string;
    teamDescription: string;
    teamType: TeamType;
}

export interface Event {
    id?: number;
    name: string;
    description: string;
    stadium: string;
    city: string;
    eventDate: string;
    ticketPrice: number;
    organizerId: number;
    status?: EventStatus;
    totalTickets?: number;
    availableTickets?: number;
    participants: Participant[];
}
