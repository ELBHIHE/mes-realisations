export interface CreateReservationRequest {
    userId: number;
    eventId: number;
    numberOfTickets: number;
}
