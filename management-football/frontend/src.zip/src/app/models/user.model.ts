export enum UserRole {
    USER = 'USER',
    ORGANIZER = 'ORGANIZER',
    ADMIN = 'ADMIN'
}

export interface User {
    id: number;
    email: string;
    firstName: string;
    lastName: string;
    phone: string;
    role: UserRole;
    active: boolean;
}

export interface RegisterRequest {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    phone: string;
    role: UserRole;
}

export interface RegisterResponse {
    id: number;
    message: string;
    email: string;
    firstName: string;
    lastName: string;
    phone: string;
    role: UserRole;
    token: string;  // ✅ AJOUTÉ
}

export interface LoginRequest {
    email: string;
    password: string;
}

export interface LoginResponse {
    id: number;
    message: string;
    email: string;
    firstName: string;
    lastName: string;
    phone: string;
    role: UserRole;
    token: string;  // ✅ AJOUTÉ
}