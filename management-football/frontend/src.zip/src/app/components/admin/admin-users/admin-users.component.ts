import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UserService } from '../../../services/user.service';
import { User } from '../../../models/user.model';

@Component({
  selector: 'app-admin-users',
  standalone: true, // ✅ obligatoire
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './admin-users.component.html',
  styleUrls: ['./admin-users.component.scss']
})
export class AdminUsersComponent implements OnInit {
  users: User[] = [];
  userForm: FormGroup;
  editingUser: User | null = null;
  showForm = false;

 constructor(private userService: UserService, private fb: FormBuilder) {
  this.userForm = this.fb.group({
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    phone: [''],
    role: ['USER', Validators.required],
    password: ['']  // ne pas mettre Validators.required ici
  });
}


  ngOnInit(): void {
    console.log('AdminUsersComponent chargé ✅');
    this.loadUsers();
  }

  loadUsers(): void {
    this.userService.getAllUsers().subscribe(data => this.users = data);
  }

 openCreateForm() {
  this.userForm.reset();
  this.editingUser = null;
  this.showForm = true;
}

closeForm() {
  this.showForm = false;
}

editUser(user: User): void {
  this.editingUser = user;
  this.userForm.patchValue({
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    role: user.role,
    phone: user.phone,
    password: '' // 🔹 vide, pour ne pas changer
  });
  this.showForm = true;
}

resetForm(): void {
  this.userForm.reset({ role: 'USER' });
  this.editingUser = null;
  this.showForm = false;
}




 submitForm(): void {
  if (this.userForm.valid) {
    let formData = { ...this.userForm.value };

    if (this.editingUser) {
      // Si édition, ne pas envoyer password si vide
      if (!formData.password) {
        delete formData.password;
      }
      this.userService.updateUser(this.editingUser.id!, formData).subscribe({
        next: () => {
          this.loadUsers();
          this.resetForm();
        },
        error: (err) => console.error('Erreur', err)
      });
    } else {
      // Création : password obligatoire
      if (!formData.password) {
        alert('Le mot de passe est obligatoire pour créer un utilisateur');
        return;
      }
      this.userService.createUser(formData).subscribe({
        next: () => {
          this.loadUsers();
          this.resetForm();
        },
        error: (err) => console.error('Erreur', err)
      });
    }
  }
}



  deleteUser(user: User): void {
  console.log('DELETE CLICKED 👉', user);

  if (confirm(`Voulez-vous vraiment supprimer ${user.firstName} ${user.lastName} ?`)) {
    this.userService.deleteUser(user.id!).subscribe({
      next: () => {
        console.log('DELETE SUCCESS ✅');
        this.loadUsers();
      },
      error: err => console.error('DELETE ERROR ❌', err)
    });
  }
}

}
