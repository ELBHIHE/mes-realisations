import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminStatsService } from '../../../services/admin-stats.service';
import { UserService } from '../../../services/user.service';
import { User } from '../../../models/user.model';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {

  eventsCount = 0;
  reservationsCount = 0;
  organizersCount = 0;

  loading = true;
  error = '';

  users: User[] = []; // ⚠️ Déclaré et initialisé

  constructor(
    private adminStatsService: AdminStatsService,
    private userService: UserService  // Service pour récupérer les utilisateurs
  ) {}

  ngOnInit(): void {
    this.loadStats();
    this.loadUsers();  // Charger les utilisateurs
  }

  loadStats(): void {
    this.loading = true;
    this.adminStatsService.getAllStats().subscribe({
      next: (data) => {
        this.eventsCount = data.events;
        this.reservationsCount = data.reservations;
        this.organizersCount = data.organizers;
        this.loading = false;
      },
      error: () => {
        this.error = 'Erreur lors du chargement des statistiques';
        this.loading = false;
      }
    });
  }

  loadUsers(): void {
    this.userService.getAllUsers().subscribe({
      next: (data) => this.users = data,
      error: () => this.error = 'Erreur lors du chargement des utilisateurs'
    });
  }
}
