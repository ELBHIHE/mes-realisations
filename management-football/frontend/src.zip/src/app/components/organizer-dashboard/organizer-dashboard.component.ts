import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Event as FootballEvent } from '../../models/event.model';
import { EventService } from '../../services/event.service';

@Component({
  selector: 'app-organizer-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './organizer-dashboard.component.html',
  styleUrls: ['./organizer-dashboard.component.scss']
})
export class OrganizerDashboardComponent implements OnInit {
  eventsCount: number = 0;
  events: FootballEvent[] = [];
  loading: boolean = true;
  error: string | null = null;

  userId: number | null = null;
  userRole: string | null = null;

  constructor(private eventService: EventService) {}

  ngOnInit(): void {
    // Récupération des infos utilisateur depuis localStorage (ou ton auth service)
    this.userRole = localStorage.getItem('userRole');
    const id = localStorage.getItem('userId');
    this.userId = id ? Number(id) : null;

    // Vérification que c'est bien un organisateur
    if (this.userRole !== 'ORGANIZER' || !this.userId) {
      this.error = 'Accès refusé. Vous devez être connecté en tant qu\'organisateur.';
      this.loading = false;
      return;
    }

    this.loadDashboardData();
  }

  private loadDashboardData(): void {
    this.loading = true;

    // 1. Charger le nombre total d'événements
    this.eventService.getEventCountByOrganizer(this.userId!).subscribe({
      next: (count: number) => {
        this.eventsCount = count;
      },
      error: (err) => {
        console.error('Erreur lors du chargement du compteur', err);
        this.error = 'Impossible de charger les statistiques.';
      }
    });

    // 2. Charger la liste des événements de l'organisateur
    this.eventService.getEventsByOrganizer(this.userId!).subscribe({
      next: (events: FootballEvent[]) => {
        this.events = events;
        this.loading = false;
      },
      error: (err) => {
        console.error('Erreur lors du chargement des événements', err);
        this.error = 'Impossible de charger vos événements.';
        this.loading = false;
      }
    });
  }

  // Méthodes réutilisées depuis ton event-list (optionnel : tu peux les déplacer dans un service partagé)
  createEvent(): void {
    // À adapter selon ta route
    window.location.href = '/dashboard/events/create';
    // ou this.router.navigate(['/dashboard/events/create']);
  }

  editEvent(event: FootballEvent): void {
    // this.router.navigate(['/dashboard/events/edit', event.id]);
    window.location.href = `/dashboard/events/edit/${event.id}`;
  }

  deleteEvent(eventId: number): void {
    if (!confirm('Voulez-vous vraiment supprimer cet événement ?')) return;

    this.eventService.deleteEvent(eventId, this.userId!).subscribe({
      next: () => {
        this.events = this.events.filter(e => e.id !== eventId);
        this.eventsCount--; // Mise à jour du compteur
        alert('Événement supprimé avec succès !');
      },
      error: (err) => {
        console.error(err);
        alert('Erreur lors de la suppression');
      }
    });
  }
}