import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Router } from '@angular/router';
import { ReservationService } from '../../../services/reservation.service';

@Component({
    selector: 'app-my-reservations',
    standalone: true,
    imports: [CommonModule, RouterModule],
    templateUrl: './my-reservations.component.html',
    styleUrls: ['./my-reservations.component.scss']
})
export class MyReservationsComponent implements OnInit {

    reservations: any[] = [];
    userId!: number;

    constructor(
        private reservationService: ReservationService,
        private router: Router
    ) { }

    ngOnInit(): void {
        const storedUserId = localStorage.getItem('userId');
        if (!storedUserId) return;
        this.userId = Number(storedUserId);

        this.loadReservations();
    }

    loadReservations(): void {
        this.reservationService.getReservationsByUser(this.userId).subscribe({
            next: data => this.reservations = data,
            error: err => console.error(err)
        });
    }

    goToPayment(reservation: any): void {
        this.router.navigate(['/dashboard/payments/pay'], {
            queryParams: {
                reservationId: reservation.id,
                amount: reservation.totalPrice
            }
        });
    }
}
