import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // ✅ ICI
import { ActivatedRoute, Router } from '@angular/router';
import { ReservationService } from '../../../services/reservation.service';



@Component({
    selector: 'app-reservation-form',
    standalone: true, // ✅ important
    imports: [CommonModule, FormsModule], // ✅ important
    templateUrl: './reservation-form.component.html',
    styleUrls: ['./reservation-form.component.scss']

})
export class ReservationFormComponent implements OnInit {

    eventId!: number;
    price!: number;
    tickets = 1;
    userId!: number;
    maxTickets: number = 4;

    constructor(
        private route: ActivatedRoute,
        private reservationService: ReservationService,
        private router: Router
    ) { }

    ngOnInit(): void {
        this.eventId = Number(this.route.snapshot.queryParamMap.get('eventId'));
        this.price = Number(this.route.snapshot.queryParamMap.get('price'));

        // 🔐 récupération depuis localStorage
        const storedUserId = localStorage.getItem('userId');
        if (storedUserId) {
            this.userId = Number(storedUserId);
        }
    }

  decrementTickets() {
  if (this.tickets > 1) {
    this.tickets--;
  }
}

incrementTickets() {
  if (this.tickets < this.maxTickets) {
    this.tickets++;
  }
}

    reserve(): void {
        this.reservationService.createReservation({
            userId: this.userId,
            eventId: this.eventId,
            numberOfTickets: this.tickets
        }).subscribe({
            next: () => {
                alert('Réservation effectuée avec succès 🎉');
                this.router.navigate(['/dashboard/reservations']);
            },
            error: err => alert(err.error?.message)
        });
    }
}
