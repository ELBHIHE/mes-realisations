import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { UserRole } from '../../models/user.model';

@Component({
    selector: 'app-register',
    standalone: true,
    imports: [CommonModule, ReactiveFormsModule, RouterModule],
    templateUrl: './register.component.html',
    styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
    registerForm: FormGroup;
    isLoading = false;
    errorMessage = '';
    successMessage = '';
    roles = Object.values(UserRole);

    constructor(
        private fb: FormBuilder,
        private authService: AuthService,
        private router: Router
    ) {
        this.registerForm = this.fb.group({
            email: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required, Validators.minLength(8)]],
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            phone: ['', [Validators.required, Validators.pattern(/^\+?[0-9]{10,15}$/)]],
            role: [UserRole.USER]  // rôle par défaut USER
        });

    }

    onSubmit(): void {
        if (this.registerForm.valid) {
            this.isLoading = true;
            this.errorMessage = '';
            this.successMessage = '';

            this.authService.register(this.registerForm.value).subscribe({
                next: (response) => {
                    this.isLoading = false;
                    this.successMessage = response.message || 'Inscription réussie !';
                    setTimeout(() => {
                        this.router.navigate(['/login']);
                    }, 2000);
                },
                error: (error) => {
                    this.isLoading = false;
                    this.errorMessage = error.error?.message || 'Une erreur est survenue lors de l\'inscription';
                }
            });
        } else {
            Object.keys(this.registerForm.controls).forEach(key => {
                this.registerForm.get(key)?.markAsTouched();
            });
        }
    }

    getErrorMessage(fieldName: string): string {
        const control = this.registerForm.get(fieldName);
        if (control?.hasError('required')) {
            return 'Ce champ est requis';
        }
        if (control?.hasError('email')) {
            return 'Email invalide';
        }
        if (control?.hasError('minlength')) {
            return 'Minimum 8 caractères requis';
        }
        if (control?.hasError('pattern')) {
            return 'Format invalide';
        }
        return '';
    }
}
