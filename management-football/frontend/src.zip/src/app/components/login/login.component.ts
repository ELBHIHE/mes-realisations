import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { LoginResponse } from '../../models/user.model';

@Component({
    selector: 'app-login',
    standalone: true,
    imports: [CommonModule, ReactiveFormsModule, RouterModule],
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent {
    loginForm: FormGroup;
    isLoading = false;
    errorMessage = '';
    successMessage = '';

    constructor(
        private fb: FormBuilder,
        private authService: AuthService,
        private router: Router
    ) {
        this.loginForm = this.fb.group({
            email: ['', [Validators.required, Validators.email]],
            password: ['', Validators.required]
        });
    }

   onSubmit(): void {
    if (this.loginForm.valid) {
        this.isLoading = true;
        this.errorMessage = '';
        this.successMessage = '';

        this.authService.login(this.loginForm.value).subscribe({
            next: (response: LoginResponse) => {
                this.isLoading = false;
                this.successMessage = response.message || 'Authentification réussie. Bienvenue !';

                // Stockage des infos utilisateur
                localStorage.setItem('userId', response.id.toString());
                localStorage.setItem('userRole', response.role);  // Utilise 'userRole' pour cohérence avec tes autres composants
                localStorage.setItem('firstName', response.firstName);
                localStorage.setItem('lastName', response.lastName);

                // Petite pause pour afficher le message de succès
                setTimeout(() => {
                    const role = response.role;

                    if (role === 'ADMIN') {
                        this.router.navigate(['/dashboard/admin/dashboard']);
                    } 
                    else if (role === 'ORGANIZER') {
                        this.router.navigate(['/dashboard/dashboard/organizer']);  // Redirection vers le dashboard organisateur
                    } 
                    else {
                        // Pour les USER ou autres rôles
                        this.router.navigate(['/dashboard']);  // ou '/events' si tu préfères
                    }
                }, 1800);
            },
            error: (error) => {
                this.isLoading = false;
                this.errorMessage = error.error?.message || 'Email ou mot de passe incorrect';
            }
        });
    } else {
        Object.keys(this.loginForm.controls).forEach(key => {
            this.loginForm.get(key)?.markAsTouched();
        });
    }
}

    getErrorMessage(fieldName: string): string {
        const control = this.loginForm.get(fieldName);
        if (control?.hasError('required')) {
            return 'Ce champ est requis';
        }
        if (control?.hasError('email')) {
            return 'Email invalide';
        }
        return '';
    }
}
