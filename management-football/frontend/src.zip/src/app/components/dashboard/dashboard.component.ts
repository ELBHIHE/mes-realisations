import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
    selector: 'app-dashboard',
    standalone: true,
    imports: [CommonModule, RouterModule],
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
    userName: string = 'Utilisateur';
    userRole: string = '';
    isSidebarOpen: boolean = false;

    constructor(
        private router: Router,
        private authService: AuthService
    ) { }

    ngOnInit(): void {
        this.loadUserInfo();
    }

    loadUserInfo(): void {
    const role = localStorage.getItem('userRole');
    const firstName = localStorage.getItem('firstName');
    const lastName = localStorage.getItem('lastName');

    if (!role) {
        this.router.navigate(['/login']);
        return;
    }

    this.userRole = role;
    this.userName = `${firstName ?? ''} ${lastName ?? ''}`.trim();
}


    logout(): void {
        // Supprimer les données de l'utilisateur
        localStorage.removeItem('userId');
        localStorage.removeItem('role');
        localStorage.removeItem('token'); // Si vous stockez un token

        // Rediriger vers la page de connexion
        this.router.navigate(['/login']);
    }

    toggleSidebar(): void {
        this.isSidebarOpen = !this.isSidebarOpen;
    }
}