import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EventService } from '../../../services/event.service';
import { Event as FootballEvent } from '../../../models/event.model';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-event-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.scss']
})
export class EventListComponent implements OnInit {

  events: FootballEvent[] = [];

  userRole: string | null = null;
  userId: number | null = null;

  constructor(
    private eventService: EventService,
    private router: Router
  ) { }

  ngOnInit(): void {
    // 🔐 Récupération depuis localStorage
    this.userRole = localStorage.getItem('userRole'); 
    this.userId = localStorage.getItem('userId')
      ? Number(localStorage.getItem('userId'))
      : null;

    // 🔁 Chargement selon le rôle
    if (this.userRole === 'ORGANIZER' && this.userId) {
      this.loadMyEvents();
    } else {
      // ✅ UTILISATEUR NORMAL → TOUS LES ÉVÉNEMENTS
      this.loadAllEvents();
    }
  }

  loadMyEvents(): void {
    // ✅ correspond au backend
    this.eventService.getEventsByOrganizer(this.userId!).subscribe({
      next: (data: FootballEvent[]) => this.events = data,
      error: err => console.error(err)
    });
  }


  loadUpcomingEvents(): void {
    this.eventService.getUpcomingEvents().subscribe({
      next: (data: FootballEvent[]) => this.events = data,
      error: err => console.error(err)
    });
  }

  // ✏️ Modifier événement (ORGANIZER)
  editEvent(event: FootballEvent): void {
    this.router.navigate(['/dashboard/events/edit', event.id]);
  }

  // 🗑️ Supprimer événement (ORGANIZER)
  deleteEvent(eventId: number): void {
    if (!confirm('Voulez-vous vraiment supprimer cet événement ?')) return;

    this.eventService.deleteEvent(eventId, this.userId!).subscribe({
      next: () => {
        this.events = this.events.filter(e => e.id !== eventId);
        alert('Événement supprimé avec succès !');
      },
      error: err => {
        console.error(err);
        alert('Erreur lors de la suppression de l\'événement');
      }
    });
  }

  // ➕ Créer événement (ORGANIZER)
  createEvent(): void {
    this.router.navigate(['/dashboard/events/create']);
  }

  // 🎟️ Réserver événement (USER)
  reserveEvent(event: FootballEvent): void {
    if (!this.userId) {
      alert('Veuillez vous connecter pour réserver');
      return;
    }

    this.router.navigate(['/dashboard/reservations/new'], {
      queryParams: {
        eventId: event.id,
        price: event.ticketPrice,
        eventName: event.name
      }
    });
  }

  loadAllEvents(): void {
    this.eventService.getAllEvents().subscribe({
      next: data => this.events = data,
      error: err => console.error(err)
    });
  }

}
