import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormArray, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { EventService } from '../../../services/event.service';
import { Event, Participant, TeamType } from '../../../models/event.model';

@Component({
  selector: 'app-event-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './event-form.component.html',
  styleUrls: ['./event-form.component.scss']
})
export class EventFormComponent implements OnInit {
  eventForm: FormGroup;
  isEditMode = false;
  eventId: number | null = null;
  userId: number | null = null;
  teamTypes = Object.values(TeamType);

  constructor(
    private fb: FormBuilder,
    private eventService: EventService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.eventForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      stadium: ['', Validators.required],
      city: ['', Validators.required],
      eventDate: ['', Validators.required],
      ticketPrice: ['', [Validators.required, Validators.min(0)]],
      participants: this.fb.array([])
    });
  }

  ngOnInit(): void {
    this.userId = localStorage.getItem('userId') ? Number(localStorage.getItem('userId')) : null;

    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.isEditMode = true;
        this.eventId = Number(id);
        this.loadEvent(this.eventId);
      } else {
        this.addParticipant(); // au moins un participant par défaut
      }
    });
  }

  get participants(): FormArray {
    return this.eventForm.get('participants') as FormArray;
  }

  addParticipant(participant?: Participant): void {
    this.participants.push(this.fb.group({
      id: [participant?.id || null],
      teamName: [participant?.teamName || '', Validators.required],
      teamDescription: [participant?.teamDescription || '', Validators.required],
      teamType: [participant?.teamType || TeamType.HOME, Validators.required]
    }));
  }

  removeParticipant(index: number): void {
    this.participants.removeAt(index);
  }

  loadEvent(id: number): void {
    this.eventService.getEventById(id).subscribe({
      next: (event: Event) => {
        this.eventForm.patchValue({
          name: event.name,
          description: event.description,
          stadium: event.stadium,
          city: event.city,
          eventDate: event.eventDate,
          ticketPrice: event.ticketPrice
        });
        // Ajouter les participants
        event.participants.forEach(p => this.addParticipant(p));
      },
      error: err => console.error(err)
    });
  }

  onSubmit(): void {
    if (!this.eventForm.valid || !this.userId) {
      this.eventForm.markAllAsTouched();
      return;
    }

    const request = {
      ...this.eventForm.value,
      organizerId: this.userId
    };

    if (this.isEditMode && this.eventId) {
      this.eventService.updateEvent(this.eventId, request, this.userId).subscribe({
        next: () => {
          alert('Événement mis à jour avec succès !');
          this.router.navigate(['/dashboard/events']);
        },
        error: err => console.error(err)
      });
    } else {
      this.eventService.createEvent(request).subscribe({
        next: () => {
          alert('Événement créé avec succès !');
          this.router.navigate(['/dashboard/events']);
        },
        error: err => console.error(err)
      });
    }
  }
}
