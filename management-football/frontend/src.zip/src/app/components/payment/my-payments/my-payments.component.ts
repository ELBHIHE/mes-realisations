import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Payment, PaymentStatus } from '../../../models/payment.model';
import { PaymentService } from '../../../services/payment.service';


@Component({
    selector: 'app-my-payments',
    standalone: true,
    imports: [CommonModule],
    templateUrl: './my-payments.component.html',
    styleUrls: ['./my-payments.component.scss']
})
export class MyPaymentsComponent implements OnInit {

    payments: Payment[] = [];
    userId!: number;

    constructor(private paymentService: PaymentService) { }

    ngOnInit(): void {
        const storedUserId = localStorage.getItem('userId');
        if (!storedUserId) return;
        this.userId = Number(storedUserId);

        this.loadPayments();
    }

    loadPayments(): void {
        this.paymentService.getPaymentsByUser(this.userId).subscribe({
            next: data => this.payments = data,
            error: err => console.error(err)
        });
    }

    getStatusText(status: PaymentStatus): string {
        const statusMap: Record<PaymentStatus, string> = {
            [PaymentStatus.COMPLETE]: 'Payé',
            [PaymentStatus.EN_ATTENTE]: 'En attente',
            [PaymentStatus.EN_COURS_DE_TRAITEMENT]: 'En cours',
            [PaymentStatus.ECHOUE]: 'Échoué',
            [PaymentStatus.REMBOURSE]: 'Remboursé',
            [PaymentStatus.ANNULE]: 'Annulé'
        };
        return statusMap[status] || status;
    }
}
