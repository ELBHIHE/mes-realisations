import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentMethod } from '../../models/payment.model';
import { PaymentService } from '../../services/payment.service';


@Component({
    selector: 'app-payment-form',
    standalone: true,
    imports: [CommonModule, FormsModule],
    templateUrl: './payment-form.component.html',
    styleUrls: ['./payment-form.component.scss']
})
export class PaymentFormComponent implements OnInit {

    reservationId!: number;
    amount!: number;
    userId!: number;

    paymentMethod: PaymentMethod = PaymentMethod.CREDIT_CARD;
    methods = Object.values(PaymentMethod);

    constructor(
        private route: ActivatedRoute,
        private paymentService: PaymentService,
        private router: Router
    ) { }

    ngOnInit(): void {
        this.reservationId = Number(this.route.snapshot.queryParamMap.get('reservationId'));
        this.amount = Number(this.route.snapshot.queryParamMap.get('amount'));

        const storedUserId = localStorage.getItem('userId');
        if (storedUserId) {
            this.userId = Number(storedUserId);
        }
    }

    pay(): void {
        this.paymentService.createPayment({
            reservationId: this.reservationId,
            userId: this.userId,
            amount: this.amount,
            paymentMethod: this.paymentMethod
        }).subscribe({
            next: payment => {
                // Traitement automatique
                this.paymentService.processPayment(payment.id).subscribe(() => {
                    alert('Paiement effectué avec succès 💳');
                    this.router.navigate(['/dashboard/payments']);
                });
            },
            error: err => alert(err.error?.message)
        });
    }
}
