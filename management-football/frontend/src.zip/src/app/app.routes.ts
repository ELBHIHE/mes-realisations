import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { EventListComponent } from './components/event/event-list/event-list.component';
import { EventFormComponent } from './components/event/event-form/event-form.component';
import { PaymentFormComponent } from './components/payment/payment-form.component';
import { ReservationFormComponent } from './components/reservation/reservation-form/reservation-form.component';
import { MyPaymentsComponent } from './components/payment/my-payments/my-payments.component';
import { MyReservationsComponent } from './components/reservation/my-reservation/my-reservations.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AdminDashboardComponent } from './components/admin/admin-dashboard/admin-dashboard.component';
import { AdminUsersComponent } from './components/admin/admin-users/admin-users.component';
import { OrganizerDashboardComponent } from './components/organizer-dashboard/organizer-dashboard.component';

export const routes: Routes = [
    { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    {
        path: 'dashboard',
        component: DashboardComponent,
        children: [
            { path: '', redirectTo: 'events', pathMatch: 'full' },
            { path: 'events', component: EventListComponent },
            { path: 'events/create', component: EventFormComponent },
            { path: 'events/edit/:id', component: EventFormComponent },
            { path: 'reservations', component: MyReservationsComponent },
            { path: 'reservations/new', component: ReservationFormComponent },
            { path: 'payments', component: MyPaymentsComponent },
            { path: 'payments/pay', component: PaymentFormComponent },
            { path: 'admin/dashboard', component: AdminDashboardComponent },
            { path: 'admin/users', component: AdminUsersComponent },
            { path: 'dashboard/organizer', component: OrganizerDashboardComponent, }
        ]
    },
    { path: '**', redirectTo: '/login' }
];