import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Event } from '../models/event.model';

@Injectable({
    providedIn: 'root'
})
export class EventService {
    private apiUrl = 'http://localhost:9999/event-service/api/events';
    private apiUrlv = 'http://localhost:9999/reservation-service/api/reservations';

    constructor(private http: HttpClient) { }

    createEvent(event: Event): Observable<Event> {
        return this.http.post<Event>(this.apiUrl, event);
    }

    getEventById(id: number): Observable<Event> {
        return this.http.get<Event>(`${this.apiUrl}/${id}`);
    }

    getAllEvents(): Observable<Event[]> {
        return this.http.get<Event[]>(this.apiUrl);
    }

    getUpcomingEvents(): Observable<Event[]> {
        return this.http.get<Event[]>(`${this.apiUrl}/upcoming`);
    }

    getEventsByOrganizer(organizerId: number): Observable<Event[]> {
        return this.http.get<Event[]>(`${this.apiUrl}/organizer/${organizerId}`);
    }

    updateEvent(id: number, event: Event, userId: number): Observable<Event> {
        const headers = new HttpHeaders().set('X-User-Id', userId.toString());
        return this.http.put<Event>(`${this.apiUrl}/${id}`, event, { headers });
    }

    deleteEvent(id: number, userId: number): Observable<void> {
        const headers = new HttpHeaders().set('X-User-Id', userId.toString());
        return this.http.delete<void>(`${this.apiUrl}/${id}`, { headers });
    }

    updateTicketAvailability(id: number, ticketsReserved: number): Observable<boolean> {
        return this.http.put<boolean>(`${this.apiUrl}/${id}/tickets`, { ticketsReserved });
    }

    getEventCountByOrganizer(organizerId: number): Observable<number> {
  return this.http.get<number>(`${this.apiUrl}/count/${organizerId}`);
}

getRevenueByEvent(eventId: number): Observable<number> {
  return this.http.get<number>(`${this.apiUrl}/event/${eventId}/revenue`);
}

    
}
