import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Payment } from '../models/payment.model';

@Injectable({
    providedIn: 'root'
})
export class PaymentService {

    private apiUrl = 'http://localhost:9999/payment-service/api/payments'; // adapter au gateway si besoin

    constructor(private http: HttpClient) { }

    // ➕ Créer paiement
    createPayment(request: {
        reservationId: number;
        userId: number;
        amount: number;
        paymentMethod: string;
        description?: string;
    }): Observable<Payment> {
        return this.http.post<Payment>(this.apiUrl, request);
    }

    // ▶️ Traiter paiement
    processPayment(paymentId: number): Observable<Payment> {
        return this.http.post<Payment>(`${this.apiUrl}/${paymentId}/process`, {});
    }

    // ❌ Annuler paiement
    cancelPayment(paymentId: number, userId: number): Observable<Payment> {
        return this.http.put<Payment>(
            `${this.apiUrl}/${paymentId}/cancel`,
            {},
            { headers: { 'X-User-Id': userId.toString() } }
        );
    }

    // 💸 Rembourser
    refundPayment(paymentId: number): Observable<Payment> {
        return this.http.put<Payment>(`${this.apiUrl}/${paymentId}/refund`, {});
    }

    // 👤 Paiements utilisateur
    getPaymentsByUser(userId: number): Observable<Payment[]> {
        return this.http.get<Payment[]>(`${this.apiUrl}/user/${userId}`);
    }

    // 🎟️ Paiements par réservation
    getPaymentsByReservation(reservationId: number): Observable<Payment[]> {
        return this.http.get<Payment[]>(`${this.apiUrl}/reservation/${reservationId}`);
    }
}
