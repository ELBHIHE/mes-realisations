import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Reservation } from '../models/reservation.model';
import { CreateReservationRequest } from '../models/create-reservation.model';


@Injectable({
    providedIn: 'root'
})
export class ReservationService {

    private apiUrl = 'http://localhost:9999/reservation-service/api/reservations';

    constructor(private http: HttpClient) { }

    createReservation(request: CreateReservationRequest): Observable<Reservation> {
        return this.http.post<Reservation>(this.apiUrl, request);
    }

    getReservationsByUser(userId: number): Observable<Reservation[]> {
        return this.http.get<Reservation[]>(`${this.apiUrl}/user/${userId}`);
    }

    cancelReservation(reservationId: number, userId: number): Observable<Reservation> {
        const headers = new HttpHeaders({
            'X-User-Id': userId.toString()
        });
        return this.http.put<Reservation>(
            `${this.apiUrl}/${reservationId}/cancel`,
            {},
            { headers }
        );
    }
}
