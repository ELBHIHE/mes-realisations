import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminStatsService {

  private eventApi = 'http://localhost:9999/event-service/api/events';
  private reservationApi = 'http://localhost:9999/reservation-service/api/reservations';
  private userApi = 'http://localhost:9999/user-service/api/users';

  constructor(private http: HttpClient) {}

  getEventsCount(): Observable<number> {
    return this.http.get<number>(`${this.eventApi}/count`);
  }

  getReservationsCount(): Observable<number> {
    return this.http.get<number>(`${this.reservationApi}/count`);
  }

  getOrganizersCount(): Observable<number> {
    return this.http.get<number>(`${this.userApi}/organizers/count`);
  }

  // 🔥 Tout charger en une fois (recommandé)
  getAllStats(): Observable<any> {
    return forkJoin({
      events: this.getEventsCount(),
      reservations: this.getReservationsCount(),
      organizers: this.getOrganizersCount()
    });
  }
}
