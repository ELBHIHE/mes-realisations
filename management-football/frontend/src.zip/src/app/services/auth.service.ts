import { Injectable, PLATFORM_ID, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';
import { RegisterRequest, RegisterResponse, LoginRequest, LoginResponse, User } from '../models/user.model';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    private apiUrl = 'http://localhost:9999/user-service/api/users';
    private readonly USER_KEY = 'currentUser';
    private readonly TOKEN_KEY = 'token';        // ✅ AJOUTÉ
    private readonly USER_ID_KEY = 'userId';     // ✅ AJOUTÉ
    private readonly USER_ROLE_KEY = 'userRole'; // ✅ AJOUTÉ

    constructor(
        private http: HttpClient,
        @Inject(PLATFORM_ID) private platformId: Object
    ) { }

    register(data: RegisterRequest): Observable<RegisterResponse> {
        return this.http.post<RegisterResponse>(`${this.apiUrl}/register`, data).pipe(
            tap(response => {
                // ✅ AJOUTÉ : Stocke aussi le token lors de l'inscription
                if (isPlatformBrowser(this.platformId) && response.token) {
                    localStorage.setItem(this.TOKEN_KEY, response.token);
                    localStorage.setItem(this.USER_ID_KEY, response.id.toString());
                    localStorage.setItem(this.USER_ROLE_KEY, response.role);
                    localStorage.setItem(this.USER_KEY, JSON.stringify(response));
                }
            })
        );
    }

    login(data: LoginRequest): Observable<LoginResponse> {
        return this.http.post<LoginResponse>(`${this.apiUrl}/authenticate`, data).pipe(
            tap(response => {
                if (isPlatformBrowser(this.platformId)) {
                    // ✅ MODIFIÉ : Stocke le token, userId et role séparément
                    localStorage.setItem(this.TOKEN_KEY, response.token);
                    localStorage.setItem(this.USER_ID_KEY, response.id.toString());
                    localStorage.setItem(this.USER_ROLE_KEY, response.role);
                    localStorage.setItem(this.USER_KEY, JSON.stringify(response));
                    
                    console.log('✅ Token stocké:', response.token);
                    console.log('✅ User ID:', response.id);
                    console.log('✅ Role:', response.role);
                }
            })
        );
    }

    logout(): void {
        if (isPlatformBrowser(this.platformId)) {
            // ✅ MODIFIÉ : Supprime aussi le token, userId et role
            localStorage.removeItem(this.TOKEN_KEY);
            localStorage.removeItem(this.USER_ID_KEY);
            localStorage.removeItem(this.USER_ROLE_KEY);
            localStorage.removeItem(this.USER_KEY);
            
            console.log('✅ Déconnexion : token et données supprimés');
        }
    }

    getCurrentUser(): LoginResponse | null {
        if (isPlatformBrowser(this.platformId)) {
            const userStr = localStorage.getItem(this.USER_KEY);
            return userStr ? JSON.parse(userStr) : null;
        }
        return null;
    }

    isAuthenticated(): boolean {
        if (isPlatformBrowser(this.platformId)) {
            const token = localStorage.getItem(this.TOKEN_KEY);
            return token !== null;
        }
        return false;
    }

    getUserId(): number | null {
        if (isPlatformBrowser(this.platformId)) {
            const userId = localStorage.getItem(this.USER_ID_KEY);
            return userId ? Number(userId) : null;
        }
        return null;
    }

    // ✅ AJOUTÉ : Méthode pour récupérer le token
    getToken(): string | null {
        if (isPlatformBrowser(this.platformId)) {
            return localStorage.getItem(this.TOKEN_KEY);
        }
        return null;
    }

    // ✅ AJOUTÉ : Méthode pour récupérer le role
    getUserRole(): string | null {
        if (isPlatformBrowser(this.platformId)) {
            return localStorage.getItem(this.USER_ROLE_KEY);
        }
        return null;
    }
}