import { HttpInterceptorFn } from '@angular/common/http';

/**
 * Intercepteur HTTP qui ajoute automatiquement le token JWT
 * à toutes les requêtes sortantes
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  // Récupère le token depuis localStorage
  const token = localStorage.getItem('token');

  // 🔍 Debug (optionnel - à retirer en production)
  console.log('🔍 Interceptor - URL:', req.url);
  console.log('🔍 Token:', token ? 'Présent ✅' : 'Absent ❌');

  // Si un token existe, clone la requête et ajoute le header Authorization
  if (token) {
    req = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
    console.log('✅ Header Authorization ajouté');
  }

  // Continue avec la requête (modifiée ou non)
  return next(req);
};