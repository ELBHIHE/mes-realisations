package com.football.eventservice.model;

public enum TeamType {
    HOME,
    AWAY
}
