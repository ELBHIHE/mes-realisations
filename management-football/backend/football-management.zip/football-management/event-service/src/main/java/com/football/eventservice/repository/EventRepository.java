package com.football.eventservice.repository;

import com.football.eventservice.model.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface EventRepository extends JpaRepository<Event, Long> {

    List<Event> findByEventDateAfter(LocalDateTime date);

    List<Event> findByOrganizerId(Long organizerId);

    List<Event> findByCity(String city);

    List<Event> findByStadium(String stadium);

    long count();

    long countByOrganizerId(Long organizerId);
}
