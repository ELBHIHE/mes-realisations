package com.football.eventservice.model;

public enum EventStatus {
    SCHEDULED,
    ONGOING,
    COMPLETED,
    CANCELLED
}
