package com.football.eventservice.service;

import com.football.eventservice.client.UserServiceClient;
import com.football.eventservice.dto.CreateEventRequest;
import com.football.eventservice.dto.EventDto;
import com.football.eventservice.dto.ParticipantDTO;
import com.football.eventservice.dto.UserDto;
import com.football.eventservice.model.Event;
import com.football.eventservice.model.Participant;
import com.football.eventservice.model.TeamType;
import com.football.eventservice.repository.EventRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class EventService {

    private final EventRepository eventRepository;
    private final UserServiceClient userServiceClient;

    @Transactional
    @CircuitBreaker(name = "eventService", fallbackMethod = "createEventFallback")
    public EventDto createEvent(CreateEventRequest request) {
        log.info("Creating event: {}", request.getName());

        // Valider que l'organisateur existe et a le rôle ORGANIZER
        validateOrganizer(request.getOrganizerId());

        Event event = new Event();
        event.setName(request.getName());
        event.setDescription(request.getDescription());
        event.setStadium(request.getStadium());
        event.setCity(request.getCity());
        event.setEventDate(request.getEventDate());
        event.setTicketPrice(request.getTicketPrice());
        event.setOrganizerId(request.getOrganizerId());

        if (request.getParticipants() != null && !request.getParticipants().isEmpty()) {
            List<Participant> participants = request.getParticipants().stream()
                    .map(dto -> {
                        Participant p = new Participant();
                        p.setEvent(event);
                        p.setTeamName(dto.getTeamName());
                        p.setTeamDescription(dto.getTeamDescription());
                        p.setTeamType(TeamType.valueOf(dto.getTeamType()));
                        return p;
                    })
                    .collect(Collectors.toList());
            event.setParticipants(participants);
        }

        Event savedEvent = eventRepository.save(event);
        log.info("Event created successfully with ID: {}", savedEvent.getId());

        return convertToDTO(savedEvent);
    }

    public EventDto getEventById(Long id) {
        log.info("Fetching event with ID: {}", id);
        Event event = eventRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Événement non trouvé avec l'ID: " + id));
        return convertToDTO(event);
    }

    public List<EventDto> getAllEvents() {
        log.info("Fetching all events");
        return eventRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<EventDto> getUpcomingEvents() {
        log.info("Fetching upcoming events");
        return eventRepository.findByEventDateAfter(LocalDateTime.now()).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<EventDto> getEventsByOrganizer(Long organizerId) {
        log.info("Fetching events for organizer: {}", organizerId);
        return eventRepository.findByOrganizerId(organizerId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public EventDto updateEvent(Long id, CreateEventRequest request, Long organizerId) {
        log.info("Updating event with ID: {}", id);
        Event event = eventRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Événement non trouvé"));

        // Vérifier que l'utilisateur est bien l'organisateur de cet événement
        if (!event.getOrganizerId().equals(organizerId)) {
            throw new RuntimeException("Vous n'êtes pas autorisé à modifier cet événement");
        }

        event.setName(request.getName());
        event.setDescription(request.getDescription());
        event.setStadium(request.getStadium());
        event.setCity(request.getCity());
        event.setEventDate(request.getEventDate());
        event.setTicketPrice(request.getTicketPrice());

        // Mise à jour des participants
        if (request.getParticipants() != null) {
            // Map des participants entrants qui ont un ID (pour mise à jour)
            Map<Long, ParticipantDTO> incomingMap = request.getParticipants().stream()
                    .filter(p -> p.getId() != null)
                    .collect(Collectors.toMap(ParticipantDTO::getId, Function.identity()));

            // ID des participants à conserver (ceux présents dans la requête)
            List<Long> incomingIds = request.getParticipants().stream()
                    .filter(p -> p.getId() != null)
                    .map(ParticipantDTO::getId)
                    .collect(Collectors.toList());

            // 1. Mise à jour des existants et suppression des orphelins
            List<Participant> toRemove = new ArrayList<>();
            for (Participant existing : event.getParticipants()) {
                if (incomingIds.contains(existing.getId())) {
                    // Update
                    ParticipantDTO dto = incomingMap.get(existing.getId());
                    existing.setTeamName(dto.getTeamName());
                    existing.setTeamDescription(dto.getTeamDescription());
                    existing.setTeamType(TeamType.valueOf(dto.getTeamType()));
                } else {
                    // Mark for removal
                    toRemove.add(existing);
                }
            }
            event.getParticipants().removeAll(toRemove);

            // 2. Ajout des nouveaux (ceux sans ID)
            request.getParticipants().stream()
                    .filter(p -> p.getId() == null)
                    .forEach(dto -> {
                        Participant p = new Participant();
                        p.setEvent(event);
                        p.setTeamName(dto.getTeamName());
                        p.setTeamDescription(dto.getTeamDescription());
                        p.setTeamType(TeamType.valueOf(dto.getTeamType()));
                        event.getParticipants().add(p);
                    });
        }

        Event updatedEvent = eventRepository.save(event);
        log.info("Event updated successfully");

        return convertToDTO(updatedEvent);
    }

    @Transactional
    public void deleteEvent(Long id, Long organizerId) {
        log.info("Deleting event with ID: {}", id);
        Event event = eventRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Événement non trouvé"));

        // Vérifier que l'utilisateur est bien l'organisateur de cet événement
        if (!event.getOrganizerId().equals(organizerId)) {
            throw new RuntimeException("Vous n'êtes pas autorisé à supprimer cet événement");
        }

        eventRepository.deleteById(id);
        log.info("Event deleted successfully");
    }

    @Transactional
    public boolean updateTicketAvailability(Long eventId, Integer ticketsReserved) {
        log.info("Updating ticket availability for event: {}, tickets: {}", eventId, ticketsReserved);
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new RuntimeException("Événement non trouvé"));

        if (event.getAvailableTickets() < ticketsReserved) {
            log.warn("Not enough tickets. Available: {}, Requested: {}",
                    event.getAvailableTickets(), ticketsReserved);
            throw new RuntimeException("Billets insuffisants. Disponibles: " + event.getAvailableTickets());
        }

        event.setAvailableTickets(event.getAvailableTickets() - ticketsReserved);
        eventRepository.save(event);
        log.info("Ticket availability updated successfully");

        return true;
    }

    private void validateOrganizer(Long organizerId) {
        try {
            log.info("Validating organizer with ID: {}", organizerId);
            UserDto user = userServiceClient.getUserById(organizerId);
            if (user == null || !user.getActive()) {
                throw new RuntimeException("L'utilisateur n'est pas actif");
            }
            if (!"ORGANIZER".equals(user.getRole()) && !"ADMIN".equals(user.getRole())) {
                throw new RuntimeException(
                        "L'utilisateur doit avoir le rôle ORGANIZER ou ADMIN pour créer un événement");
            }
        } catch (Exception ex) {
            log.error("User service unavailable: {}", ex.getMessage());
            throw new RuntimeException("Service utilisateur temporairement indisponible");
        }
    }


    private EventDto convertToDTO(Event event) {
        EventDto dto = new EventDto();
        dto.setId(event.getId());
        dto.setName(event.getName());
        dto.setDescription(event.getDescription());
        dto.setStadium(event.getStadium());
        dto.setCity(event.getCity());
        dto.setEventDate(event.getEventDate());
        dto.setTotalTickets(event.getTotalTickets());
        dto.setAvailableTickets(event.getAvailableTickets());
        dto.setTicketPrice(event.getTicketPrice());
        dto.setOrganizerId(event.getOrganizerId());
        dto.setStatus(event.getStatus().name());

        List<ParticipantDTO> participantDTOs = event.getParticipants().stream()
                .map(p -> new ParticipantDTO(
                        p.getId(),
                        p.getTeamName(),
                        p.getTeamDescription(),
                        p.getTeamType().name()
                ))
                .collect(Collectors.toList());
        dto.setParticipants(participantDTOs);

        return dto;
    }

    private EventDto createEventFallback(CreateEventRequest request, Exception ex) {
        log.error("Fallback method called for createEvent. Error: {}", ex.getMessage());
        throw new RuntimeException(
                "Le service est temporairement indisponible. Veuillez réessayer plus tard.");
    }

    public long countEvents() {
        return eventRepository.count();
    }

    public long getEventCountByOrganizer(Long organizerId) {
        return eventRepository.countByOrganizerId(organizerId);
    }
}