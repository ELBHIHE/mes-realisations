package com.football.eventservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EventDto {

    private Long id;
    private String name;
    private String description;
    private String stadium;
    private String city;
    private LocalDateTime eventDate;
    private Integer totalTickets;
    private Integer availableTickets;
    private Double ticketPrice;
    private Long organizerId;
    private List<ParticipantDTO> participants;
    private String status;
}
