package com.football.eventservice.controller;

import com.football.eventservice.dto.CreateEventRequest;
import com.football.eventservice.dto.EventDto;
import com.football.eventservice.dto.UpdateTicketAvailabilityRequest;
import com.football.eventservice.service.EventService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.security.oauth2.resource.OAuth2ResourceServerProperties;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/events")
@RequiredArgsConstructor
public class EventController {

    private final EventService eventService;

    @PostMapping
    public ResponseEntity<EventDto> createEvent(
            @Valid @RequestBody CreateEventRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(eventService.createEvent(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EventDto> getEventById(@PathVariable Long id) {
        return ResponseEntity.ok(eventService.getEventById(id));
    }

    @GetMapping
    public ResponseEntity<List<EventDto>> getAllEvents() {
        return ResponseEntity.ok(eventService.getAllEvents());
    }

    @GetMapping("/upcoming")
    public ResponseEntity<List<EventDto>> getUpcomingEvents() {
        return ResponseEntity.ok(eventService.getUpcomingEvents());
    }

    @GetMapping("/organizer/{organizerId}")
    public ResponseEntity<List<EventDto>> getEventsByOrganizer(
            @PathVariable Long organizerId) {
        return ResponseEntity.ok(eventService.getEventsByOrganizer(organizerId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EventDto> updateEvent(
            @PathVariable Long id,
            @Valid @RequestBody CreateEventRequest request,
            @RequestHeader("X-User-Id") Long userId) {
        return ResponseEntity.ok(eventService.updateEvent(id, request, userId));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEvent(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") Long userId) {
        eventService.deleteEvent(id, userId);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/tickets")
    public ResponseEntity<Boolean> updateTicketAvailability(
            @PathVariable Long id,
            @Valid @RequestBody UpdateTicketAvailabilityRequest request) {
        boolean success = eventService.updateTicketAvailability(
                id,
                request.getTicketsReserved()
        );
        return ResponseEntity.ok(success);
    }

    @GetMapping("/count")
    public long getTotalEvents() {
        return eventService.countEvents();
    }

    @GetMapping("/count/{organizerId}")
    public ResponseEntity<Long> getEventCountByOrganizer(@PathVariable Long organizerId) {
        long count = eventService.getEventCountByOrganizer(organizerId);
        return ResponseEntity.ok(count);
    }
}
