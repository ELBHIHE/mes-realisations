package com.football.notificationservice.service;

import com.football.notificationservice.dto.NotificationDto;
import com.football.notificationservice.dto.NotificationRequest;
import com.football.notificationservice.model.Notification;
import com.football.notificationservice.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final EmailService emailService;
    private final SmsService smsService;

    /**
     * ✅ MÉTHODE PRINCIPALE - Envoi asynchrone de notification
     * Appelée par Reservation-Service et Payment-Service via Feign
     */
    @Async("taskExecutor")
    @Transactional
    public void sendNotification(NotificationRequest request) {
        log.info("📨 Traitement notification {} pour {}", request.getType(), request.getRecipient());

        // 1. Créer l'entrée en base de données
        Notification notification = createNotificationFromRequest(request);
        notification = notificationRepository.save(notification);

        // 2. Envoyer la notification selon le type
        try {
            if ("EMAIL".equalsIgnoreCase(request.getType())) {
                emailService.sendEmail(
                        request.getRecipient(),
                        request.getSubject(),
                        request.getContent()
                );
            } else if ("SMS".equalsIgnoreCase(request.getType())) {
                smsService.sendSms(
                        request.getRecipient(),
                        request.getContent()
                );
            } else {
                throw new IllegalArgumentException("Type de notification invalide: " + request.getType());
            }

            // 3. Marquer comme envoyée
            notification.setStatus("SENT");
            notification.setSentAt(LocalDateTime.now());
            log.info("✅ Notification envoyée avec succès");

        } catch (Exception e) {
            // 4. Marquer comme échouée
            notification.setStatus("FAILED");
            notification.setErrorMessage(e.getMessage());
            log.error("❌ Erreur lors de l'envoi: {}", e.getMessage());
        }

        notificationRepository.save(notification);
    }

    /**
     * ✅ Récupération d'une notification par ID
     */
    public NotificationDto getNotificationById(Long id) {
        Notification notification = notificationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Notification introuvable"));
        return convertToDto(notification);
    }

    /**
     * ✅ Liste toutes les notifications (admin)
     */
    public List<NotificationDto> getAllNotifications() {
        return notificationRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    /**
     * ✅ Notifications d'un utilisateur
     */
    public List<NotificationDto> getNotificationsByUserId(Long userId) {
        return notificationRepository.findByUserId(userId).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    /**
     * ✅ Notifications par statut
     */
    public List<NotificationDto> getNotificationsByStatus(String status) {
        return notificationRepository.findByStatus(status).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    /**
     * ✅ Relancer les notifications échouées
     */
    @Transactional
    public void retryFailedNotifications() {
        log.info("🔄 Retry des notifications échouées");

        List<Notification> failedNotifications = notificationRepository
                .findByStatusAndRetryCountLessThan("FAILED", 3);

        for (Notification notification : failedNotifications) {
            notification.setStatus("RETRY");
            notification.setRetryCount(notification.getRetryCount() + 1);
            notificationRepository.save(notification);

            // Créer une requête et relancer
            NotificationRequest request = convertToRequest(notification);
            sendNotification(request);
        }

        log.info("✅ {} notifications relancées", failedNotifications.size());
    }

    // ========================================
    // MÉTHODES PRIVÉES UTILITAIRES
    // ========================================

    /**
     * Convertit une NotificationRequest en entité Notification
     */
    private Notification createNotificationFromRequest(NotificationRequest request) {
        Notification notification = new Notification();
        notification.setType(request.getType().toUpperCase()); // Normaliser en majuscules
        notification.setCategory(request.getCategory().toUpperCase());
        notification.setRecipient(request.getRecipient());
        notification.setSubject(request.getSubject());
        notification.setContent(request.getContent());
        notification.setReferenceId(request.getReferenceId());
        notification.setUserId(request.getUserId());
        notification.setStatus("PENDING");
        notification.setRetryCount(0);
        return notification;
    }

    /**
     * Convertit une entité Notification en NotificationRequest
     */
    private NotificationRequest convertToRequest(Notification notification) {
        return NotificationRequest.builder()
                .type(notification.getType())
                .category(notification.getCategory())
                .recipient(notification.getRecipient())
                .subject(notification.getSubject())
                .content(notification.getContent())
                .referenceId(notification.getReferenceId())
                .userId(notification.getUserId())
                .build();
    }

    /**
     * Convertit une entité Notification en NotificationDto
     */
    private NotificationDto convertToDto(Notification notification) {
        NotificationDto dto = new NotificationDto();
        dto.setId(notification.getId());
        dto.setType(notification.getType());
        dto.setCategory(notification.getCategory());
        dto.setRecipient(notification.getRecipient());
        dto.setSubject(notification.getSubject());
        dto.setContent(notification.getContent());
        dto.setStatus(notification.getStatus());
        dto.setReferenceId(notification.getReferenceId());
        dto.setUserId(notification.getUserId());
        dto.setSentAt(notification.getSentAt());
        dto.setErrorMessage(notification.getErrorMessage());
        dto.setRetryCount(notification.getRetryCount());
        dto.setCreatedAt(notification.getCreatedAt());
        return dto;
    }
}