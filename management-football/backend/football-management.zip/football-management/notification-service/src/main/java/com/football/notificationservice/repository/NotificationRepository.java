package com.football.notificationservice.repository;

import com.football.notificationservice.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

    List<Notification> findByUserId(Long userId);

    List<Notification> findByStatus(String status);

    List<Notification> findByType(String type);

    List<Notification> findByCategory(String category);

    List<Notification> findByReferenceId(Long referenceId);

    List<Notification> findByStatusAndRetryCountLessThan(String status, Integer maxRetries);

    List<Notification> findByStatusAndCreatedAtBefore(String status, LocalDateTime dateTime);
}