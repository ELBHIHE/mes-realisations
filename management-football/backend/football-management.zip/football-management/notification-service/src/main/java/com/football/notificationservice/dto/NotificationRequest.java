package com.football.notificationservice.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO utilisé par les autres microservices (Reservation, Payment)
 * pour envoyer des notifications via Feign Client.
 *
 * Utilise des String car les autres services n'ont pas accès aux enums.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotificationRequest {

    @NotBlank(message = "Le type est requis")
    private String type; // "EMAIL" ou "SMS"

    @NotBlank(message = "La catégorie est requise")
    private String category; // "RESERVATION", "PAYMENT", "EVENT"

    @NotBlank(message = "Le destinataire est requis")
    private String recipient; // email or phone number

    @NotBlank(message = "Le sujet est requis")
    private String subject;

    @NotBlank(message = "Le contenu est requis")
    private String content;

    private Long referenceId; // ID de la réservation ou du paiement

    private Long userId;
}