package com.football.notificationservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * DTO de réponse pour les notifications
 * Retourné par les endpoints GET
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotificationDto {

    private Long id;
    private String type; // "EMAIL", "SMS"
    private String category; // "RESERVATION", "PAYMENT", etc.
    private String recipient;
    private String subject;
    private String content;
    private String status; // "PENDING", "SENT", "FAILED", "RETRY"
    private Long referenceId;
    private Long userId;
    private LocalDateTime sentAt;
    private String errorMessage;
    private Integer retryCount;
    private LocalDateTime createdAt;
}