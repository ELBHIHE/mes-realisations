package com.football.notificationservice.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Entité Notification - Stocke l'historique des notifications
 *
 * IMPORTANT : Utilise String au lieu d'Enum pour plus de flexibilité
 * et éviter les problèmes de conversion avec Feign
 */
@Entity
@Table(name = "notifications")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 20)
    private String type; // "EMAIL", "SMS"

    @Column(nullable = false, length = 50)
    private String category; // "RESERVATION", "PAYMENT", "EVENT", "GENERAL"

    @Column(nullable = false)
    private String recipient; // email or phone number

    @Column(nullable = false, length = 500)
    private String subject;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    @Column(nullable = false, length = 20)
    private String status = "PENDING"; // "PENDING", "SENT", "FAILED", "RETRY"

    @Column(name = "reference_id")
    private Long referenceId; // ID de la réservation ou du paiement

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "sent_at")
    private LocalDateTime sentAt;

    @Column(name = "error_message", length = 1000)
    private String errorMessage;

    @Column(name = "retry_count")
    private Integer retryCount = 0;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}