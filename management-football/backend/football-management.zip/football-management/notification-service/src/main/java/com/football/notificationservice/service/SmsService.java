package com.football.notificationservice.service;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;



/**
 * Service d'envoi de SMS via Twilio
 * Numéro Twilio : +19283655999
 */
@Service
@Slf4j
public class SmsService {

    @Value("${sms.provider.enabled:false}")
    private boolean smsEnabled;

    @Value("${sms.provider.from-number:+19283655999}")
    private String fromNumber;

    @Value("${sms.provider.name:simulation}")
    private String providerName;

    @Value("${sms.provider.account-sid:}")
    private String accountSid;

    @Value("${sms.provider.auth-token:}")
    private String authToken;

    /**
     * Initialisation de Twilio au démarrage du service
     */
    @PostConstruct
    public void init() {
        if (smsEnabled && "twilio".equalsIgnoreCase(providerName)) {
            if (accountSid != null && !accountSid.isEmpty() && authToken != null && !authToken.isEmpty()) {
                try {
                    Twilio.init(accountSid, authToken);
                    log.info("╔════════════════════════════════════════════════════════╗");
                    log.info("║       ✅ TWILIO INITIALISÉ AVEC SUCCÈS                ║");
                    log.info("╠════════════════════════════════════════════════════════╣");
                    log.info("║ Account SID : {}...                    ║", accountSid.substring(0, 10));
                    log.info("║ From Number : {}                       ║", fromNumber);
                    log.info("║ Provider    : Twilio                                  ║");
                    log.info("║ Mode        : ENVOI RÉEL DE SMS                       ║");
                    log.info("╚════════════════════════════════════════════════════════╝");
                } catch (Exception e) {
                    log.error("╔════════════════════════════════════════════════════════╗");
                    log.error("║       ❌ ERREUR INITIALISATION TWILIO                 ║");
                    log.error("╠════════════════════════════════════════════════════════╣");
                    log.error("║ Erreur : {}", e.getMessage());
                    log.error("╚════════════════════════════════════════════════════════╝");
                    log.error("💡 Vérifiez vos credentials Twilio dans application.properties");
                }
            } else {
                log.warn("⚠️ Twilio activé mais credentials manquants");
                log.warn("💡 Ajoutez account-sid et auth-token dans application.properties");
            }
        } else {
            log.info("╔════════════════════════════════════════════════════════╗");
            log.info("║       📱 MODE SMS : SIMULATION (GRATUIT)              ║");
            log.info("╠════════════════════════════════════════════════════════╣");
            log.info("║ Les SMS seront affichés dans les logs                 ║");
            log.info("║ Pour activer Twilio :                                  ║");
            log.info("║   sms.provider.enabled=true                            ║");
            log.info("╚════════════════════════════════════════════════════════╝");
        }
    }

    /**
     * Envoie un SMS (RÉEL via Twilio ou simulation)
     */
    public void sendSms(String phoneNumber, String message) {
        try {
            log.info("📱 Demande d'envoi SMS");
            log.info("   Provider : {}", providerName);
            log.info("   De       : {}", fromNumber);
            log.info("   À        : {}", phoneNumber);

            if (!smsEnabled) {
                log.warn("⚠️ Service SMS désactivé - Mode simulation");
                simulateSms(phoneNumber, message);
                return;
            }

            if ("twilio".equalsIgnoreCase(providerName)) {
                sendViaTwilio(phoneNumber, message);
            } else {
                log.warn("⚠️ Provider SMS inconnu: {}", providerName);
                simulateSms(phoneNumber, message);
            }

            log.info("✅ SMS traité avec succès");

        } catch (Exception e) {
            log.error("❌ Erreur lors de l'envoi du SMS: {}", e.getMessage());
            throw new RuntimeException("Échec de l'envoi du SMS: " + e.getMessage());
        }
    }

    /**
     * Envoi RÉEL via Twilio
     */
    private void sendViaTwilio(String phoneNumber, String message) {
        try {
            log.info("╔════════════════════════════════════════════════════════╗");
            log.info("║         🚀 ENVOI RÉEL VIA TWILIO                      ║");
            log.info("╠════════════════════════════════════════════════════════╣");

            Message twilioMessage = Message.creator(
                    new PhoneNumber(phoneNumber),  // Destinataire
                    new PhoneNumber(fromNumber),   // +19283655999
                    message                         // Contenu
            ).create();

            log.info("║ ✅ SMS ENVOYÉ AVEC SUCCÈS !                           ║");
            log.info("╠════════════════════════════════════════════════════════╣");
            log.info("║ Message SID  : {}... ║", twilioMessage.getSid().substring(0, 20));
            log.info("║ Status       : {}                              ║",
                    String.format("%-30s", twilioMessage.getStatus()));
            log.info("║ From         : {}                       ║", fromNumber);
            log.info("║ To           : {}                     ║",
                    String.format("%-24s", phoneNumber));
            log.info("║ Direction    : outbound-api                            ║");

            if (twilioMessage.getPrice() != null) {
                log.info("║ Price        : {} USD                              ║",
                        twilioMessage.getPrice());
            }

            log.info("╚════════════════════════════════════════════════════════╝");
            log.info("📱 Le destinataire devrait recevoir le SMS dans quelques secondes");

        } catch (com.twilio.exception.ApiException e) {
            log.error("╔════════════════════════════════════════════════════════╗");
            log.error("║         ❌ ERREUR TWILIO API                          ║");
            log.error("╠════════════════════════════════════════════════════════╣");
            log.error("║ Code     : {}", e.getCode());
            log.error("║ Message  : {}", e.getMessage());
            log.error("╚════════════════════════════════════════════════════════╝");

            if (e.getCode() == 21211) {
                log.error("💡 Le numéro {} n'est pas valide", phoneNumber);
            } else if (e.getCode() == 21608) {
                log.error("💡 Le numéro {} n'est pas vérifié (compte Trial)", phoneNumber);
                log.error("   Vérifiez-le sur : https://console.twilio.com/us1/develop/phone-numbers/manage/verified");
            } else if (e.getCode() == 21606) {
                log.error("💡 Le numéro FROM {} n'est pas un numéro Twilio valide", fromNumber);
            } else if (e.getCode() == 20003) {
                log.error("💡 Erreur d'authentification - Vérifiez account-sid et auth-token");
            }

            throw new RuntimeException("Erreur Twilio: " + e.getMessage());

        } catch (Exception e) {
            log.error("╔════════════════════════════════════════════════════════╗");
            log.error("║         ❌ ERREUR TWILIO                              ║");
            log.error("╠════════════════════════════════════════════════════════╣");
            log.error("║ {}", e.getMessage());
            log.error("╚════════════════════════════════════════════════════════╝");
            log.error("💡 Vérifiez :");
            log.error("   - Que le numéro destinataire est vérifié (compte trial)");
            log.error("   - Que le format du numéro est correct (+212...)");
            log.error("   - Que vos credentials Twilio sont corrects");
            log.error("   - Que vous avez du crédit Twilio restant");
            throw new RuntimeException("Erreur Twilio: " + e.getMessage());
        }
    }

    /**
     * Mode simulation (si Twilio désactivé)
     */
    private void simulateSms(String phoneNumber, String message) {
        log.info("╔════════════════════════════════════════════════════════╗");
        log.info("║           📱 SIMULATION ENVOI SMS                     ║");
        log.info("╠════════════════════════════════════════════════════════╣");
        log.info("║ De       : {}                       ║", fromNumber);
        log.info("║ À        : {}                     ║",
                String.format("%-24s", phoneNumber));
        log.info("╠════════════════════════════════════════════════════════╣");
        log.info("║ Message  :                                            ║");

        String[] lines = message.split("\\n");
        for (String line : lines) {
            if (line.length() > 50) {
                log.info("║ {}... ║", line.substring(0, 50));
            } else {
                log.info("║ {}", String.format("%-50s", line) + " ║");
            }
        }

        log.info("╚════════════════════════════════════════════════════════╝");
        log.info("✅ SMS simulé avec succès !");
        log.info("💡 Pour envoyer de VRAIS SMS :");
        log.info("   1. Mettez sms.provider.enabled=true");
        log.info("   2. Configurez vos credentials Twilio");

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Envoie un SMS de confirmation de réservation
     */
    public void sendReservationSms(String phoneNumber, String userName, String reservationCode, String eventName) {
        String message = String.format(
                "🏟️ Football Events\n\n" +
                        "Bonjour %s,\n\n" +
                        "Votre réservation pour '%s' est confirmée !\n\n" +
                        "Code de réservation : %s\n\n" +
                        "Merci de votre confiance !",
                userName, eventName, reservationCode
        );
        sendSms(phoneNumber, message);
    }

    /**
     * Envoie un SMS de confirmation de paiement
     */
    public void sendPaymentSms(String phoneNumber, String userName, String transactionId, Double amount) {
        String message = String.format(
                "💳 Football Events - Paiement Confirmé\n\n" +
                        "Bonjour %s,\n\n" +
                        "Votre paiement de %.2f MAD a été reçu avec succès.\n\n" +
                        "ID Transaction : %s\n\n" +
                        "Merci !",
                userName, amount, transactionId
        );
        sendSms(phoneNumber, message);
    }

    /**
     * Envoie un SMS de rappel de réservation
     */
    public void sendReservationReminder(String phoneNumber, String userName, String eventName, String dateTime) {
        String message = String.format(
                "⏰ Rappel - Football Events\n\n" +
                        "Bonjour %s,\n\n" +
                        "N'oubliez pas votre réservation pour '%s' demain à %s.\n\n" +
                        "À très bientôt !",
                userName, eventName, dateTime
        );
        sendSms(phoneNumber, message);
    }

    /**
     * Envoie un SMS d'annulation de réservation
     */
    public void sendReservationCancellation(String phoneNumber, String userName, String reservationCode) {
        String message = String.format(
                "❌ Football Events - Annulation\n\n" +
                        "Bonjour %s,\n\n" +
                        "Votre réservation (Code: %s) a été annulée.\n\n" +
                        "Si vous avez des questions, contactez-nous.",
                userName, reservationCode
        );
        sendSms(phoneNumber, message);
    }

    /**
     * Envoie un SMS d'échec de paiement
     */
    public void sendPaymentFailure(String phoneNumber, String userName, String reservationCode) {
        String message = String.format(
                "⚠️ Football Events - Paiement Échoué\n\n" +
                        "Bonjour %s,\n\n" +
                        "Le paiement pour votre réservation (Code: %s) a échoué.\n\n" +
                        "Veuillez réessayer ou nous contacter.",
                userName, reservationCode
        );
        sendSms(phoneNumber, message);
    }
}