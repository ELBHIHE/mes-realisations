package com.football.notificationservice.client;

import com.football.notificationservice.dto.UserDto;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "user-service", url = "${user-service.url:http://localhost:8081}")
public interface UserServiceClient {

    @GetMapping("/api/users/{id}")
    @CircuitBreaker(name = "userService", fallbackMethod = "getUserFallback")
    UserDto getUserById(@PathVariable("id") Long id);

    default UserDto getUserFallback(Long id, Exception ex) {
        throw new RuntimeException("Service utilisateur temporairement indisponible");
    }
}
