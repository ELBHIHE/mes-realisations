package com.football.notificationservice.controller;

import com.football.notificationservice.dto.NotificationDto;
import com.football.notificationservice.dto.NotificationRequest;
import com.football.notificationservice.service.NotificationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
@Slf4j
public class NotificationController {

    private final NotificationService notificationService;

    /**
     * ✅ ENDPOINT PRINCIPAL - Utilisé par Reservation/Payment Service via Feign
     * Reçoit une demande d'envoi de notification et la traite de manière asynchrone
     */
    @PostMapping("/send")
    public ResponseEntity<?> sendNotification(@Valid @RequestBody NotificationRequest request) {
        try {
            log.info("📨 Demande d'envoi notification {} pour {}", request.getType(), request.getRecipient());
            notificationService.sendNotification(request);

            Map<String, String> response = new HashMap<>();
            response.put("message", "Notification en cours d'envoi");
            response.put("type", request.getType());
            response.put("recipient", request.getRecipient());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("❌ Erreur lors de la demande d'envoi: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }

    /**
     * ✅ CONSULTATION - Récupère une notification par ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getNotificationById(@PathVariable Long id) {
        try {
            NotificationDto notification = notificationService.getNotificationById(id);
            return ResponseEntity.ok(notification);
        } catch (Exception e) {
            log.error("❌ Notification introuvable: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    /**
     * ✅ CONSULTATION - Historique des notifications d'un utilisateur
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<NotificationDto>> getUserNotifications(@PathVariable Long userId) {
        log.info("📋 Consultation notifications utilisateur: {}", userId);
        List<NotificationDto> notifications = notificationService.getNotificationsByUserId(userId);
        return ResponseEntity.ok(notifications);
    }

    /**
     * ✅ ADMIN - Liste toutes les notifications
     */
    @GetMapping
    public ResponseEntity<List<NotificationDto>> getAllNotifications() {
        log.info("📋 Consultation toutes les notifications (admin)");
        List<NotificationDto> notifications = notificationService.getAllNotifications();
        return ResponseEntity.ok(notifications);
    }

    /**
     * ✅ ADMIN - Notifications par statut
     */
    @GetMapping("/status/{status}")
    public ResponseEntity<List<NotificationDto>> getNotificationsByStatus(@PathVariable String status) {
        log.info("📋 Consultation notifications avec statut: {}", status);
        List<NotificationDto> notifications = notificationService.getNotificationsByStatus(status.toUpperCase());
        return ResponseEntity.ok(notifications);
    }

    /**
     * ✅ ADMIN - Relancer les notifications échouées
     */
    @PostMapping("/retry-failed")
    public ResponseEntity<Map<String, String>> retryFailedNotifications() {
        try {
            log.info("🔄 Relance des notifications échouées");
            notificationService.retryFailedNotifications();

            Map<String, String> response = new HashMap<>();
            response.put("message", "Retry des notifications échouées en cours");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("❌ Erreur lors du retry: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * ✅ HEALTH CHECK
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "notification-service");
        return ResponseEntity.ok(response);
    }
}