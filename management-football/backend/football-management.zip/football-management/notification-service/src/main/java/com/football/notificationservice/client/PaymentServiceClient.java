package com.football.notificationservice.client;

import com.football.notificationservice.dto.PaymentDto;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "payment-service", url = "${payment-service.url:http://localhost:8084}")
public interface PaymentServiceClient {

    @GetMapping("/api/payments/{id}")
    @CircuitBreaker(name = "paymentService", fallbackMethod = "getPaymentFallback")
    PaymentDto getPaymentById(@PathVariable("id") Long id);

    default PaymentDto getPaymentFallback(Long id, Exception ex) {
        throw new RuntimeException("Service paiement temporairement indisponible");
    }
}
