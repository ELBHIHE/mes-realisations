package com.football.notificationservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReservationDto {
    private Long id;
    private Long userId;
    private Long eventId;
    private Integer numberOfTickets;
    private Double totalPrice;
    private String status;
    private String reservationCode;
    private String userEmail;
    private String userName;
    private String eventName;
    private LocalDateTime eventDate;
    private String eventStadium;
    private LocalDateTime createdAt;
}
