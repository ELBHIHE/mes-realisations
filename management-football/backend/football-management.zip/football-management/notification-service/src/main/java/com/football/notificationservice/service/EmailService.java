package com.football.notificationservice.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailService {

    private final JavaMailSender mailSender;
    private final SpringTemplateEngine templateEngine;

    @Value("${spring.mail.username}")
    private String fromEmail;

    private static final DateTimeFormatter DATE_FORMATTER =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public void sendEmail(String to, String subject, String content) {
        try {
            log.info("Envoi d'email à: {}", to);

            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(to);
            message.setSubject(subject);
            message.setText(content);

            mailSender.send(message);
            log.info("Email envoyé avec succès à: {}", to);

        } catch (Exception e) {
            log.error("Erreur lors de l'envoi de l'email à {}: {}", to, e.getMessage());
            throw new RuntimeException("Échec de l'envoi de l'email: " + e.getMessage());
        }
    }

    public void sendHtmlEmail(String to, String subject, String templateName, Map<String, Object> variables) {
        try {
            log.info("Envoi d'email HTML à: {} avec le template: {}", to, templateName);

            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            Context context = new Context();
            context.setVariables(variables);
            String htmlContent = templateEngine.process(templateName, context);

            helper.setFrom(fromEmail);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(htmlContent, true);

            mailSender.send(message);
            log.info("Email HTML envoyé avec succès à: {}", to);

        } catch (MessagingException e) {
            log.error("Erreur lors de l'envoi de l'email HTML à {}: {}", to, e.getMessage());
            throw new RuntimeException("Échec de l'envoi de l'email HTML: " + e.getMessage());
        }
    }

    // Email de confirmation de réservation avec template HTML
    public void sendReservationConfirmationHtml(
            String to,
            String userName,
            String reservationCode,
            String eventName,
            LocalDateTime eventDate,
            String eventStadium,
            Integer numberOfTickets,
            Double totalPrice) {

        log.info("Envoi de confirmation de réservation HTML à: {}", to);

        Map<String, Object> variables = new HashMap<>();
        variables.put("userName", userName);
        variables.put("reservationCode", reservationCode);
        variables.put("eventName", eventName);
        variables.put("eventDate", eventDate.format(DATE_FORMATTER));
        variables.put("eventStadium", eventStadium);
        variables.put("numberOfTickets", numberOfTickets);
        variables.put("totalPrice", String.format("%.2f", totalPrice));

        String subject = "✅ Confirmation de réservation - " + eventName;

        sendHtmlEmail(to, subject, "reservation-confirmation", variables);
    }

    // Email de confirmation de paiement avec template HTML
    public void sendPaymentConfirmationHtml(
            String to,
            String userName,
            String transactionId,
            String reservationCode,
            String eventName,
            Double amount,
            String paymentMethod,
            LocalDateTime paymentDate) {

        log.info("Envoi de confirmation de paiement HTML à: {}", to);

        Map<String, Object> variables = new HashMap<>();
        variables.put("userName", userName);
        variables.put("transactionId", transactionId);
        variables.put("reservationCode", reservationCode);
        variables.put("eventName", eventName);
        variables.put("amount", String.format("%.2f", amount));
        variables.put("paymentMethod", paymentMethod);
        variables.put("paymentDate", paymentDate.format(DATE_FORMATTER));

        String subject = "✅ Confirmation de paiement - " + eventName;

        sendHtmlEmail(to, subject, "payment-confirmation", variables);
    }

    // Méthodes texte simple (backup)
    public void sendReservationConfirmation(String to, String userName, String reservationCode,
                                            String eventName, String eventDate, Integer tickets, Double totalPrice) {
        String subject = "Confirmation de votre réservation - " + eventName;
        String content = String.format(
                "Bonjour %s,\n\n" +
                        "Votre réservation a été confirmée avec succès!\n\n" +
                        "Détails de la réservation:\n" +
                        "- Code de réservation: %s\n" +
                        "- Événement: %s\n" +
                        "- Date: %s\n" +
                        "- Nombre de billets: %d\n" +
                        "- Prix total: %.2f MAD\n\n" +
                        "Merci pour votre réservation!\n\n" +
                        "Cordialement,\n" +
                        "L'équipe Football Events",
                userName, reservationCode, eventName, eventDate, tickets, totalPrice
        );

        sendEmail(to, subject, content);
    }

    public void sendPaymentConfirmation(String to, String userName, String transactionId,
                                        String eventName, Double amount) {
        String subject = "Confirmation de paiement - " + eventName;
        String content = String.format(
                "Bonjour %s,\n\n" +
                        "Votre paiement a été traité avec succès!\n\n" +
                        "Détails du paiement:\n" +
                        "- ID de transaction: %s\n" +
                        "- Événement: %s\n" +
                        "- Montant: %.2f MAD\n\n" +
                        "Merci pour votre confiance!\n\n" +
                        "Cordialement,\n" +
                        "L'équipe Football Events",
                userName, transactionId, eventName, amount
        );

        sendEmail(to, subject, content);
    }

    // Email d'annulation de réservation
    public void sendReservationCancellation(String to, String userName, String reservationCode, String eventName) {
        String subject = "Annulation de réservation - " + eventName;
        String content = String.format(
                "Bonjour %s,\n\n" +
                        "Votre réservation a été annulée.\n\n" +
                        "Détails:\n" +
                        "- Code de réservation: %s\n" +
                        "- Événement: %s\n\n" +
                        "Si vous n'êtes pas à l'origine de cette annulation, veuillez nous contacter immédiatement.\n\n" +
                        "Cordialement,\n" +
                        "L'équipe Football Events",
                userName, reservationCode, eventName
        );

        sendEmail(to, subject, content);
    }

    // Email de rappel d'événement
    public void sendEventReminder(String to, String userName, String eventName, LocalDateTime eventDate, String stadium) {
        String subject = "⏰ Rappel: " + eventName + " - Demain!";
        String content = String.format(
                "Bonjour %s,\n\n" +
                        "Nous vous rappelons que l'événement suivant aura lieu demain:\n\n" +
                        "📅 Événement: %s\n" +
                        "🕐 Date: %s\n" +
                        "📍 Lieu: %s\n\n" +
                        "N'oubliez pas d'apporter votre code de réservation!\n\n" +
                        "À très bientôt,\n" +
                        "L'équipe Football Events",
                userName, eventName, eventDate.format(DATE_FORMATTER), stadium
        );

        sendEmail(to, subject, content);
    }
}