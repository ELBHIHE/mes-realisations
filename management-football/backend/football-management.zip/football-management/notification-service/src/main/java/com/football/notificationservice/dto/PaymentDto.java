package com.football.notificationservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentDto {
    private Long id;
    private Long reservationId;
    private Long userId;
    private Double amount;
    private String paymentMethod;
    private String status;
    private String transactionId;
    private String description;
    private String userEmail;
    private String userName;
    private String reservationCode;
    private String eventName;
    private LocalDateTime createdAt;
    private LocalDateTime completedAt;
}
