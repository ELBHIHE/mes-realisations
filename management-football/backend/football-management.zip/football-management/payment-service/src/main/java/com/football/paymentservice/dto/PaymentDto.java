package com.football.paymentservice.dto;

import com.football.paymentservice.model.PaymentMethod;
import com.football.paymentservice.model.PaymentStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentDto {

    private Long id;
    private Long reservationId;
    private Long userId;
    private Double amount;
    private PaymentMethod paymentMethod;
    private PaymentStatus status;
    private String transactionId;
    private String description;
    private String userEmail;
    private String userName;
    private String reservationCode;
    private String eventName;
    private LocalDateTime createdAt;
    private LocalDateTime completedAt;
}