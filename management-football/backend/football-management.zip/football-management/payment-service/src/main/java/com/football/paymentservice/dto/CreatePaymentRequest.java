package com.football.paymentservice.dto;

import com.football.paymentservice.model.PaymentMethod;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreatePaymentRequest {

    @NotNull(message = "Reservation ID est requis")
    private Long reservationId;

    @NotNull(message = "User ID est requis")
    private Long userId;

    //@NotNull(message = "Le montant est requis")
    //@Min(value = 0, message = "Le montant doit être positif")
    //private Double amount;

    @NotNull(message = "La méthode de paiement est requise")
    private PaymentMethod paymentMethod;

    private String description;
}