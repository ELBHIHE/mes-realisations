package com.football.paymentservice.controller;

import com.football.paymentservice.dto.CreatePaymentRequest;
import com.football.paymentservice.dto.PaymentDto;
import com.football.paymentservice.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
@Slf4j
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping
    public ResponseEntity<?> createPayment(
            @Valid @RequestBody CreatePaymentRequest request) {
        try {
            log.info("Requête de création de paiement reçue");
            PaymentDto payment = paymentService.createPayment(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(payment);
        } catch (Exception e) {
            log.error("Erreur lors de la création du paiement: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }

    @PostMapping("/{id}/process")
    public ResponseEntity<?> processPayment(@PathVariable Long id) {
        try {
            log.info("Requête de traitement du paiement ID: {}", id);
            PaymentDto payment = paymentService.processPayment(id);
            return ResponseEntity.ok(payment);
        } catch (Exception e) {
            log.error("Erreur lors du traitement du paiement: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }

    @PostMapping("/process-immediately")
    public ResponseEntity<?> createAndProcessPayment(
            @Valid @RequestBody CreatePaymentRequest request) {
        try {
            log.info("🚀 Création et traitement immédiat du paiement");

            // 1. Créer le paiement
            PaymentDto payment = paymentService.createPayment(request);

            // 2. Le traiter immédiatement
            PaymentDto processedPayment = paymentService.processPayment(payment.getId());

            return ResponseEntity.status(HttpStatus.CREATED).body(processedPayment);

        } catch (Exception e) {
            log.error("Erreur lors du paiement: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }


    @GetMapping("/{id}")
    public ResponseEntity<?> getPaymentById(@PathVariable Long id) {
        try {
            log.info("Requête de récupération du paiement ID: {}", id);
            PaymentDto payment = paymentService.getPaymentById(id);
            return ResponseEntity.ok(payment);
        } catch (Exception e) {
            log.error("Erreur lors de la récupération: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    @GetMapping("/transaction/{transactionId}")
    public ResponseEntity<?> getPaymentByTransactionId(@PathVariable String transactionId) {
        try {
            log.info("Requête de récupération par transaction ID: {}", transactionId);
            PaymentDto payment = paymentService.getPaymentByTransactionId(transactionId);
            return ResponseEntity.ok(payment);
        } catch (Exception e) {
            log.error("Erreur: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<PaymentDto>> getPaymentsByUserId(
            @PathVariable Long userId) {
        log.info("Récupération des paiements de l'utilisateur: {}", userId);
        List<PaymentDto> payments = paymentService.getPaymentsByUserId(userId);
        return ResponseEntity.ok(payments);
    }

    @GetMapping("/reservation/{reservationId}")
    public ResponseEntity<List<PaymentDto>> getPaymentsByReservationId(
            @PathVariable Long reservationId) {
        log.info("Récupération des paiements de la réservation: {}", reservationId);
        List<PaymentDto> payments = paymentService.getPaymentsByReservationId(reservationId);
        return ResponseEntity.ok(payments);
    }

    @GetMapping
    public ResponseEntity<List<PaymentDto>> getAllPayments() {
        log.info("Récupération de tous les paiements");
        List<PaymentDto> payments = paymentService.getAllPayments();
        return ResponseEntity.ok(payments);
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<?> cancelPayment(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") Long userId) {
        try {
            log.info("Annulation du paiement ID: {}", id);
            PaymentDto payment = paymentService.cancelPayment(id, userId);
            return ResponseEntity.ok(payment);
        } catch (Exception e) {
            log.error("Erreur lors de l'annulation: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }

    @PutMapping("/{id}/refund")
    public ResponseEntity<?> refundPayment(@PathVariable Long id) {
        try {
            log.info("Remboursement du paiement ID: {}", id);
            PaymentDto payment = paymentService.refundPayment(id);
            return ResponseEntity.ok(payment);
        } catch (Exception e) {
            log.error("Erreur lors du remboursement: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "payment-service");
        return ResponseEntity.ok(response);
    }
}