package com.football.paymentservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotificationRequest {
    private String type;
    private String category;
    private String recipient;
    private String subject;
    private String content;
    private Long referenceId;
    private Long userId;
}
