package com.football.paymentservice.client;

import com.football.paymentservice.dto.ReservationDto;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "reservation-service", url = "${reservation-service.url:http://localhost:8083}")
public interface ReservationServiceClient {

    @GetMapping("/api/reservations/{id}")
    @CircuitBreaker(name = "reservationService", fallbackMethod = "getReservationFallback")
    ReservationDto getReservationById(@PathVariable("id") Long id);

    default ReservationDto getReservationFallback(Long id, Exception ex) {
        throw new RuntimeException("Service réservation temporairement indisponible");
    }
}
