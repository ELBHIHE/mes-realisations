package com.football.paymentservice.model;

public enum PaymentStatus {
    EN_ATTENTE,
    EN_COURS_DE_TRAITEMENT,
    COMPLETE,
    ECHOUE,
    REMBOURSE,
    ANNULE
}
