package com.football.paymentservice.client;
import com.football.paymentservice.dto.NotificationRequest;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "notification-service", url = "${notification-service.url:http://localhost:8085}")
public interface NotificationServiceClient {

    @PostMapping("/api/notifications/send")
    @CircuitBreaker(name = "notificationService", fallbackMethod = "sendNotificationFallback")
    void sendNotification(@RequestBody NotificationRequest request);

    default void sendNotificationFallback(NotificationRequest request, Exception ex) {
        System.err.println("⚠️ Notification service indisponible: " + ex.getMessage());
    }
}