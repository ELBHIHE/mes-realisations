package com.football.paymentservice.service;

import com.football.paymentservice.client.NotificationServiceClient;
import com.football.paymentservice.client.ReservationServiceClient;
import com.football.paymentservice.client.UserServiceClient;
import com.football.paymentservice.dto.*;
import com.football.paymentservice.model.Payment;
import com.football.paymentservice.model.PaymentStatus;
import com.football.paymentservice.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final UserServiceClient userServiceClient;
    private final ReservationServiceClient reservationServiceClient;
    private final NotificationServiceClient notificationServiceClient; // ✅ AJOUTER

    @Transactional
    public PaymentDto createPayment(CreatePaymentRequest request) {
        log.info("Création d'un paiement pour la réservation {} par l'utilisateur {}",
                request.getReservationId(), request.getUserId());

        // Vérifier que l'utilisateur existe et est actif
        UserDto user = userServiceClient.getUserById(request.getUserId());
        if (user == null || !user.getActive()) {
            throw new RuntimeException("Utilisateur introuvable ou inactif");
        }

        // Vérifier que la réservation existe
        ReservationDto reservation = reservationServiceClient.getReservationById(request.getReservationId());
        if (reservation == null) {
            throw new RuntimeException("Réservation introuvable");
        }

        // Vérifier que la réservation appartient bien à l'utilisateur
        if (!reservation.getUserId().equals(request.getUserId())) {
            throw new RuntimeException("Cette réservation n'appartient pas à cet utilisateur");
        }

        // ✅ NOUVEAU : Vérifier le statut de la réservation
        if (!"CONFIRMEE".equals(reservation.getStatus())) {
            throw new RuntimeException("La réservation doit être confirmée avant le paiement. Statut actuel: " + reservation.getStatus());
        }

        // Vérifier qu'il n'y a pas déjà un paiement complété pour cette réservation
        paymentRepository.findByReservationIdAndStatus(request.getReservationId(), PaymentStatus.COMPLETE)
                .ifPresent(p -> {
                    throw new RuntimeException("Un paiement existe déjà pour cette réservation");
                });


        // ✅ NOUVEAU : Calcul automatique du montant depuis la réservation
        Double amount = reservation.getTotalPrice();

        if (amount == null || amount <= 0) {
            throw new RuntimeException("Montant de réservation invalide: " + amount);
        }

        log.info("💰 Montant calculé automatiquement: {} MAD", amount);

        // Créer le paiement
        Payment payment = new Payment();
        payment.setReservationId(request.getReservationId());
        payment.setUserId(request.getUserId());
        payment.setAmount(amount);  // ✅ Montant automatique
        payment.setPaymentMethod(request.getPaymentMethod());
        payment.setStatus(PaymentStatus.EN_ATTENTE);
        payment.setTransactionId(generateTransactionId());
        payment.setDescription(request.getDescription());

        // Stocker les informations de l'utilisateur et de la réservation
        payment.setUserEmail(user.getEmail());
        payment.setUserName(user.getFirstName() + " " + user.getLastName());
        payment.setReservationCode(reservation.getReservationCode());
        payment.setEventName(reservation.getEventName());

        Payment savedPayment = paymentRepository.save(payment);
        log.info("Paiement créé avec succès. Transaction ID: {}", savedPayment.getTransactionId());

        return convertToDto(savedPayment);
    }

    @Transactional
    public PaymentDto processPayment(Long paymentId) {
        log.info("Traitement du paiement ID: {}", paymentId);

        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new RuntimeException("Paiement introuvable"));

        if (payment.getStatus() == PaymentStatus.COMPLETE) {
            throw new RuntimeException("Ce paiement a déjà été traité");
        }

        if (payment.getStatus() == PaymentStatus.ANNULE) {
            throw new RuntimeException("Ce paiement a été annulé");
        }

        // Simuler le traitement du paiement
        payment.setStatus(PaymentStatus.EN_COURS_DE_TRAITEMENT);
        paymentRepository.save(payment);

        try {
            // Simulation d'un appel à une passerelle de paiement
            Thread.sleep(2000); // Simuler un délai de traitement

            // Simuler un succès (dans un vrai système, on vérifierait la réponse de la passerelle)
            boolean paymentSuccess = simulatePaymentGateway(payment);

            if (paymentSuccess) {
                payment.setStatus(PaymentStatus.COMPLETE);
                payment.setCompletedAt(LocalDateTime.now());
                log.info("Paiement traité avec succès - Montant: {} MAD", payment.getAmount());


                // ✅ AJOUTÉ - ENVOI AUTOMATIQUE EMAIL
                try {
                    sendPaymentConfirmationEmail(payment);
                    log.info("✉️ Email de confirmation de paiement envoyé à {}", payment.getUserEmail());
                } catch (Exception e) {
                    log.warn("⚠️ Échec envoi email (non bloquant): {}", e.getMessage());
                }

                // ✅ AJOUTÉ - ENVOI AUTOMATIQUE SMS
                try {
                    sendPaymentConfirmationSms(payment);
                    log.info("📱 SMS de confirmation de paiement envoyé");
                } catch (Exception e) {
                    log.warn("⚠️ Échec envoi SMS (non bloquant): {}", e.getMessage());
                }

            } else {
                payment.setStatus(PaymentStatus.ECHOUE);
                log.warn("Échec du traitement du paiement");
            }

        } catch (InterruptedException e) {
            payment.setStatus(PaymentStatus.ECHOUE);
            log.error("Erreur lors du traitement du paiement: {}", e.getMessage());
            Thread.currentThread().interrupt();
        }

        Payment updatedPayment = paymentRepository.save(payment);
        return convertToDto(updatedPayment);
    }

    public PaymentDto getPaymentById(Long id) {
        log.info("Récupération du paiement ID: {}", id);
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Paiement introuvable"));
        return convertToDto(payment);
    }

    public PaymentDto getPaymentByTransactionId(String transactionId) {
        log.info("Récupération du paiement par transaction ID: {}", transactionId);
        Payment payment = paymentRepository.findByTransactionId(transactionId)
                .orElseThrow(() -> new RuntimeException("Paiement introuvable"));
        return convertToDto(payment);
    }

    public List<PaymentDto> getPaymentsByUserId(Long userId) {
        log.info("Récupération des paiements de l'utilisateur: {}", userId);
        return paymentRepository.findByUserId(userId).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public List<PaymentDto> getPaymentsByReservationId(Long reservationId) {
        log.info("Récupération des paiements pour la réservation: {}", reservationId);
        return paymentRepository.findByReservationId(reservationId).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public List<PaymentDto> getAllPayments() {
        log.info("Récupération de tous les paiements");
        return paymentRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public PaymentDto cancelPayment(Long id, Long userId) {
        log.info("Annulation du paiement ID: {} par l'utilisateur: {}", id, userId);

        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Paiement introuvable"));

        // Vérifier que c'est bien l'utilisateur qui a créé le paiement
        if (!payment.getUserId().equals(userId)) {
            throw new RuntimeException("Vous n'êtes pas autorisé à annuler ce paiement");
        }

        // Vérifier que le paiement n'est pas déjà complété
        if (payment.getStatus() == PaymentStatus.COMPLETE) {
            throw new RuntimeException("Impossible d'annuler un paiement complété. Demandez un remboursement.");
        }

        // Vérifier que le paiement n'est pas déjà annulé
        if (payment.getStatus() == PaymentStatus.ANNULE) {
            throw new RuntimeException("Ce paiement est déjà annulé");
        }

        payment.setStatus(PaymentStatus.ANNULE);
        payment.setUpdatedAt(LocalDateTime.now());

        Payment updated = paymentRepository.save(payment);
        log.info("Paiement annulé avec succès");

        return convertToDto(updated);
    }

    @Transactional
    public PaymentDto refundPayment(Long id) {
        log.info("Remboursement du paiement ID: {}", id);

        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Paiement introuvable"));

        if (payment.getStatus() != PaymentStatus.COMPLETE) {
            throw new RuntimeException("Seuls les paiements complétés peuvent être remboursés");
        }

        payment.setStatus(PaymentStatus.REMBOURSE);
        payment.setUpdatedAt(LocalDateTime.now());

        Payment updated = paymentRepository.save(payment);
        log.info("Paiement remboursé avec succès");

        return convertToDto(updated);
    }




    // ✅ MÉTHODE AJOUTÉE - Envoi Email Confirmation Paiement
    private void sendPaymentConfirmationEmail(Payment payment) {
        String emailContent = String.format(
                "Bonjour %s,\n\n" +
                        "Votre paiement a été traité avec succès!\n\n" +
                        "💳 Détails du paiement:\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "🆔 Transaction: %s\n" +
                        "🎫 Réservation: %s\n" +
                        "⚽ Événement: %s\n" +
                        "💰 Montant: %.2f MAD\n" +
                        "💳 Méthode: %s\n" +
                        "📅 Date: %s\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                        "Merci pour votre confiance!\n\n" +
                        "Cordialement,\n" +
                        "L'équipe Football Events 🏆",
                payment.getUserName(),
                payment.getTransactionId(),
                payment.getReservationCode(),
                payment.getEventName(),
                payment.getAmount(),
                payment.getPaymentMethod(),
                payment.getCompletedAt()
        );

        NotificationRequest notification = NotificationRequest.builder()
                .type("EMAIL")
                .category("PAYMENT")
                .recipient(payment.getUserEmail())
                .subject("✅ Confirmation de paiement - " + payment.getEventName())
                .content(emailContent)
                .referenceId(payment.getId())
                .userId(payment.getUserId())
                .build();

        notificationServiceClient.sendNotification(notification);
    }

    // ✅ MÉTHODE AJOUTÉE - Envoi SMS Confirmation Paiement
    private void sendPaymentConfirmationSms(Payment payment) {
        String smsContent = String.format(
                "✅ Paiement confirmé!\n" +
                        "Transaction: %s\n" +
                        "Montant: %.2f MAD\n" +
                        "Événement: %s",
                payment.getTransactionId(),
                payment.getAmount(),
                payment.getEventName()
        );

        NotificationRequest notification = NotificationRequest.builder()
                .type("SMS")
                .category("PAYMENT")
                .recipient(payment.getUserEmail())
                .subject("Confirmation paiement")
                .content(smsContent)
                .referenceId(payment.getId())
                .userId(payment.getUserId())
                .build();

        notificationServiceClient.sendNotification(notification);
    }

    private String generateTransactionId() {
        return "TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    private boolean simulatePaymentGateway(Payment payment) {
        log.info("🎲 Simulation: Montant={} MAD, Méthode={}",
                payment.getAmount(), payment.getPaymentMethod());

        // 95% de succès
        boolean success = Math.random() > 0.05;

        if (success) {
            log.info("Passerelle de paiement: SUCCÈS");
        } else {
            log.warn("Passerelle de paiement: ÉCHEC");
        }

        return success;
    }

    private PaymentDto convertToDto(Payment payment) {
        PaymentDto dto = new PaymentDto();
        dto.setId(payment.getId());
        dto.setReservationId(payment.getReservationId());
        dto.setUserId(payment.getUserId());
        dto.setAmount(payment.getAmount());
        dto.setPaymentMethod(payment.getPaymentMethod());
        dto.setStatus(payment.getStatus());
        dto.setTransactionId(payment.getTransactionId());
        dto.setDescription(payment.getDescription());
        dto.setUserEmail(payment.getUserEmail());
        dto.setUserName(payment.getUserName());
        dto.setReservationCode(payment.getReservationCode());
        dto.setEventName(payment.getEventName());
        dto.setCreatedAt(payment.getCreatedAt());
        dto.setCompletedAt(payment.getCompletedAt());
        return dto;
    }
}