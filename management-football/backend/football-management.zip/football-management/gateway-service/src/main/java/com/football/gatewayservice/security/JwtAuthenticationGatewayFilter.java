package com.football.gatewayservice.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.security.Key;
import java.util.List;

/**
 * Filtre global du Gateway qui valide les tokens JWT
 * et transmet les informations utilisateur aux microservices
 */
@Component
public class JwtAuthenticationGatewayFilter implements GlobalFilter, Ordered {

    @Value("${jwt.secret}")
    private String secretKey;

    // Endpoints publics (pas besoin de token)
    private static final List<String> PUBLIC_ENDPOINTS = List.of(
            "/user-service/api/users/register",
            "/user-service/api/users/authenticate",
            "/user-service/api/users/health",
            "/api/users/register",
            "/api/users/authenticate",
            "/api/users/health",
            "/event-service/api/events/health",
            "/reservation-service/api/reservations/health",
            "/payment-service/api/payments/health",
            "/notification-service/api/notifications/health"
    );

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

        String path = exchange.getRequest().getURI().getPath();

        // ✅ LOG pour debug
        System.out.println("🔍 Gateway reçoit: " + path);

        // Si l'endpoint est public, on laisse passer
        if (isPublicEndpoint(path)) {
            System.out.println("✅ Endpoint public, accès autorisé");
            return chain.filter(exchange);
        }

        System.out.println("🔐 Endpoint protégé, vérification JWT...");

        // Récupère le header Authorization
        String authHeader = exchange.getRequest().getHeaders().getFirst("Authorization");

        // Si pas de header ou format incorrect
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            System.err.println("❌ Pas de token Authorization");
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }

        // Extrait le token
        String token = authHeader.substring(7);

        try {
            // ✅ CORRECTION : Utilise la même méthode que user-service
            Key signingKey = Keys.hmacShaKeyFor(Decoders.BASE64.decode(secretKey));

            // Valide et extrait les claims du token
            Claims claims = Jwts.parser()
                    .setSigningKey(signingKey)
                    .parseClaimsJws(token)
                    .getBody();

            // Extrait les informations utilisateur
            String email = claims.getSubject();
            String userId = claims.get("userId", String.class);
            String role = claims.get("role", String.class);

            System.out.println("✅ Token valide - User: " + email + " (ID: " + userId + ", Role: " + role + ")");

            // Ajoute les informations utilisateur dans les headers
            ServerHttpRequest modifiedRequest = exchange.getRequest().mutate()
                    .header("X-User-Email", email)
                    .header("X-User-Id", userId != null ? userId : "")
                    .header("X-User-Role", role != null ? role : "USER")
                    .build();

            // Continue avec la requête modifiée
            return chain.filter(exchange.mutate().request(modifiedRequest).build());

        } catch (Exception e) {
            // Token invalide ou expiré
            System.err.println("❌ Erreur validation token: " + e.getClass().getSimpleName() + " - " + e.getMessage());
            e.printStackTrace();
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }
    }

    /**
     * Vérifie si l'endpoint est public
     */
    private boolean isPublicEndpoint(String path) {
        return PUBLIC_ENDPOINTS.stream().anyMatch(path::startsWith);
    }

    /**
     * Priorité du filtre (exécuté en premier)
     */
    @Override
    public int getOrder() {
        return -1;
    }
}