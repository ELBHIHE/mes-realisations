package com.football.userservice.model;

public enum Role {
    USER,
    ORGANIZER,
    ADMIN
}
