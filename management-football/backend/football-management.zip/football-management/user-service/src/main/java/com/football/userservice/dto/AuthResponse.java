package com.football.userservice.dto;

import com.football.userservice.model.Role;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AuthResponse {

    private Long id;
    private String message;
    private String email;
    private String firstName;
    private String lastName;
    private String phone;
    private Role role;

    // ✅ NOUVEAU - Token JWT ajouté
    private String token;
}
