package com.football.userservice.service;

import com.football.userservice.dto.AuthRequest;
import com.football.userservice.dto.AuthResponse;
import com.football.userservice.dto.RegisterRequest;
import com.football.userservice.dto.UserDto;
import com.football.userservice.model.Role;
import com.football.userservice.model.User;
import com.football.userservice.repository.UserRepository;
import com.football.userservice.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    // ✅ NOUVEAUX - Dépendances pour JWT et sécurité
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private final UserDetailsService userDetailsService;

    public AuthResponse register(RegisterRequest request) {

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email déjà utilisé");
        }

        User user = new User();
        user.setEmail(request.getEmail());

        // ✅ MODIFIÉ - Encode le mot de passe avec BCrypt
        user.setPassword(passwordEncoder.encode(request.getPassword()));


        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setPhone(request.getPhone());

        // Vérifie si le rôle est fourni, sinon USER par défaut
        user.setRole(request.getRole() != null ? request.getRole() : Role.USER);

        user.setActive(true);

        userRepository.save(user);

        // ✅ NOUVEAU - Génère le token JWT
        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getEmail());
        // ✅ NOUVEAU CODE
        String jwtToken = jwtService.generateTokenWithClaims(
                userDetails,
                user.getId(),
                user.getRole().name()
        );

        return new AuthResponse(
                user.getId(),
                "Inscription réussie",
                user.getEmail(),
                user.getFirstName(),
                user.getLastName(),
                user.getPhone(),
                user.getRole(),
                jwtToken  // ✅ Token JWT ajouté
        );
    }

    public AuthResponse authenticate(AuthRequest request) {

        // ✅ NOUVEAU - Utilise Spring Security pour vérifier les credentials
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Utilisateur introuvable"));

        // ✅ NOUVEAU - Génère le token JWT
        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getEmail());
        // ✅ NOUVEAU CODE
        String jwtToken = jwtService.generateTokenWithClaims(
                userDetails,
                user.getId(),
                user.getRole().name()
        );

        return new AuthResponse(
                user.getId(),
                "Authentification réussie",
                user.getEmail(),
                user.getFirstName(),
                user.getLastName(),
                user.getPhone(),
                user.getRole(),
                jwtToken  // ✅ Token JWT ajouté
        );
    }

    public UserDto getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Utilisateur introuvable"));
        return mapToDto(user);
    }

    public UserDto getUserByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Utilisateur introuvable"));
        return mapToDto(user);
    }

    public List<UserDto> getAllUsers() {
        return userRepository.findAll()
                .stream()
                .map(this::mapToDto)
                .toList();
    }

    public UserDto updateUser(Long id, UserDto dto) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Utilisateur introuvable"));

        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setPhone(dto.getPhone());
        user.setRole(dto.getRole());

        userRepository.save(user);
        return mapToDto(user);
    }

    public void deleteUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Utilisateur introuvable"));
        user.setActive(false); // désactivation logique
        userRepository.save(user);
    }

    private UserDto mapToDto(User user) {
        return new UserDto(
                user.getId(),
                user.getEmail(),
                user.getFirstName(),
                user.getLastName(),
                user.getPhone(),
                user.getRole(),
                user.getActive()
        );
    }

    public long countOrganizers() {
        return userRepository.countByRole(Role.ORGANIZER);
    }
}