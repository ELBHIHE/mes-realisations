package com.football.reservationservice.service;

import com.football.reservationservice.client.EventServiceClient;
import com.football.reservationservice.client.NotificationServiceClient;
import com.football.reservationservice.client.UserServiceClient;
import com.football.reservationservice.dto.*;
import com.football.reservationservice.model.Reservation;
import com.football.reservationservice.model.ReservationStatus;
import com.football.reservationservice.repository.ReservationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private final UserServiceClient userServiceClient;
    private final EventServiceClient eventServiceClient;
    private final NotificationServiceClient notificationServiceClient; // ✅ AJOUTER CETTE LIGNE

    @Transactional
    public ReservationDto createReservation(CreateReservationRequest request) {
        log.info("Création d'une réservation pour l'utilisateur {} et l'événement {}",
                request.getUserId(), request.getEventId());


        // ← AJOUTER CETTE VALIDATION
        if (request.getNumberOfTickets() > 4) {
            throw new RuntimeException("Vous ne pouvez pas réserver plus de 4 billets par réservation");
        }

        // Vérifier que l'utilisateur existe et est actif
        UserDto user = userServiceClient.getUserById(request.getUserId());
        if (user == null || !user.getActive()) {
            throw new RuntimeException("Utilisateur introuvable ou inactif");
        }

        // Vérifier que l'événement existe et a des billets disponibles
        EventDto event = eventServiceClient.getEventById(request.getEventId());
        if (event == null) {
            throw new RuntimeException("Événement introuvable");
        }

        if (event.getAvailableTickets() < request.getNumberOfTickets()) {
            throw new RuntimeException(
                    "Billets insuffisants. Disponibles: " + event.getAvailableTickets());
        }

        // Vérifier que l'événement n'est pas passé
        if (event.getEventDate().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Impossible de réserver pour un événement passé");
        }

        // Calculer le prix total
        Double totalPrice = event.getTicketPrice() * request.getNumberOfTickets();

        // Créer la réservation
        Reservation reservation = new Reservation();
        reservation.setUserId(request.getUserId());
        reservation.setEventId(request.getEventId());
        reservation.setNumberOfTickets(request.getNumberOfTickets());
        reservation.setTotalPrice(totalPrice);
        reservation.setStatus(ReservationStatus.En_ATTENTE);
        reservation.setReservationCode(generateReservationCode());

        // Stocker les informations de l'utilisateur et de l'événement
        reservation.setUserEmail(user.getEmail());
        reservation.setUserName(user.getFirstName() + " " + user.getLastName());
        reservation.setEventName(event.getName());
        reservation.setEventDate(event.getEventDate());
        reservation.setEventStadium(event.getStadium());

        // Sauvegarder la réservation
        Reservation savedReservation = reservationRepository.save(reservation);

        // Mettre à jour la disponibilité des billets dans l'événement
        try {
            UpdateTicketAvailabilityRequest updateRequest = new UpdateTicketAvailabilityRequest();
            updateRequest.setTicketsReserved(request.getNumberOfTickets());

            Boolean updated = eventServiceClient.updateTicketAvailability(
                    request.getEventId(), updateRequest);

            if (Boolean.TRUE.equals(updated)) {
                savedReservation.setStatus(ReservationStatus.CONFIRMEE);
                savedReservation = reservationRepository.save(savedReservation);
                log.info("Réservation confirmée avec le code: {}", savedReservation.getReservationCode());

                // ✅ AJOUTER CE BLOC - ENVOI AUTOMATIQUE EMAIL
                try {
                    sendReservationConfirmationEmail(savedReservation);
                    log.info("✉️ Email de confirmation envoyé à {}", savedReservation.getUserEmail());
                } catch (Exception e) {
                    log.warn("⚠️ Échec envoi email (non bloquant): {}", e.getMessage());
                }

                // ✅ AJOUTER CE BLOC - ENVOI AUTOMATIQUE SMS
                try {
                    sendReservationConfirmationSms(savedReservation);
                    log.info("📱 SMS de confirmation envoyé");
                } catch (Exception e) {
                    log.warn("⚠️ Échec envoi SMS (non bloquant): {}", e.getMessage());
                }
            }

        } catch (Exception ex) {
            log.error("Erreur lors de la mise à jour des billets: {}", ex.getMessage());
            savedReservation.setStatus(ReservationStatus.ANNULEE);
            reservationRepository.save(savedReservation);
            throw new RuntimeException("Échec de la réservation. Veuillez réessayer.");
        }

        return convertToDto(savedReservation);
    }


    // ✅ AJOUTER CETTE MÉTHODE À LA FIN DE LA CLASSE
    private void sendReservationConfirmationEmail(Reservation reservation) {
        String emailContent = String.format(
                "Bonjour %s,\n\n" +
                        "Votre réservation a été confirmée avec succès!\n\n" +
                        "📋 Détails de la réservation:\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "🎫 Code: %s\n" +
                        "⚽ Événement: %s\n" +
                        "📅 Date: %s\n" +
                        "🏟️ Stade: %s\n" +
                        "🎟️ Billets: %d\n" +
                        "💰 Prix total: %.2f MAD\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                        "Présentez ce code à l'entrée du stade.\n\n" +
                        "Cordialement,\n" +
                        "L'équipe Football Events 🏆",
                reservation.getUserName(),
                reservation.getReservationCode(),
                reservation.getEventName(),
                reservation.getEventDate(),
                reservation.getEventStadium(),
                reservation.getNumberOfTickets(),
                reservation.getTotalPrice()
        );

        NotificationRequest emailNotification = NotificationRequest.builder()
                .type("EMAIL")
                .category("RESERVATION")
                .recipient(reservation.getUserEmail())
                .subject("✅ Confirmation de réservation - " + reservation.getEventName())
                .content(emailContent)
                .referenceId(reservation.getId())
                .userId(reservation.getUserId())
                .build();

        notificationServiceClient.sendNotification(emailNotification);
    }

    // ✅ AJOUTER CETTE MÉTHODE
    private void sendReservationConfirmationSms(Reservation reservation) {
        String smsContent = String.format(
                "✅ Réservation confirmée!\n" +
                        "Code: %s\n" +
                        "Événement: %s\n" +
                        "Date: %s\n" +
                        "Billets: %d",
                reservation.getReservationCode(),
                reservation.getEventName(),
                reservation.getEventDate(),
                reservation.getNumberOfTickets()
        );

        NotificationRequest smsNotification = NotificationRequest.builder()
                .type("SMS")
                .category("RESERVATION")
                .recipient(reservation.getUserEmail()) // Utiliser email temporairement
                .subject("Confirmation réservation")
                .content(smsContent)
                .referenceId(reservation.getId())
                .userId(reservation.getUserId())
                .build();

        notificationServiceClient.sendNotification(smsNotification);
    }

    public ReservationDto getReservationById(Long id) {
        log.info("Récupération de la réservation ID: {}", id);
        Reservation reservation = reservationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Réservation introuvable"));
        return convertToDto(reservation);
    }

    public ReservationDto getReservationByCode(String code) {
        log.info("Récupération de la réservation par code: {}", code);
        Reservation reservation = reservationRepository.findByReservationCode(code)
                .orElseThrow(() -> new RuntimeException("Réservation introuvable"));
        return convertToDto(reservation);
    }

    public List<ReservationDto> getReservationsByUserId(Long userId) {
        log.info("Récupération des réservations de l'utilisateur: {}", userId);
        return reservationRepository.findByUserId(userId).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public List<ReservationDto> getReservationsByEventId(Long eventId) {
        log.info("Récupération des réservations pour l'événement: {}", eventId);
        return reservationRepository.findByEventId(eventId).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public List<ReservationDto> getAllReservations() {
        log.info("Récupération de toutes les réservations");
        return reservationRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public ReservationDto cancelReservation(Long id, Long userId) {
        log.info("Annulation de la réservation ID: {} par l'utilisateur: {}", id, userId);

        Reservation reservation = reservationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Réservation introuvable"));

        // Vérifier que c'est bien l'utilisateur qui a fait la réservation
        if (!reservation.getUserId().equals(userId)) {
            throw new RuntimeException("Vous n'êtes pas autorisé à annuler cette réservation");
        }

        // Vérifier que la réservation n'est pas déjà annulée
        if (reservation.getStatus() == ReservationStatus.ANNULEE) {
            throw new RuntimeException("Cette réservation est déjà annulée");
        }

        // Vérifier que l'événement n'est pas passé
        if (reservation.getEventDate().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Impossible d'annuler une réservation pour un événement passé");
        }

        reservation.setStatus(ReservationStatus.ANNULEE);
        reservation.setUpdatedAt(LocalDateTime.now());

        Reservation updated = reservationRepository.save(reservation);
        log.info("Réservation annulée avec succès");

        return convertToDto(updated);
    }

    @Transactional
    public void deleteReservation(Long id) {
        log.info("Suppression de la réservation ID: {}", id);

        Reservation reservation = reservationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Réservation introuvable"));

        reservationRepository.delete(reservation);
        log.info("Réservation supprimée avec succès");
    }

    private String generateReservationCode() {
        return "RES-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    private ReservationDto convertToDto(Reservation reservation) {
        ReservationDto dto = new ReservationDto();
        dto.setId(reservation.getId());
        dto.setUserId(reservation.getUserId());
        dto.setEventId(reservation.getEventId());
        dto.setNumberOfTickets(reservation.getNumberOfTickets());
        dto.setTotalPrice(reservation.getTotalPrice());
        dto.setStatus(reservation.getStatus().name());
        dto.setReservationCode(reservation.getReservationCode());
        dto.setUserEmail(reservation.getUserEmail());
        dto.setUserName(reservation.getUserName());
        dto.setEventName(reservation.getEventName());
        dto.setEventDate(reservation.getEventDate());
        dto.setEventStadium(reservation.getEventStadium());
        dto.setCreatedAt(reservation.getCreatedAt());
        return dto;
    }

    public long countReservations() {
        return reservationRepository.count();
    }

    public Double getPaidRevenueByEvent(Long eventId) {
        return reservationRepository.getPaidRevenueByEvent(eventId);
    }
}