package com.football.reservationservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotificationRequest {
    private String type; // EMAIL ou SMS
    private String category; // RESERVATION, PAYMENT, EVENT
    private String recipient;
    private String subject;
    private String content;
    private Long referenceId;
    private Long userId;
}
