package com.football.reservationservice.controller;

import com.football.reservationservice.dto.CreateReservationRequest;
import com.football.reservationservice.dto.ReservationDto;
import com.football.reservationservice.service.ReservationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reservations")
@RequiredArgsConstructor
@Slf4j
public class ReservationController {

    private final ReservationService reservationService;

    @PostMapping
    public ResponseEntity<?> createReservation(
            @Valid @RequestBody CreateReservationRequest request) {
        try {
            log.info("Requête de création de réservation reçue");
            ReservationDto reservation = reservationService.createReservation(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(reservation);
        } catch (Exception e) {
            log.error("Erreur lors de la création de la réservation: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getReservationById(@PathVariable Long id) {
        try {
            log.info("Requête de récupération de la réservation ID: {}", id);
            ReservationDto reservation = reservationService.getReservationById(id);
            return ResponseEntity.ok(reservation);
        } catch (Exception e) {
            log.error("Erreur lors de la récupération: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    @GetMapping("/code/{code}")
    public ResponseEntity<?> getReservationByCode(@PathVariable String code) {
        try {
            log.info("Requête de récupération par code: {}", code);
            ReservationDto reservation = reservationService.getReservationByCode(code);
            return ResponseEntity.ok(reservation);
        } catch (Exception e) {
            log.error("Erreur: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<ReservationDto>> getReservationsByUserId(
            @PathVariable Long userId) {
        log.info("Récupération des réservations de l'utilisateur: {}", userId);
        List<ReservationDto> reservations = reservationService.getReservationsByUserId(userId);
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/event/{eventId}")
    public ResponseEntity<List<ReservationDto>> getReservationsByEventId(
            @PathVariable Long eventId) {
        log.info("Récupération des réservations de l'événement: {}", eventId);
        List<ReservationDto> reservations = reservationService.getReservationsByEventId(eventId);
        return ResponseEntity.ok(reservations);
    }

    @GetMapping
    public ResponseEntity<List<ReservationDto>> getAllReservations() {
        log.info("Récupération de toutes les réservations");
        List<ReservationDto> reservations = reservationService.getAllReservations();
        return ResponseEntity.ok(reservations);
    }

    @PutMapping("/{id}/cancel")
    public ResponseEntity<?> cancelReservation(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") Long userId) {
        try {
            log.info("Annulation de la réservation ID: {}", id);
            ReservationDto reservation = reservationService.cancelReservation(id, userId);
            return ResponseEntity.ok(reservation);
        } catch (Exception e) {
            log.error("Erreur lors de l'annulation: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteReservation(@PathVariable Long id) {
        try {
            log.info("Suppression de la réservation ID: {}", id);
            reservationService.deleteReservation(id);
            Map<String, String> response = new HashMap<>();
            response.put("message", "Réservation supprimée avec succès");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Erreur lors de la suppression: {}", e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "reservation-service");
        return ResponseEntity.ok(response);
    }

    @GetMapping("/count")
    public long getTotalReservations() {
        return reservationService.countReservations();
    }

    @GetMapping("/event/{eventId}/revenue")
    public ResponseEntity<Double> getRevenueByEvent(@PathVariable Long eventId) {
        Double revenue = reservationService.getPaidRevenueByEvent(eventId);
        return ResponseEntity.ok(revenue);
    }
}