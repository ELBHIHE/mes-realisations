package com.football.reservationservice.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreateReservationRequest {

    @NotNull(message = "User ID est requis")
    private Long userId;

    @NotNull(message = "Event ID est requis")
    private Long eventId;

    @NotNull(message = "Le nombre de billets est requis")
    @Min(value = 1, message = "Le nombre de billets doit être au moins 1")
    @Max(value = 4, message = "Vous ne pouvez pas réserver plus de 4 billets")  // ← AJOUTER CECI
    private Integer numberOfTickets;
}