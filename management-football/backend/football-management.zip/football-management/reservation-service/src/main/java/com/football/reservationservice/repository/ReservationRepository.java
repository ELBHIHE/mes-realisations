package com.football.reservationservice.repository;

import com.football.reservationservice.model.Reservation;
import com.football.reservationservice.model.ReservationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    List<Reservation> findByUserId(Long userId);

    List<Reservation> findByEventId(Long eventId);

    List<Reservation> findByStatus(ReservationStatus status);

    Optional<Reservation> findByReservationCode(String reservationCode);

    List<Reservation> findByUserIdAndStatus(Long userId, ReservationStatus status);

    List<Reservation> findByEventIdAndStatus(Long eventId, ReservationStatus status);

    long count();


    @Query("SELECT COALESCE(SUM(r.totalPrice), 0.0) " +
            "FROM Reservation r " +
            "WHERE r.eventId = :eventId " +
            "  AND r.status = com.football.reservationservice.model.ReservationStatus.CONFIRMEE")  // Adapte le statut selon ton enum
    Double getPaidRevenueByEvent(@Param("eventId") Long eventId);
}