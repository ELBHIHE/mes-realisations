package com.football.reservationservice.client;

import com.football.reservationservice.dto.EventDto;
import com.football.reservationservice.dto.UpdateTicketAvailabilityRequest;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "event-service", url = "${event-service.url:http://localhost:8082}")
public interface EventServiceClient {

    @GetMapping("/api/events/{id}")
    @CircuitBreaker(name = "eventService", fallbackMethod = "getEventFallback")
    EventDto getEventById(@PathVariable("id") Long id);

    @PutMapping("/api/events/{id}/tickets")
    @CircuitBreaker(name = "eventService", fallbackMethod = "updateTicketsFallback")
    Boolean updateTicketAvailability(
            @PathVariable("id") Long id,
            @RequestBody UpdateTicketAvailabilityRequest request
    );

    default EventDto getEventFallback(Long id, Exception ex) {
        throw new RuntimeException("Service événement temporairement indisponible");
    }

    default Boolean updateTicketsFallback(Long id, UpdateTicketAvailabilityRequest request, Exception ex) {
        throw new RuntimeException("Impossible de mettre à jour les billets");
    }
}