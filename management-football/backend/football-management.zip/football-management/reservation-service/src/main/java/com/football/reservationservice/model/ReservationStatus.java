package com.football.reservationservice.model;

public enum ReservationStatus {
    En_ATTENTE,
    CONFIRMEE,
    ANNULEE,
    EXPIREE
}
